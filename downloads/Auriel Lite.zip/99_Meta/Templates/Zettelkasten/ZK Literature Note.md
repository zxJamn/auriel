<%*
const id = tp.date.now("YYYYMMDDHHmmss");
const created = tp.date.now("YYYY-MM-DD HH:mm");
const selectedText = tp.file.selection();

const readLink = (() => {
  const GET = async (url, body) => {
    try {
      const r = await tp.obsidian.requestUrl({ url, method: body ? "POST" : "GET", throw: false,
        body: body ? JSON.stringify(body) : undefined, contentType: body ? "application/json" : undefined,
        headers: { "Accept-Language": "en-GB,en;q=0.9", "Cookie": "SOCS=CAI" } });
      return r.status < 400 ? r.text : null;
    } catch (e) { return null; }
  };
  const asJson = t => { try { return t ? JSON.parse(t) : null; } catch (e) { return null; } };
  const pageJson = (h, name) => {
    if (!h) return null;
    const at = [name + " = {", name + "={", `["${name}"] = {`].map(s => h.indexOf(s)).find(i => i >= 0);
    if (at == null) return null;
    const s = h.indexOf("{", at); let d = 0, q = false, esc = false;
    for (let k = s; k < h.length; k++) {
      const c = h[k];
      if (q) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === '"') q = false; }
      else if (c === '"') q = true; else if (c === "{") d++; else if (c === "}" && --d === 0) return asJson(h.slice(s, k + 1));
    }
    return null;
  };
  const walk = (o, fn) => { if (!o || typeof o !== "object") return; if (Array.isArray(o)) return o.forEach(x => walk(x, fn)); for (const k in o) if (!fn(k, o[k])) walk(o[k], fn); };
  const words = t => !t ? "" : typeof t === "string" ? t : t.simpleText ?? t.content ?? (t.runs || []).map(r => r.text).join("");
  const secs = s => /^\d+(:\d{1,2}){1,2}$/.test(String(s).trim()) ? String(s).trim().split(":").reduce((a, x) => a * 60 + +x, 0) : 0;
  const unhtml = s => String(s || "").replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|nbsp);/gi, (_, e) => e[0] === "#" ? String.fromCodePoint(parseInt(e.slice(1).replace(/^x/i, ""), /^#x/i.test(e) ? 16 : 10)) : ({ amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " })[e.toLowerCase()]);
  const biggest = list => (list || []).slice().sort((a, b) => (b.width || 0) - (a.width || 0))[0]?.url || "";

  const ids = url => {
    let u; try { u = new URL(url.trim()); } catch (e) { return null; }
    const host = u.hostname.replace(/^(www|m|music)\./, ""), p = u.pathname.split("/").filter(Boolean);
    if (host === "youtu.be") return { v: p[0] || null, list: u.searchParams.get("list") };
    if (!/^youtube(-nocookie)?\.com$/.test(host)) return null;
    const v = u.searchParams.get("v") || (["shorts", "live", "embed", "v"].includes(p[0]) ? p[1] : null);
    const list = /^(PL|OLAK|UU|FL|OL)/.test(u.searchParams.get("list") || "") ? u.searchParams.get("list") : null;
    const channel = p[0] && (p[0][0] === "@" || ["channel", "c", "user"].includes(p[0])) ? `https://www.youtube.com/${p[0][0] === "@" ? p[0] : p.slice(0, 2).join("/")}` : null;
    return { v, list, channel };
  };

  let VER = "2.20250910.01.00";
  const api = (path, body) => GET(`https://www.youtube.com/youtubei/v1/${path}?prettyPrint=false`,
    { context: { client: { clientName: "WEB", clientVersion: VER, hl: "en", gl: "GB" } }, ...body }).then(asJson);
  const version = h => { const m = h && h.match(/"INNERTUBE_CLIENT_VERSION":"([^"]+)"/); if (m) VER = m[1]; };

  const fromDescription = (text, len) => {
    const out = [];
    for (const line of String(text || "").split("\n")) {
      const m = line.match(/(?:^|[\s(\[])((?:\d{1,2}:)?\d{1,2}:\d{2})(?=$|[\s)\]\-–—:|])/);
      if (!m) continue;
      const s = secs(m[1]);
      const t = line.replace(new RegExp(`[(\\[]?\\s*${m[1]}\\s*[)\\]]?`), " ").replace(/^[^\p{L}\p{N}"'“‘]+/u, "").replace(/[\s\-–—:|]+$/, "").replace(/\s+/g, " ").trim();
      if (t && (!out.length || s > out[out.length - 1].s) && (!len || s < len)) out.push({ t, s });
    }
    return out.length >= 3 ? out : [];
  };

  async function video(v) {
    const h = await GET(`https://www.youtube.com/watch?v=${v}&hl=en`); version(h);
    const pr = pageJson(h, "ytInitialPlayerResponse") || await api("player", { videoId: v });
    const dt = pageJson(h, "ytInitialData") || await api("next", { videoId: v });
    const vd = pr && pr.videoDetails;
    if (!vd) return null;
    const len = +vd.lengthSeconds || 0;
    const sets = [];
    walk(dt && dt.playerOverlays, (k, val) => { if (k === "markersMap" && Array.isArray(val)) { val.forEach(m => sets.push([m.key, (m.value && m.value.chapters) || []])); return true; } });
    const set = (sets.find(([k, c]) => k === "DESCRIPTION_CHAPTERS" && c.length) || sets.find(([, c]) => c.length) || [null, []])[1];
    let ch = set.map(c => c.chapterRenderer).filter(Boolean).map(c => ({ t: words(c.title), s: Math.round((c.timeRangeStartMillis || 0) / 1000) }));
    let from = ch.length ? "chapters" : "";
    if (!ch.length) { ch = fromDescription(vd.shortDescription, len); from = ch.length ? "description" : ""; }
    const lessons = ch.map((c, i) => ({ t: c.t, url: `https://youtu.be/${v}${c.s ? "?t=" + c.s : ""}`, secs: (i + 1 < ch.length ? ch[i + 1].s : len) - c.s }));
    return { kind: "video", title: vd.title || "", author: vd.author || "", platform: "YouTube", link: `https://www.youtube.com/watch?v=${v}`,
      cover: biggest(vd.thumbnail && vd.thumbnail.thumbnails), secs: len, from,
      lessons: lessons.length ? lessons : [{ t: vd.title || "The video", url: `https://youtu.be/${v}`, secs: len }] };
  }

  async function playlist(list) {
    const h = await GET(`https://www.youtube.com/playlist?list=${list}&hl=en`); version(h);
    let dt = pageJson(h, "ytInitialData");
    if (!dt || !dt.contents) dt = await api("browse", { browseId: "VL" + list });
    if (!dt) return null;
    const out = [], seen = new Set(); let more = null;
    const add = (id, t, s) => { if (!id || seen.has(id) || /^\[(private|deleted) video\]$/i.test(t)) return; seen.add(id); out.push({ t, url: `https://www.youtube.com/watch?v=${id}&list=${list}`, secs: s, id }); };
    const take = tree => walk(tree, (k, x) => {
      if (k === "playlistVideoRenderer") { add(x.videoId, words(x.title), +x.lengthSeconds || secs(words(x.lengthText))); return true; }
      if (k === "lockupViewModel" && /VIDEO/.test(x.contentType || "VIDEO")) {
        let s = 0; walk(x.contentImage, (kk, b) => { if (kk === "thumbnailBadgeViewModel" && secs(b.text)) { s = s || secs(b.text); return true; } });
        add(x.contentId, words(x.metadata && x.metadata.lockupMetadataViewModel && x.metadata.lockupMetadataViewModel.title), s); return true; }
      if (k === "continuationCommand" && x.token) { more = x.token; return true; }
    });
    take(dt.contents);
    for (let n = 0; more && n < 20; n++) { const r = await api("browse", { continuation: more }); more = null; take(r && (r.onResponseReceivedActions || r.continuationContents)); }
    if (!out.length) return null;
    let title = words(dt.metadata && dt.metadata.playlistMetadataRenderer && dt.metadata.playlistMetadataRenderer.title), author = "";
    walk(dt.header, (k, x) => { if (k === "ownerText" && !author) author = words(x); if (k === "title" && !title) title = words(x); });
    walk(dt.sidebar, (k, x) => { if (k === "videoOwnerRenderer" && !author) { author = words(x.title); return true; } });
    if (!author) { const o = asJson(await GET(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent("https://www.youtube.com/playlist?list=" + list)}`)); author = (o && o.author_name) || ""; }
    author = author.replace(/^by\s+/i, "");
    const first = out[0].id, wide = `https://i.ytimg.com/vi/${first}/maxresdefault.jpg`;
    const cover = await tp.obsidian.requestUrl({ url: wide, method: "HEAD", throw: false }).then(r => r.status < 400, () => false) ? wide : `https://i.ytimg.com/vi/${first}/hqdefault.jpg`;
    return { kind: "playlist", title, author, platform: "YouTube", link: `https://www.youtube.com/playlist?list=${list}`, cover,
      secs: out.reduce((a, x) => a + (x.secs || 0), 0), from: "playlist", lessons: shared(out).map(({ t, url, secs }) => ({ t, url, secs })) };
  }
  function shared(list) {
    if (list.length < 3) return list;
    const ts = list.map(x => x.t), need = Math.max(3, Math.ceil(ts.length * .75)), SEP = /[|:,–—]|\s-/g;
    const most = (cands, has) => [...new Set(cands)].filter(c => c.trim().length > 2 && ts.filter(t => has(t, c)).length >= need).sort((a, b) => b.length - a.length)[0] || "";
    const heads = [], tails = [];
    ts.forEach(t => { for (const m of t.matchAll(SEP)) { heads.push(t.slice(0, m.index + m[0].length)); tails.push(t.slice(m.index)); } });
    const pre = most(heads, (t, c) => t.startsWith(c) && t.length > c.length), suf = most(tails, (t, c) => t.endsWith(c) && t.length > c.length);
    const cut = ts.map(t => { if (pre && t.startsWith(pre)) t = t.slice(pre.length); if (suf && t.endsWith(suf)) t = t.slice(0, t.length - suf.length); return t.replace(/^[\s|:,–—-]+|[\s|:,–—-]+$/g, ""); });
    return cut.every(t => t.length > 1) ? list.map((x, i) => ({ ...x, t: cut[i] })) : list;
  }

  async function page(url) {
    const h = await GET(url);
    if (!h) return null;
    const meta = p => { const m = h.match(new RegExp(`<meta[^>]+(?:property|name)=["']${p}["'][^>]*content=["']([^"']*)["']`, "i")) || h.match(new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']${p}["']`, "i")); return m ? unhtml(m[1]).trim() : ""; };
    const site = meta("og:site_name"), host = new URL(url).hostname.replace(/^www\./, "");
    let title = meta("og:title") || unhtml((h.match(/<title[^>]*>([^<]*)</i) || [])[1] || "").trim();
    for (const cut of [site, host, "YouTube"].filter(Boolean)) title = title.replace(new RegExp(`\\s*[|–—-]\\s*${cut.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*$`, "i"), "");
    return { kind: "page", title, author: meta("author"), platform: site || host, link: url, cover: meta("og:image"), secs: 0, from: "", lessons: [] };
  }

  const isbnOf = s => { const d = String(s || "").replace(/^isbn[:\s]*/i, "").replace(/[\s-]/g, ""); return /^(97[89]\d{10}|\d{9}[\dX])$/i.test(d) ? d.toUpperCase() : null; };
  const OL = "https://openlibrary.org";
  async function book(ref) {
    const ed = asJson(await GET(ref.isbn ? `${OL}/isbn/${ref.isbn}.json` : `${OL}${ref.path}.json`));
    if (!ed || ed.error) return null;
    let edition = ed, work = null;
    if (ed.type && ed.type.key === "/type/work") {
      work = ed; const es = (asJson(await GET(`${OL}${ed.key}/editions.json?limit=100`)) || {}).entries || [], same = String(ed.title || "").toLowerCase().slice(0, 12);
      const rank = e => (String(e.title || "").toLowerCase().startsWith(same) ? 4 : 0) + ((e.table_of_contents || []).length > 2 ? 2 : 0) + (e.covers ? 1 : 0);
      edition = es.slice().sort((x, y) => rank(y) - rank(x))[0] || ed;
    }
    else if (ed.works && ed.works[0]) work = asJson(await GET(`${OL}${ed.works[0].key}.json`));
    const keys = (edition.authors || []).map(a => a.key).concat(((work && work.authors) || []).map(a => a.author && a.author.key)).filter(Boolean);
    const names = [];
    for (const k of [...new Set(keys)].slice(0, 3)) { const a = asJson(await GET(`${OL}${k}.json`)); if (a && a.name) names.push(a.name); }
    let toc = edition.table_of_contents || [], from = toc.length > 2 ? "contents" : "", other = "";
    if (toc.length < 3 && work) {
      const lang = ((edition.languages || [])[0] || {}).key;
      const es = asJson(await GET(`${OL}${work.key}/editions.json?limit=100`));
      const score = e => (e.table_of_contents || []).length + (e.table_of_contents || []).filter(t => t.pagenum).length;
      const best = ((es && es.entries) || []).filter(e => (e.table_of_contents || []).length > 2 && (!lang || ((e.languages || [])[0] || {}).key === lang)).sort((a, b) => score(b) - score(a))[0];
      if (best) { toc = best.table_of_contents; from = "contents"; other = best.key; edition = best.number_of_pages ? { ...edition, number_of_pages: edition.number_of_pages || best.number_of_pages } : edition; }
    }
    const flat = new Set(toc.map(t => t.level || 0)).size < 2;
    const depth = t => flat ? String(t.label || "").split(".").filter(Boolean).length - 1 : t.level || 0;
    const name = t => [/^[\dIVXLC.]+$/i.test(t.label || "") ? t.label : "", words(t.title)].filter(Boolean).join(" ").trim();
    const pageNum = t => /^\d+$/.test(String(t.pagenum || "").trim()) ? +t.pagenum : null;
    const lessons = [], total = edition.number_of_pages || 0;
    toc.forEach((t, i) => {
      if (i + 1 < toc.length && depth(toc[i + 1]) > depth(t)) return;
      let part = ""; for (let j = i - 1; j >= 0; j--) if (depth(toc[j]) < depth(t)) { part = name(toc[j]); break; }
      const p0 = pageNum(t), next = toc.slice(i + 1).map(pageNum).find(n => n != null), p1 = next != null ? next - 1 : total || null;
      lessons.push({ t: name(t), part, pages: p0 != null && p1 != null && p1 >= p0 ? [p0, p1] : null });
    });
    const id = (edition.covers || []).find(c => c > 0);
    const title = edition.title || (work && work.title) || "";
    if (!lessons.length) lessons.push({ t: title || "The book", part: "", pages: total ? [1, total] : null });
    return { kind: "book", title, author: names.join(", "), platform: "Book", pages: total,
      link: ref.isbn ? `${OL}/isbn/${ref.isbn}` : `${OL}${ref.path}`, cover: id ? `https://covers.openlibrary.org/b/id/${id}-L.jpg` : "",
      secs: 0, from: lessons.length ? from : "", other, lessons };
  }

  async function read(url, wholeList) {
    const isbn = isbnOf(url), ol = /openlibrary\.org\/(isbn\/([\dXx-]+)|(?:books|works)\/OL\d+[MW])/.exec(url);
    if (isbn || ol) return book(isbn ? { isbn } : ol[2] ? { isbn: isbnOf(ol[2]) } : { path: "/" + ol[1] });
    const y = ids(url);
    if (!y) return page(url);
    if (y.list && (!y.v || await wholeList())) { const p = await playlist(y.list); if (p) return p; }
    if (y.v) { const v = await video(y.v); if (v) return v; }
    if (y.channel) { const c = await page(y.channel); if (c) return { ...c, author: c.title, title: "", platform: "YouTube", cover: "" }; }
    const o = asJson(await GET(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(url)}`));
    return o ? { kind: "video", title: o.title || "", author: o.author_name || "", platform: "YouTube", link: url, cover: o.thumbnail_url || "", secs: 0, from: "", lessons: [] } : null;
  }
  return { read, ids, isbnOf };
})();
const splitCourse = (() => {
  const pad = n => String(n).padStart(2, "0");
  const hms = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h}:${pad(m)}:${pad(s % 60)}` : `${m}:${pad(s % 60)}`; };
  const secsOf = t => { const p = String(t || "").trim().split(":").map(Number); return p.length > 1 && p.every(n => n >= 0) ? p.reduce((a, n) => a * 60 + n, 0) : 0; };
  const idOf = u => { const m = /youtu\.be\/([\w-]{11})|[?&]v=([\w-]{11})/.exec(u || ""); return m ? m[1] || m[2] : ""; };
  const at = (base, s) => { const id = idOf(base); return id ? `https://youtu.be/${id}${s ? "?t=" + Math.round(s) : ""}` : ""; };
  const startOf = l => +(/[?&]t=(\d+)/.exec(l.url || "") || [])[1] || 0;
  function fromList(text, base, total) {
    const out = []; let part = "";
    fromList.dropped = 0;
    for (const raw of String(text || "").split(/\r?\n/)) {
      let t = raw.replace(/^\s*(?:[-*•]|\d+[.)])\s+/, "").replace(/^[^\p{L}\p{N}([#]+/u, "").trim();
      if (!t) continue;
      if (/^#+\s*/.test(t)) { part = t.replace(/^#+\s*/, "").trim(); continue; }
      let start = null, secs = 0, pages = null, m;
      if ((m = /^[([]?((?:\d{1,2}:)?\d{1,2}:\d{2})[)\]]?\s*[-–—:|.)]*\s*(.*)$/.exec(t))) { start = secsOf(m[1]); t = m[2]; }
      else if ((m = /^(.*?)\s*[([]?((?:\d{1,2}:)?\d{1,2}:\d{2})[)\]]?\s*$/.exec(t)) && m[1]) { start = secsOf(m[2]); t = m[1]; }
      if ((m = /\s*[(•·,–—-]?\s*(?:pp?\.|pages?)\s*(\d+)\s*[–-]\s*(\d+)\s*\)?\s*$/i.exec(t))) { pages = [+m[1], +m[2]]; t = t.slice(0, m.index); }
      if ((m = /\s*[(•·,–—-]?\s*(?:(\d+)\s*(?:h|hr|hrs|hour|hours)\b)?\s*(?:(\d+)\s*(?:m|min|mins|minute|minutes)\b)?\s*\)?\s*$/i.exec(t)) && (m[1] || m[2])) { secs = ((+m[1] || 0) * 60 + (+m[2] || 0)) * 60; t = t.slice(0, m.index); }
      t = t.replace(/[\s\-–—:|]+$/, "").trim();
      if (t) out.push({ t, part, start, secs, pages });
    }
    if (out.some(l => l.start != null)) {
      const timed = out.filter(l => l.start != null).sort((a, b) => a.start - b.start);
      fromList.dropped = out.length - timed.length;
      timed.forEach((l, i) => { const next = timed[i + 1]; l.secs = next ? next.start - l.start : total ? Math.max(0, total - l.start) : l.secs; l.url = at(base, l.start); });
      return timed.map(({ t, part, secs, url }) => ({ t, part, secs, url }));
    }
    return out.map(({ t, part, secs, pages }) => ({ t, part, secs, pages, url: "" }));
  }
  function gather(lessons, mins) {
    const out = []; let cur = null;
    for (const l of lessons) {
      if (!cur || (cur.secs >= 60 && cur.secs + l.secs > mins * 60 * 1.15)) { cur = { first: l, last: l, secs: 0, url: l.url, part: l.part || "", moments: [] }; out.push(cur); }
      cur.last = l; cur.secs += l.secs || 0; cur.moments.push({ at: startOf(l), t: l.t, url: l.url });
    }
    return out.map(g => ({ t: g.first === g.last ? g.first.t : `${g.first.t} … ${g.last.t}`, part: g.part, secs: g.secs, url: g.url, moments: g.moments.length > 1 ? g.moments : [] }));
  }
  function every(base, total, mins) {
    const out = [], step = mins * 60;
    for (let s = 0, n = 1; s < total; s += step, n++) out.push({ t: `Part ${n} · ${hms(s)}–${hms(Math.min(total, s + step))}`, part: "", secs: Math.min(step, total - s), url: at(base, s) });
    return out;
  }
  const parts = (lessons, n) => lessons.map((l, i) => { const a = Math.floor(i / n) * n + 1, b = Math.min(lessons.length, a + n - 1); return { ...l, part: `Part ${Math.floor(i / n) + 1} · ${a === b ? "video " + a : `videos ${a}–${b}`}` }; });
  return { fromList, gather, every, parts, hms, secsOf, idOf };
})();


const abort = async why => { new Notice(why); try { await app.vault.delete(tp.config.target_file); } catch (e) {} };
const isLink = s => /^https?:\/\/\S+$/i.test(String(s || "").trim()) || !!readLink.isbnOf(s);
let got = null;
const readIt = async url => {
  const busy = new Notice("Reading the link…", 0);
  try {
    got = await readLink.read(url, async () => (await tp.system.suggester(
      ["The whole playlist", "Only this video"], [true, false], false, "This video is in a playlist")) !== false);
  } finally { busy.hide(); }
  if (!got) new Notice("Nothing could be read from that page. The link is kept; type the rest.");
  else if (got.link) link = got.link;
};

const first = ((await tp.system.prompt("Title of Book/Media — or paste its link, or a book's ISBN")) || "").trim();
if (!first) return abort("Title cannot be empty. Template aborted.");
let link = isLink(first) ? first : "";
if (link) await readIt(link);
let source = link ? ((await tp.system.prompt(got && got.title ? "Title — as the page gives it" : "Title — the page did not give one", (got && got.title) || "")) || "").trim() : first;
if (!source) return abort("Title cannot be empty. Template aborted.");

const TYPES = [["🎬 Movie", "movie"], ["📺 Show", "show"], ["📖 Book", "book"], ["🎓 Course", "course"], ["🎥 Video", "video"],
  ["📰 Article", "article"], ["🎙️ Podcast", "podcast"], ["🎵 Album", "album"], ["🎮 Game", "game"]];
const lead = got && got.platform === "YouTube" ? ["course", "video"] : got && got.kind === "book" ? ["book", "course"] : [];
const order = [...lead.map(k => TYPES.find(t => t[1] === k)), ...TYPES.filter(t => !lead.includes(t[1]))];
const sourceType = (await tp.system.suggester(order.map(t => t[0]), order.map(t => t[1]), false, "What type of media is this?")) || "book";

if (sourceType === "course" && !link) {
  const l = ((await tp.system.prompt("Its link — a YouTube video or playlist, or a book's ISBN, writes the syllabus (blank to skip)")) || "").trim();
  if (isLink(l)) { link = l; await readIt(l); }
}

let lessons = null, splitSaid = "";
if (sourceType === "course") {
  const R0 = got || {}, L0 = R0.lessons || [], total = R0.secs || 0, video = R0.kind === "video";
  const opts = [];
  const cut = ["Cut into parts every so many minutes", "every"], paste = ["Timestamps I paste — from its description, a comment, or my own", "paste"], one = ["The whole video, one lesson", "one"];
  if (video && R0.from) opts.push([`Its ${L0.length} chapters, a lesson each`, "as"], ["Its chapters, gathered into sittings of about the same length", "gather"], paste, one, ...(total > 25 * 60 ? [["Cut into parts every so many minutes, not by its chapters", "every"]] : []));
  else if (video) opts.push(...(total > 25 * 60 ? [cut, paste, one] : [one, paste]));
  if (R0.kind === "playlist") opts.push([`Each of its ${L0.length} videos a lesson`, "as"], ["Its videos in parts", "parts"]);
  if (R0.kind === "book" && R0.from) opts.push([`Its ${L0.length} chapters, as its contents give them`, "as"]);
  if (!video && R0.kind !== "playlist") opts.push(["A list of lessons I paste — a line a lesson, # for a part", "paste"], ["None yet: I will write them in the note", "none"]);
  const how = (await tp.system.suggester(opts.map(o => o[0]), opts.map(o => o[1]), false, "The lessons")) || opts[0][1];
  if (how === "gather") {
    const m = (await tp.system.suggester(["about 15 minutes", "about 20 minutes", "about 30 minutes", "about 45 minutes", "about an hour"], [15, 20, 30, 45, 60], false, "A sitting of")) || 30;
    lessons = splitCourse.gather(L0, m); splitSaid = `from the video's chapters, gathered into sittings of about ${m} minutes`;
  } else if (how === "every") {
    const m = (await tp.system.suggester(["10 minutes", "15 minutes", "20 minutes", "30 minutes", "45 minutes", "an hour"], [10, 15, 20, 30, 45, 60], false, "A part every")) || 20;
    lessons = splitCourse.every(link, total, m); splitSaid = `by cutting the video every ${m} minutes`;
  } else if (how === "parts") {
    const n = (await tp.system.suggester(["5 videos", "10 videos", "20 videos"], [5, 10, 20], false, "A part of")) || 10;
    lessons = splitCourse.parts(L0, n); splitSaid = `from the playlist, in parts of ${n} videos`;
  } else if (how === "paste") {
    const text = (await tp.system.prompt("The lessons, a line each. A time at the start (1:05:00) is where it begins in the video; a length at the end (45m, 1h 30m) or pages (pp. 12–30) is kept; # starts a part.", "", false, true)) || "";
    lessons = splitCourse.fromList(text, link, total);
    splitSaid = video ? "from timestamps you pasted" : "from a list you pasted";
    if (!lessons.length && L0.length) { lessons = null; splitSaid = ""; }
    const dropped = splitCourse.fromList.dropped;
    if (dropped) new Notice(`${dropped} ${dropped === 1 ? "line with no time was" : "lines with no time were"} left out, as headings of the list.`);
  } else if (how === "one") {
    lessons = [{ t: (got && got.title) || source, part: "", secs: total, url: splitCourse.idOf(link) ? `https://youtu.be/${splitCourse.idOf(link)}` : "" }]; splitSaid = "as one lesson, the whole video";
  } else if (how === "none") lessons = [];
}

let category = "";
if (sourceType === "course") {
  const seen = new Map();
  for (const f of app.vault.getMarkdownFiles()) {
    if (!f.path.startsWith("01_Zettelkasten/Literature/")) continue;
    const fm = (app.metadataCache.getFileCache(f) || {}).frontmatter || {};
    if (fm.type !== "course" && ![].concat(fm.tags || []).some(t => /^#?course\//.test(String(t)))) continue;
    let c = fm.category != null ? fm.category : fm.genre;
    if (c == null) { const m = (await app.vault.cachedRead(f)).match(/^\s*-?\s*(?:category|genre)::[ \t]*(\S.*)$/m); c = m && m[1]; }
    for (const v of [].concat(c || [])) {
      const s = String(v).replace(/^\[\[|\]\]$/g, "").trim(), k = s.toLowerCase();
      if (s) seen.set(k, [(seen.get(k) || [s])[0], ((seen.get(k) || [])[1] || 0) + 1]);
    }
  }
  const known = [...seen.values()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  const NEW = { new: true }, NONE = { none: true };
  const pick = known.length ? await tp.system.suggester(
    [...known.map(([c, n]) => `${c}   · ${n} course${n === 1 ? "" : "s"}`), "+  A new category", "–  None for now"],
    [...known.map(([c]) => c), NEW, NONE], false, "Category") : NEW;
  if (pick === NEW) category = ((await tp.system.prompt("Category — a new one joins the list next time")) || "").trim();
  else if (typeof pick === "string") category = pick;
}

const status = (await tp.system.suggester(
  ["📥 Queue (To Consume)", "▶️ Active (Consuming)", "✅ Done (Finished)", "❌ Dropped (Did Not Finish)"],
  ["queue", "active", "done", "dropped"], false, "Current Status?")) || "queue";

let rating = "";
if (status === "done" || status === "dropped") {
  rating = (await tp.system.suggester(
    ["⭐ 10 — Masterpiece", "⭐ 9 — Excellent", "⭐ 8 — Great", "⭐ 7 — Very good", "⭐ 6 — Good",
     "⭐ 5 — OK", "⭐ 4 — Mediocre", "⭐ 3 — Bad", "⭐ 2 — Very bad", "⭐ 1 — Terrible", "Skip"],
    [10, 9, 8, 7, 6, 5, 4, 3, 2, 1, ""], false, "Rating?")) ?? "";
}
const watched = (sourceType === "movie" && status === "done") ? tp.date.now("YYYY-MM-DD") : "";
const finished = status === "done" ? tp.date.now("YYYY-MM-DD") : "";

const R = got || {};
const author = R.author || "", platform = R.platform || "", cover = R.cover || "";
const minutes = R.secs ? Math.round(R.secs / 60) : "";
const yaml = v => { v = String(v == null ? "" : v).trim(); return !v ? "" : /[:#\[\]{}&*!|>'"%@`,?]|^[-\s]/.test(v) ? JSON.stringify(v) : v; };
const len = s => { const m = Math.max(1, Math.round(s / 60)); return m >= 60 ? `${Math.floor(m / 60)}h${m % 60 ? " " + (m % 60) + "m" : ""}` : `${m}m`; };

const hms = s => { const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), p = n => String(n).padStart(2, "0"); return h ? `${h}:${p(m)}:${p(s % 60)}` : `${m}:${p(s % 60)}`; };
const heading = t => String(t || "").replace(/\s+/g, " ").replace(/^#+\s*/, "").trim() || "Untitled";
const safeName = s => String(s || "").replace(/\s+[-|]\s+|:\s+/g, " — ").replace(/\[/g, "(").replace(/\]/g, ")").replace(/[\\/]/g, "-")
  .replace(/[:*?"<>|#^]/g, "").replace(/\s+/g, " ").trim();
const fileName = safeName(source);
const L = lessons || R.lessons || [], width = Math.max(2, String(L.length).length);
const ownNotes = sourceType === "course" && L.length > 0 && R.kind !== "book" && R.kind !== "video" && !L.some(l => /[?&]t=\d/.test(l.url || "") || l.pages);
const lessonDir = `01_Zettelkasten/Literature/${fileName}`;
const lessonName = (l, i) => `${fileName} · ${String(i + 1).padStart(width, "0")} ${safeName(heading(l.t))}`.slice(0, 180).trim();
const alias = t => heading(t).replace(/\|/g, "·").replace(/[[\]]/g, "");
const box = `- [${status === "done" ? "x" : " "}]`;
let lastPart = "";
const sections = L.map((l, i) => {
  const at = /[?&]t=(\d+)/.exec(l.url || ""), part = l.part || "", anchor = `^l${String(i + 1).padStart(width, "0")}`;
  const where = l.url ? `[${at ? "watch from " + hms(+at[1]) : "watch"}](${l.url})` : l.pages ? `pages ${l.pages[0]}–${l.pages[1]}` : "";
  const head = part && part !== lastPart ? `${ownNotes && i ? "\n" : ""}### ${heading(part)}\n\n` : "";
  lastPart = part;
  if (ownNotes) return head + [box, `[[${lessonName(l, i)}|${alias(l.t)}]]`, l.url ? `· [watch](${l.url})` : "", l.secs ? `(${len(l.secs)})` : "", anchor].filter(Boolean).join(" ");
  const line = [box, where, l.secs ? `(${len(l.secs)})` : "", anchor].filter(Boolean).join(" ");
  const moments = (l.moments || []).map(m => `- [${hms(m.at)}](${m.url}) ${m.t}`).join("\n");
  return `${head}${part ? "####" : "###"} ${heading(l.t)}\n${line}${moments ? "\n\n" + moments : ""}`;
}).join(ownNotes ? "\n" : "\n\n");
const syllabus = sections ? "\n" + sections + "\n" : "";
const readOn = tp.date.now("D MMM YYYY");
const each = ownNotes
  ? `Each lesson has its own note, in the folder ${lessonDir}, linked from its line: write in it — notes, moments, questions, cards. Tick the line here when it is done. The ^l anchor at the end of a line is how links and the Courses view find the lesson, and it stays when a note is renamed.`
  : "Each lesson is a section: under its line go your notes, links to permanent notes and its cards. The ^l anchor at the end of the line is how links and the Courses view find it, and it stays when the heading is renamed.";
const secsAll = L.reduce((a, l) => a + (l.secs || 0), 0);
const syllabusNote = !sections
  ? `A lesson is a heading with a line under it — ### Lecture 1, then - [ ] (45m) ^l01 — and a heading above a run of lessons is their part. ${each}`
  : splitSaid ? `Written on ${readOn} ${splitSaid}: ${L.length} lessons${secsAll ? ", " + len(secsAll) : ""}. ${each}`
  : R.from === "chapters" ? `Written on ${readOn} from the video's chapters: ${L.length} lessons, ${len(R.secs)}; each opens the video where it starts. ${each}`
  : R.from === "description" ? `Written on ${readOn} from the timestamps in the video's description: ${L.length} lessons, ${len(R.secs)}; each opens the video where it starts. ${each}`
  : R.from === "playlist" ? `Written on ${readOn} from the playlist: ${L.length} videos, ${len(R.secs)}. A ### heading above a run of them makes a part. ${each}`
  : R.from === "contents" ? `Written on ${readOn} from the book's contents${R.other ? ` as another edition gives them (openlibrary.org${R.other})` : ""}: ${L.length} lessons${R.pages ? `, ${R.pages} pages` : ""}. Remove what you will not read. ${each}`
  : R.kind === "book" ? `The book's contents are not on Open Library, so it is one lesson; a heading and a line for each chapter make it a syllabus. ${each}`
  : `The video has no chapters, so it is one lesson. More sections like it, each linked with its own ?t= (seconds), make stops along it. ${each}`;
const lessonNote = (l, i) => `---
created: ${created}
type: lesson
course: "[[${fileName}]]"
lesson: ${i + 1}
link: ${yaml(l.url || "")}
minutes: ${l.secs ? Math.round(l.secs / 60) : ""}
tags:
  - literature
  - course/lesson
cssclasses:
  - course-lesson
---
%% A lesson of the course in its properties. Write here: notes; a moment as a line that starts with its link, - [4:40](the video's link with &t=280) and what it says; a > [!question]; a > [!card]- with its answer on the > lines under it. The course's note holds the tick. %%
${(l.moments || []).length ? "\n" + l.moments.map(m => `- [${hms(m.at)}](${m.url}) ${m.t}`).join("\n") + "\n" : ""}`;

const tagsStr = ["literature", `${sourceType}/${status}`].map(t => "  - " + t).join("\n");

await tp.file.move(`/01_Zettelkasten/Literature/${fileName}`);
if (ownNotes) {
  try { await app.vault.createFolder(lessonDir); } catch (e) {}
  let made = 0;
  for (const [i, l] of L.entries()) {
    const path = `${lessonDir}/${lessonName(l, i)}.md`;
    if (app.vault.getAbstractFileByPath(path)) continue;
    try { await app.vault.create(path, lessonNote(l, i)); made++; } catch (e) {}
  }
  new Notice(`${made} lesson ${made === 1 ? "note" : "notes"} made in ${lessonDir}`);
}
_%>---
id: <% id %>
created: <% created %>
<%* if (sourceType === "course") { _%>
type: course
status: <% status %>
author: <% yaml(author) %>
platform: <% yaml(platform) %>
category: <% yaml(category) %>
link: <% yaml(link) %>
cover: <% yaml(cover) %>
minutes: <% minutes %>
due: 
rating: <% rating %>
finished: <% finished %>
certificate: 
tags:
<% tagsStr %>
cssclasses:
  - course
---
> [!abstract] In one line
> <% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Syllabus
%% <% syllabusNote %> %%
<% syllabus -%>

## Cards
%% Cards for the whole course; a lesson's own go in its section, or in its note. A card is a callout: > [!card]- the question, and the answer on the > lines under it. > [!card|both]- asks it both ways, and ==words== in a question make it a gap to fill. The Courses view asks them when they are due and writes when to ask again at the end of the question, hidden. %%

## Takeaways
%% A line each, in your own words. %%

## Atomic notes spawned
%% Write the atomic note, link back to this one from inside it, and it appears in the backlinks. %%
<%* } else { _%>
type: literature
tags:
<% tagsStr %>
---
# <% source %>

<%* if (sourceType === "movie") { _%>
## Reference
- type:: movie
- status:: <% status %>
- author:: 
- year:: 
- runtime:: 
- genres:: 
- rating:: <% rating %>
- episode:: 
- watched:: <% watched %>
- rewatched:: 
- synopsis:: 
- cast:: 
- banner:: 
- banner_url:: 
- poster:: 
- poster_url:: 
- trailer:: 
- link:: <% link %>

## My take
<% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Memorable Lines
*Format: `quote:: "the actual line"`. One per line.*
- quote:: 

## Gallery
*Wallpapers & key art. Format: `art:: <image-url>`. One per line.*
- art:: 

## Links
*Edits, scenes, essays. Format: `watch:: [title](url)` or just a url.*
- watch:: 

## Atomic notes spawned
*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*

> [!tip]- 🎬 One button does the rest
> Open this note with the **Movie view** and press **⟡ fetch from the web** — director, year, runtime, genres, synopsis, poster, banner, and cast fill themselves (TMDB if a key sits in Vault Settings as `tmdb_api_key`, otherwise Wikipedia). Fetch only fills blanks — anything you type by hand is never overwritten. Images cache to `04_Attachments/Media/`; the `_url` twins remain as fallback if you ever delete them.
<%* } else if (sourceType === "show") { _%>
## Reference
- type:: show
- status:: <% status %>
- author:: 
- year:: 
- genres:: 
- genre:: 
- rating:: <% rating %>
- episode:: 
- progress:: 
- synopsis:: 
- cast:: 
- poster:: 
- poster_url:: 
- link:: <% link %>

## My take
<% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Memorable Lines
- quote:: 

## Atomic notes spawned
*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*
<%* } else if (sourceType === "book") { _%>
## Reference
- type:: book
- status:: <% status %>
- author:: <% author %>
- genre:: 
- rating:: <% rating %>
- page:: 
- pages:: <% R.pages || "" %>
- link:: <% link %>

## Summary
*2-3 sentences in your own words.*
<% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Key Points

## Quotes
- quote:: 

## Atomic notes spawned
*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*
<%* } else if (sourceType === "album") { _%>
## Reference
- type:: album
- status:: <% status %>
- author:: <% author %>
- genre:: 
- rating:: <% rating %>
- length:: <% minutes %>
- link:: <% link %>

## Overall Vibe
*2-3 sentences describing the sound and feel of the album.*
<% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Standout Tracks

## Favorite Lyrics
- quote:: 

## Atomic notes spawned
*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*
<%* } else { _%>
## Reference
- type:: <% sourceType %>
- status:: <% status %>
- author:: <% author %>
- genre:: 
- rating:: <% rating %>
- progress:: 
- length:: <% minutes %>
- platform:: <% platform %>
- link:: <% link %>

## Summary
*2-3 sentences in your own words.*
<% selectedText ? selectedText : "" %><% tp.file.cursor() %>

## Key Points

## Quotes
- quote:: 

## Atomic notes spawned
*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*
<%* } _%>
<%* } _%>
