<%*
const DOMAINS = [
  { e: "🎨", n: "Art" },            { e: "🏢", n: "Business" },
  { e: "💬", n: "Communication" },  { e: "🧠", n: "EQ" },
  { e: "💰", n: "Finance" },        { e: "🩺", n: "Health" },
  { e: "📜", n: "History" },        { e: "💻", n: "Infrastructure" },
  { e: "🗣️", n: "Languages" },      { e: "📣", n: "Marketing" },
  { e: "🧮", n: "Maths" },          { e: "🧘", n: "Philosophy" },
  { e: "🌐", n: "Physics" },        { e: "⚡", n: "Productivity" },
  { e: "⌨️", n: "Programming" },    { e: "🧠", n: "Psychology" },
  { e: "🕯️", n: "Religion" },       { e: "✍️", n: "Writing" },
];
const abort = async msg => {
  new Notice(msg);
  try { await app.vault.delete(tp.config.target_file); } catch (e) {}
};

const selectedText = tp.file.selection();

const title = await tp.system.prompt("Title");
if (title === null || !title.trim()) { await abort("Note creation cancelled."); return; }

const tLow = title.trim().toLowerCase();
const twin = app.vault.getMarkdownFiles().find(f => {
  const b = f.basename.toLowerCase();
  return b === tLow || b.endsWith(" - " + tLow);
});
if (twin) {
  const go = await tp.system.suggester(
    [`⚠️ "${twin.basename}" exists — create anyway`, "✕ Cancel"],
    ["go", "stop"], false, "A note with this title already exists");
  if (go !== "go") { await abort("Cancelled — no twin created."); return; }
}

const noteType = await tp.system.suggester(
  ["📝 Standard Permanent Note", "🗺️ Hub Note (Sub-MOC)"],
  ["standard", "moc"], false, "Standard note or Hub?");
if (noteType === null) { await abort("Note creation cancelled."); return; }

const id = tp.date.now("YYYYMMDDHHmmss");
const name = `${id} - ${title.trim()}`;
await tp.file.move(`/01_Zettelkasten/Permanent/${name}`);

let parentMocBreadcrumb = "", parentMocTag = "";
async function pickMoc() {
  const sel = await tp.system.suggester(
    [...DOMAINS.map(d => `${d.e} ${d.n}`), "❌ None / Independent"],
    [...DOMAINS.map(d => d.n), ""], false, "Parent MOC dashboard:");
  if (sel) {
    parentMocBreadcrumb = `> [[MOC - ${sel}|↑ Back to ${sel}]]`;
    parentMocTag = sel.toLowerCase();
  }
}
if (noteType === "moc") await pickMoc();

const tagCounts = app.metadataCache.getTags();
let existingTags = Object.entries(tagCounts)
  .map(([t, c]) => ({ t: t.replace(/^#/, ""), c }))
  .filter(x => !/^(permanent$|moc$|task$|study$|review\/)/.test(x.t))
  .sort((a, b) => b.c - a.c || a.t.localeCompare(b.t))
  .map(x => x.t);

let userTags = [];
if (parentMocTag) userTags.push(parentMocTag);

while (true) {
  const disp = ["✅ Done adding tags", "➕ Type a new tag…",
    ...existingTags.map(t => userTags.includes(t) ? `✔️ ${t}` : t)];
  const vals = ["DONE", "NEW", ...existingTags];
  const pick = await tp.system.suggester(disp, vals, false, "Tags — Esc to finish");
  if (!pick || pick === "DONE") break;
  if (pick === "NEW") {
    const nt = await tp.system.prompt("New tag (no #, e.g. maths/algebra)");
    if (nt && nt.trim()) {
      const c = nt.trim().replace(/^#/, "");
      if (!userTags.includes(c)) userTags.push(c);
      if (!existingTags.includes(c)) existingTags.unshift(c);
    }
  } else if (!userTags.includes(pick)) userTags.push(pick);
}

const FEATURES = [
  { id: "tasks",   label: "📝 Tasks — feeds the Home Dashboard" },
  { id: "recall",  label: "🔁 Active recall Q&A" },
  { id: "related", label: "🔗 Related notes" },
  { id: "source",  label: "📖 Source line" },
  { id: "quote",   label: "❝ Quote / excerpt" },
  { id: "alias",   label: "🏷️ Alias" },
  ...(noteType === "standard" ? [{ id: "moclink", label: "🧭 Parent MOC breadcrumb" }] : []),
];
let picked = [];
while (true) {
  const disp = ["✅ Done — build the note",
    ...FEATURES.map(f => picked.includes(f.id) ? `✔️ ${f.label}` : f.label)];
  const vals = ["DONE", ...FEATURES.map(f => f.id)];
  const pick = await tp.system.suggester(disp, vals, false, "Add features — Esc for minimal");
  if (!pick || pick === "DONE") break;
  picked.includes(pick) ? picked.splice(picked.indexOf(pick), 1) : picked.push(pick);
}

if (picked.includes("moclink") && !parentMocTag) {
  await pickMoc();
  if (parentMocTag && !userTags.includes(parentMocTag)) userTags.push(parentMocTag);
}
let alias = "";
if (picked.includes("alias")) alias = (await tp.system.prompt("Alias")) || "";
let quote = "";
if (picked.includes("quote")) quote = (await tp.system.prompt("Quote / excerpt")) || "";
let sourceLine = "";
if (picked.includes("source")) sourceLine = (await tp.system.prompt("Source (title, author, URL…)")) || "";

let related = [];
if (picked.includes("related")) {
  const pool = [...new Set(app.vault.getMarkdownFiles()
    .filter(f => (f.path.startsWith("01_Zettelkasten/") || f.basename.startsWith("MOC - "))
      && f.basename !== tp.config.target_file.basename)
    .map(f => f.basename))].sort();
  while (true) {
    const disp = ["✅ Done linking", ...pool.map(b => related.includes(b) ? `✔️ ${b}` : b)];
    const vals = ["DONE", ...pool];
    const pick = await tp.system.suggester(disp, vals, false, "Related notes — Esc to finish");
    if (!pick || pick === "DONE") break;
    related.includes(pick) ? related.splice(related.indexOf(pick), 1) : related.push(pick);
  }
}

let tagsArr = ["permanent"];
if (noteType === "moc") tagsArr.push("moc");
let breadcrumbs = [];
if (parentMocBreadcrumb) breadcrumbs.push(parentMocBreadcrumb);
const lowerDomains = DOMAINS.map(d => d.n.toLowerCase());
userTags.forEach(t => {
  if (!tagsArr.includes(t)) tagsArr.push(t);
  const root = t.split("/")[0].toLowerCase();
  const idx = lowerDomains.indexOf(root);
  if (idx !== -1) {
    const bc = `> [[MOC - ${DOMAINS[idx].n}|↑ Back to ${DOMAINS[idx].n}]]`;
    if (!breadcrumbs.includes(bc)) breadcrumbs.push(bc);
  }
});
if (noteType === "standard" && !related.length && !breadcrumbs.length) tagsArr.push("review/orphan");

const tagsYaml = "tags:\n" + tagsArr.map(t => "  - " + t).join("\n");
const aliasYaml = alias ? `\naliases:\n  - ${alias}` : "";
const crumbOut = breadcrumbs.length ? breadcrumbs.join(" | ") + "\n\n" : "";

const ideaOut = selectedText
  ? selectedText
  : "*Write the idea in your own words — what it is, why it matters, where it connects.*";

let modules = "";
if (quote) modules += `\n\n> ${quote.replace(/\n/g, "\n> ")}`;
if (picked.includes("tasks")) {
  modules += noteType === "moc"
    ? `\n\n## Objectives\n- [ ]  #task #study 📅 ${tp.date.now("YYYY-MM-DD")}`
    : `\n\n## Tasks\n- [ ]  #task #study 📅 ${tp.date.now("YYYY-MM-DD")}`;
}
if (picked.includes("recall")) modules += `\n\n## Recall\n**Q:** \n**A:** `;
if (related.length) modules += `\n\n## Related\n` + related.map(r => `- [[${r}]]`).join("\n");
if (sourceLine) modules += `\n\n**Source:** ${sourceLine}`;

let hubBody = "";
if (noteType === "moc") {
  const aggregateTag = userTags.length ? userTags[userTags.length - 1] : (parentMocTag || "your-tag-here");
  hubBody = `\n\n## Knowledge Base\n\`\`\`dataview\nTABLE WITHOUT ID\n  file.link AS "Notes",\n  type AS "State"\nFROM #${aggregateTag}\nWHERE file.name != this.file.name\nSORT file.name ASC\n\`\`\``;
}
_%>---
id: <% id %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %><% aliasYaml %>
type: <% noteType === "moc" ? "MOC" : "permanent" %>
<% tagsYaml %>
---
<% crumbOut %># <% title %>

<% noteType === "moc" ? "*The hub for this territory — child notes gather below.*" : ideaOut %><% tp.file.cursor() %><% hubBody %><% modules %>