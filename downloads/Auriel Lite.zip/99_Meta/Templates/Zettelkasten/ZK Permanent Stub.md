<%*
_%>---
id: <% tp.date.now("YYYYMMDDHHmmss") %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
type: permanent
tags:
  - permanent
---
# <% tp.file.title %>

<% tp.file.cursor() %>
