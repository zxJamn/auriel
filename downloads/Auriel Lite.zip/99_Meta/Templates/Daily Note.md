<%*
const iso = /^\d{4}-\d{2}-\d{2}$/.test(tp.file.title) ? tp.file.title : tp.date.now("YYYY-MM-DD");
const SFILE = app.vault.getAbstractFileByPath("99_Meta/Vault Settings.md");
const VS = SFILE ? (app.metadataCache.getFileCache(SFILE)?.frontmatter ?? {}) : {};
const clean = s => { const m = String(s || "").trim().match(/^(\d{1,2})[:.](\d{2})$/);
  return m && +m[1] < 24 && +m[2] < 60 ? String(+m[1]).padStart(2, "0") + ":" + m[2] : ""; };
const dow = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"][new Date(iso + "T12:00:00").getDay()];
const sched = key => (Array.isArray(VS[key]) ? VS[key] : []).find(r =>
  String(r.days || "").toLowerCase().split(/[,\s]+/).includes(dow) && clean(r.start));
const blocks = [
  ["job", "work_schedule", VS.working !== false],
  ["study", "study_schedule", VS.studying !== false],
  ["training", "training_schedule", true],
];
const times = [];
blocks.forEach(([name, key, on]) => { const r = on ? sched(key) : null;
  if (r) times.push([name + "_start", clean(r.start)], [name + "_end", clean(r.end)]); });
const lines = times.filter(([, v]) => v);
try {
  const mod = app.vault.getFiles().find(f => /^Vault-Module\.md$/i.test(f.name));
  if (mod) {
    const raw = await app.vault.read(mod), fence = raw.match(/```(?:js|javascript)\s*\n([\s\S]*?)```/);
    const NV = new Function((fence ? fence[1] : raw) + "\nreturn typeof VAULT_MODULE !== 'undefined' ? VAULT_MODULE : null;")();
    if (NV && NV.loadPacks) await NV.loadPacks(app);
    const G = NV && NV.pack ? NV.pack("gym") : null;
    const g = G ? await G.gym.day(app, iso, tp.date.now("YYYY-MM-DD")) : null;
    if (g && g.session && !g.rest && g.type && g.type !== "rest") lines.push(["training", g.type]);
  }
} catch (e) { console.error("[daily note template] the day's session", e); }
-%>
---
type: daily
date: <% iso %>
<% lines.map(([k, v]) => `${k}: "${v}"`).join("\n") %>
tags:
  - daily
---
