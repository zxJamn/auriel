<%*
const mod = await (async () => {
  for (const f of app.vault.getFiles().filter(f => /^Vault-Module\.md$/i.test(f.name))) {
    try {
      const raw = await app.vault.read(f), src = (raw.match(/`{3}(?:js|javascript)\s*\n([\s\S]*?)`{3}/) || [, raw])[1];
      const m = new Function(src + "\nreturn typeof VAULT_MODULE !== 'undefined' ? VAULT_MODULE : null;")();
      if (m && m.maps && typeof m.askHome === "function") return { M: m, note: raw };
    } catch (e) {}
  }
  return null;
})();
const me = tp.config.target_file, title = tp.file.title;
if (!mod) new Notice(`${title} · no home yet: the core module was not found`);
else {
  const { M, note } = mod, I = M.maps.index(app, tp.date.now("YYYY-MM-DD"));
  const linked = app.metadataCache.resolvedLinks || {}, loose = app.metadataCache.unresolvedLinks || {};
  const linking = new Set([...Object.keys(linked).filter(p => linked[p][me.path]),
    ...Object.keys(loose).filter(p => Object.keys(loose[p]).some(l => l.split("/").pop().toLowerCase() === title.toLowerCase()))]);
  linking.delete(me.path);
  const recent = app.workspace.getLastOpenFiles ? app.workspace.getLastOpenFiles() : [];
  const from = recent.find(p => linking.has(p)) || [...linking][0] || null;
  const at = from ? I.byPath(from) || I.home(from) : null;
  const guesses = [...(at ? [{ map: at, why: `where ${from.split("/").pop().replace(/\.md$/, "")} lives` }] : []),
    ...M.maps.guessForText(I, { title }).filter(g => !at || g.map.path !== at.path)];
  const target = await M.askHome(app, { title, guesses }, note);
  if (!target) new Notice(`${title} · no home yet, it waits in Unfiled`);
  else tp.hooks.on_all_templates_executed(async () => {
    try { const r = await M.maps.setHome(app, [me], target); new Notice(String(r.why || r.said).replace(/<[^>]+>/g, "")); }
    catch (e) { new Notice(`${title} · no home: ${(e && e.message) || e}`); }
  });
}
_%>---
id: <% tp.date.now("YYYYMMDDHHmmss") %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
type: permanent
tags:
  - permanent
---
# <% tp.file.title %>

<% tp.file.cursor() %>
