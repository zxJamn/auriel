---
type: vault-module
---

# Vault-Module

The core every view in this vault is drawn with: the popover and its palette, the marks, the tabs,
the dock and the settings sheet, the loaders for the chrome and for a pack's module, the day's note
as lines, the command line, and the guard around every renderer. It holds nothing of a pack. A pack
is a note in the Packs folder naming a module beside this one, which joins this one when a view
loads; a vault without that note has no such pack, and the views draw without it.

The first block opens with the shape of a day -- the times a daily note is read by -- and then the
module. The second block is its stylesheet, for everything the views mount on the page body; the
module puts it in place on every load.

**Do not edit these blocks by hand.** The views read them by this note's name every time they load,
and they are replaced whole whenever the vault's code is updated, so anything typed here is lost.

```js
const DAY_SHAPE = (() => {
  const ALIAS = {
    wake: ["wake", "wake_time"],
    sleep: ["sleep", "sleep_time", "bed_time"],
    job_start: ["job_start", "work_start", "shift_start"],
    job_end: ["job_end", "work_end", "shift_end"],
    study_start: ["study_start", "uni_start"], study_end: ["study_end", "uni_end"],
    training_start: ["training_start", "train_start", "gym_start"],
    training_end: ["training_end", "train_end", "gym_end"],
  };
  const WORDS = { training: ["training", "day_type", "daytype", "session"] };
  const WORD = v => String(v == null ? "" : v).trim().toLowerCase().replace(/\s+/g, "_");
  const HHMM = v => { const m = String(v || "").trim().match(/^(\d{1,2})[:.\s]?(\d{2})/);
    if (!m) return ""; const h = +m[1], mi = +m[2];
    return (h > 23 || mi > 59) ? "" : String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0"); };
  function parse(text) {
    const o = {};
    const find = n => {
      const m = String(text || "").match(new RegExp("^[ \\t>]*-?[ \\t]*" + n + "::[ \\t]*(.*)$", "m"));
      return m ? m[1] : null;
    };
    Object.entries(ALIAS).forEach(([k, names]) => {
      for (const n of names) { const v = HHMM(find(n)); if (v) { o[k] = v; break; } }
    });
    Object.entries(WORDS).forEach(([k, names]) => {
      for (const n of names) { const v = WORD(find(n)); if (v) { o[k] = v; break; } }
    });
    return o;
  }
  function of(raw, fm) {
    const f = fm || {}, fromFm = {};
    Object.entries(ALIAS).forEach(([k, names]) => {
      for (const n of names) { const v = HHMM(f[n]); if (v) { fromFm[k] = v; break; } }
    });
    Object.entries(WORDS).forEach(([k, names]) => {
      for (const n of names) { const v = WORD(f[n]); if (v) { fromFm[k] = v; break; } }
    });
    return { ...parse(raw), ...fromFm };
  }
  return { ALIAS, WORDS, HHMM, parse, of };
})();

const VAULT_MODULE = (() => {
  const VERSION = "2.21";

  const SHAPE_IN = typeof DAY_SHAPE !== "undefined" ? DAY_SHAPE : null;
  const REG = { list: [], defs: Object.create(null) };
  let PARTS = null;
  const SHELVED = new Set(["money", "money-tab"]);
  const partOn = name => { const n = String(name).toLowerCase(); return PARTS ? PARTS.has(n) : !SHELVED.has(n); };
  const partsOf = fm => { const p = fm && fm.parts;
    const list = Array.isArray(p) ? p.map(x => String(x).trim().toLowerCase()).filter(Boolean) : [];
    return list.length ? new Set(list) : null; };
  function meets(range, version = VERSION) {
    const v = String(version).split(".").map(Number), r = String(range || "").trim();
    const m = r.match(/^(\^)?(\d+)(?:\.(\d+))?(?:\.(\d+))?$/); if (!m) return false;
    const floor = [+m[2], +(m[3] || 0), +(m[4] || 0)], have = [v[0] || 0, v[1] || 0, v[2] || 0];
    const atLeast = have[0] !== floor[0] ? have[0] > floor[0] : have[1] !== floor[1] ? have[1] > floor[1] : have[2] >= floor[2];
    return m[1] ? have[0] === floor[0] && atLeast : atLeast;
  }
  function frontOf(text) {
    const m = String(text || "").replace(/\r/g, "").match(/^---\n([\s\S]*?)\n---/), out = {};
    if (!m) return out;
    const unq = v => v.trim().replace(/^(["'])(.*)\1$/, "$2");
    let key = null;
    for (const line of m[1].split("\n")) {
      let x;
      if ((x = line.match(/^\s+-\s+(.*)$/)) && key) { if (!Array.isArray(out[key])) out[key] = []; out[key].push(unq(x[1])); }
      else if ((x = line.match(/^\s+([A-Za-z0-9_-]+):\s*(.*)$/)) && key) { if (!out[key] || typeof out[key] !== "object" || Array.isArray(out[key])) out[key] = {}; out[key][x[1]] = unq(x[2]); }
      else if ((x = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/))) {
        key = x[1]; const v = x[2].trim(), flow = v.match(/^\[(.*)\]$/);
        out[key] = v === "" ? "" : flow ? flow[1].split(",").map(unq).filter(s => s !== "") : unq(v);
      }
    }
    return out;
  }
  function register(id, def = {}) {
    id = String(id || "").trim();
    if (!id) return { ok: false, why: "a pack has an id" };
    if (REG.defs[id]) return { ok: false, why: `${id} is registered already` };
    const need = (def.requires || {}).core;
    const entry = { id, version: String(def.version || "0"), ok: true, why: "" };
    const at = REG.list.findIndex(p => p.id === id), list = () => { if (at >= 0) REG.list[at] = entry; else REG.list.push(entry); };
    if (need && !meets(need)) { entry.ok = false; entry.why = `needs core ${String(need).replace(/^\^/, "")}, this is ${VERSION}`; list(); return { ok: false, why: entry.why }; }
    REG.defs[id] = def; list();
    const taken = [];
    try { Object.entries(def.kinds || {}).forEach(([k, fn]) => { if (!(k in kinds)) kinds[k] = fn; else taken.push("kind " + k); }); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { const t = commands.add(def.commands || {}); taken.push(...t); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { Object.entries(def.sources || {}).forEach(([k, s]) => {
      const src = typeof s === "function" ? { label: k, read: s } : s;
      if (!src || typeof src.read !== "function") return;
      if (SOURCES[k] || HABIT_OWN.includes(k)) taken.push("source " + k); else SOURCES[k] = { label: String(src.label || k), read: src.read };
    }); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { (def.rooms || []).forEach(g => { if (g && g.match instanceof RegExp && g.word) ROOM_GROUPS.push({ pack: id, id: String(g.id || id), word: String(g.word), mark: String(g.mark || "door"), match: g.match }); }); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { (def.marks || []).forEach(m => { if (Array.isArray(m) && m[0] instanceof RegExp && typeof m[1] === "string") MARKS.push([m[0], m[1]]); }); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { (def.keys || []).forEach(k => {
      if (!k || !k.key) return;
      if (KEYS.some(x => x.key === k.key)) taken.push("key " + k.key); else KEYS.push(Object.assign({ name: k.key, use: "", hint: "", from: "" }, k, { views: [].concat(k.views || []) }));
    }); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    try { fillersOf(id, def, taken); } catch (e) { entry.ok = false; entry.why = String(e.message || e); }
    return entry.ok ? { ok: true, why: taken.length ? "already taken: " + taken.join(", ") : "" } : { ok: false, why: entry.why };
  }
  const SOURCES = Object.create(null), MARKS = [], ROOM_GROUPS = [], HABIT_OWN = ["journal", "weight"];
  const roomGroups = () => ROOM_GROUPS.filter(g => REG.list.some(p => p.id === g.pack && p.ok));
  const packs = () => REG.list.map(p => ({ ...p }));
  const packDef = id => (REG.defs[id] && REG.list.find(p => p.id === id && p.ok) ? REG.defs[id] : null);

  const FILL = [];
  const SLOT_AT = { pages: "page", settings: "settings", stops: "stops", dates: "dates", progress: "progress" };
  function fillersOf(id, def, taken) {
    const seq = REG.list.findIndex(p => p.id === id);
    for (const slot of ["pages", "settings", "stops", "dates", "progress", "sections"]) {
      for (const f of [].concat(def[slot] || [])) {
        if (!f || typeof f !== "object") continue;
        const at = SLOT_AT[slot] || String(f.at || "");
        const name = `${slot === "pages" ? "page" : slot === "settings" ? "settings" : at} ${f.id || ""}`.trim();
        const fn = slot === "stops" || slot === "dates" || slot === "progress" ? f.read : f.draw;
        if (!at || !f.host || typeof fn !== "function" || (slot === "pages" && (!f.id || typeof f.html !== "string"))) { taken.push(name + ": incomplete"); continue; }
        if ((slot === "pages" || slot === "settings") && FILL.some(x => x.at === at && x.host === f.host && x.id === f.id)) { taken.push(name + ": taken"); continue; }
        FILL.push(Object.assign({}, f, { pack: id, host: String(f.host), at, order: Number(f.order) || 0, seq }));
      }
    }
  }
  const sockets = (host, at) => FILL.filter(x => x.host === host && x.at === at && (!x.part || partOn(x.part)) && (x.pack === "core" || REG.list.some(p => p.id === x.pack && p.ok)))
    .sort((a, b) => a.seq - b.seq || a.order - b.order).map(x => Object.assign({}, x));

  let STORE_MOD = null;
  function storeModule(app) {
    if (STORE_MOD) return STORE_MOD;
    const box = {};
    STORE_MOD = loadModuleOf(app, "Vault-Store", ["draw", "boot", "act"], box, "[Store]").then(S => {
      const css = (String(box.raw || "").match(/`{3}css\s*\n([\s\S]*?)`{3}/) || [])[1];
      if (css && typeof document !== "undefined") {
        let st = document.getElementById("vault-store-style");
        if (!st) { st = document.createElement("style"); st.id = "vault-store-style"; (document.head || document.body).appendChild(st); }
        if (st.textContent !== css) st.textContent = css;
      }
      return S;
    });
    STORE_MOD.catch(() => { STORE_MOD = null; });
    return STORE_MOD;
  }
  const storeOff = s => !!s && (s.store_check === false || String(s.store_check).trim().toLowerCase() === "false");
  FILL.push({ pack: "core", host: "hall", at: "page", id: "store", order: 95, seq: -1, mark: "basket", word: "Store",
    html: `<div class="st-page"><p class="vc-empty">The Store is opening.</p></div>`,
    draw: async ctx => {
      let S;
      try { S = await storeModule(ctx.app); }
      catch (e) {
        const p = ctx.ui && ctx.ui.panel && ctx.ui.panel(), t = ((e && e.tried) || [])[0] || (e && e.message) || String(e);
        if (p) p.innerHTML = `<p class="vc-empty">The Store's note, <b>Vault-Store</b>, could not be read: ${esc(String(t).replace(/^.*? — /, ""))}</p>`;
        return;
      }
      return S.draw(ctx);
    },
    boot: async ctx => { if (storeOff(ctx.settings)) return 0; return (await storeModule(ctx.app)).boot(ctx); } });

  let LONG_MOD = null;
  function longModule(app) {
    if (LONG_MOD) return LONG_MOD;
    const box = {};
    LONG_MOD = loadModuleOf(app, "Vault-Long", ["draw"], box, "[Long]").then(L => {
      const css = (String(box.raw || "").match(/`{3}css\s*\n([\s\S]*?)`{3}/) || [])[1];
      if (css && typeof document !== "undefined") {
        let st = document.getElementById("vault-long-style");
        if (!st) { st = document.createElement("style"); st.id = "vault-long-style"; (document.head || document.body).appendChild(st); }
        if (st.textContent !== css) st.textContent = css;
      }
      return L;
    });
    LONG_MOD.catch(() => { LONG_MOD = null; });
    return LONG_MOD;
  }
  FILL.push({ pack: "core", host: "hall", at: "page", id: "trends", part: "trends", order: 35, seq: -1, mark: "graph", word: "Trends",
    html: `<div class="lv-page"><p class="vc-empty">Trends are being read.</p></div>`,
    draw: async ctx => {
      let L;
      try { L = await longModule(ctx.app); }
      catch (e) {
        const p = ctx.ui && ctx.ui.panel && ctx.ui.panel(), t = ((e && e.tried) || [])[0] || (e && e.message) || String(e);
        if (p) p.innerHTML = `<p class="vc-empty">The long view's note, <b>Vault-Long</b>, could not be read: ${esc(String(t).replace(/^.*? — /, ""))}</p>`;
        return;
      }
      return L.draw(ctx);
    } });

  const esc = s => String(s ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const ICONS = {
    close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    add: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5.5 12h13"/>',
    delete: '<path d="M4.5 6.5h15"/><path d="M9.5 6.5V5A1.5 1.5 0 0 1 11 3.5h2A1.5 1.5 0 0 1 14.5 5v1.5"/><path d="M6.5 6.5l.8 12.1a2 2 0 0 0 2 1.9h5.4a2 2 0 0 0 2-1.9l.8-12.1"/><path d="M10.2 10.5v6M13.8 10.5v6"/>',
    edit: '<path d="M4.5 18.5l3.3-.9L18.2 7.2a2.1 2.1 0 0 0-3-3L4.8 14.6z"/><path d="M13.6 5.8l3 3"/>',
    write: '<path d="M4.5 18.5l3.3-.9L18.2 7.2a2.1 2.1 0 0 0-3-3L4.8 14.6z"/><path d="M13.6 5.8l3 3"/><path class="d" d="M10 21h9.5"/>',
    undo: '<path d="M9 14.5 4.5 10 9 5.5"/><path d="M4.5 10h10a5 5 0 0 1 0 10H11"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    open: '<path d="M14 4.5h5.5V10"/><path d="M19.5 4.5l-8 8"/><path d="M17.5 13.5V18a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 18V8A1.5 1.5 0 0 1 6 6.5h4.5"/>',
    go: '<path d="M4.5 12h15M14 6.5l5.5 5.5-5.5 5.5"/>',
    back: '<path d="M19.5 12h-15M10 6.5 4.5 12l5.5 5.5"/>',
    prev: '<path d="M14.5 5.5 8 12l6.5 6.5"/>',
    next: '<path d="M9.5 5.5 16 12l-6.5 6.5"/>',
    fold: '<path d="M5.5 15 12 8.5l6.5 6.5"/>',
    unfold: '<path d="M5.5 9 12 15.5 18.5 9"/>',
    raise: '<path d="M12 19.5v-15M6.5 10 12 4.5l5.5 5.5"/>',
    lower: '<path d="M12 4.5v15M6.5 14l5.5 5.5 5.5-5.5"/>',
    copy: '<rect x="8.5" y="8.5" width="11" height="11" rx="1.5"/><path d="M15.5 8.5V6A1.5 1.5 0 0 0 14 4.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/>',
    paste: '<path d="M9 5H7.5A1.5 1.5 0 0 0 6 6.5V19a1.5 1.5 0 0 0 1.5 1.5h9A1.5 1.5 0 0 0 18 19V6.5A1.5 1.5 0 0 0 16.5 5H15"/><rect x="9" y="3.5" width="6" height="3" rx="1"/><path d="M9.5 11h5M9.5 14.5h5M9.5 18h3"/>',
    reset: '<path d="M3.75 6v4.5h4.5"/><path d="M5.63 14.25a6.75 6.75 0 1 0 1.6-7.02L3.75 10.5"/>',
    refresh: '<path d="M20.25 6v4.5h-4.5M3.75 18v-4.5h4.5"/><path d="M5.63 9.75a6.75 6.75 0 0 1 11.14-2.52l3.48 3.27M3.75 13.5l3.48 3.27a6.75 6.75 0 0 0 11.14-2.52"/>',
    chance: '<rect x="4.5" y="4.5" width="15" height="15" rx="3"/><circle class="f" cx="9" cy="9" r="1.2"/><circle class="f" cx="12" cy="12" r="1.2"/><circle class="f" cx="15" cy="15" r="1.2"/>',
    search: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l4.5 4.5"/>',
    find: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.3 15.3l4.7 4.7"/><path class="f" d="M10.5 7.3c.35 1.9 1.3 2.85 3.2 3.2-1.9.35-2.85 1.3-3.2 3.2-.35-1.9-1.3-2.85-3.2-3.2 1.9-.35 2.85-1.3 3.2-3.2z"/>',
    fetch: '<path d="M7.5 17H7a4 4 0 0 1-.6-7.95A5.5 5.5 0 0 1 17 8.2a4.25 4.25 0 0 1 .5 8.8"/><path d="M12 11v9M9 17l3 3 3-3"/>',
    import: '<path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/><path d="M12 10.5V17M9.2 14.2 12 17l2.8-2.8"/>',
    export: '<path d="M12 15V4.5M7.5 9 12 4.5 16.5 9"/><path d="M4.5 14v4.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V14"/>',
    print: '<path d="M7 9V3.5h10V9"/><path d="M7 16.5H5a1.5 1.5 0 0 1-1.5-1.5v-4.5A1.5 1.5 0 0 1 5 9h14a1.5 1.5 0 0 1 1.5 1.5V15a1.5 1.5 0 0 1-1.5 1.5h-2"/><path d="M7 13.5h10v7H7z"/>',
    link: '<path d="M10.5 13.5l-1.8 1.8a3 3 0 0 1-4.2-4.2l3-3a3 3 0 0 1 4.2 0"/><path d="M13.5 10.5l1.8-1.8a3 3 0 0 1 4.2 4.2l-3 3a3 3 0 0 1-4.2 0"/><path d="M9.5 14.5l5-5"/>',
    swap: '<path d="M4.5 8.5h14M15 5l3.5 3.5L15 12M19.5 15.5h-14M9 12l-3.5 3.5L9 19"/>',
    scale: '<path d="M14 4.5h5.5V10M19.5 4.5l-6 6M10 19.5H4.5V14M4.5 19.5l6-6"/>',
    crop: '<path d="M7 3.5V17h13.5"/><path d="M3.5 7H17v13.5"/><path class="d" d="M10 10.5h3.5V14"/>',
    repeat: '<path d="M17 3.5l3 3-3 3M4.5 11.5V10A3.5 3.5 0 0 1 8 6.5h12M7 20.5l-3-3 3-3M19.5 12.5V14a3.5 3.5 0 0 1-3.5 3.5H4"/>',
    send: '<path d="M20.5 3.5 13.5 20.5l-3.2-7.3L3 10z"/><path d="M20.5 3.5l-10.2 9.7"/>',
    pin: '<path d="M9 3.5h6"/><path d="M10 3.5 9.3 9 6.5 12.5h11L14.7 9 14 3.5"/><path d="M12 12.5v8"/>',
    lock: '<rect x="5.5" y="10.5" width="13" height="9.5" rx="2"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5"/><circle class="f" cx="12" cy="14.6" r="1.1"/><path d="M12 15.6v1.8"/>',
    drag: '<circle class="f" cx="9" cy="6" r="1.1"/><circle class="f" cx="15" cy="6" r="1.1"/><circle class="f" cx="9" cy="12" r="1.1"/><circle class="f" cx="15" cy="12" r="1.1"/><circle class="f" cx="9" cy="18" r="1.1"/><circle class="f" cx="15" cy="18" r="1.1"/>',
    more: '<circle class="f" cx="6" cy="12" r="1.3"/><circle class="f" cx="12" cy="12" r="1.3"/><circle class="f" cx="18" cy="12" r="1.3"/>',
    select: '<path d="M4 7.2l1.8 1.8 3.4-3.4"/><path d="M12 7.5h8M12 16.5h8"/><rect x="4.5" y="14" width="5" height="5" rx="1"/>',
    settings: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.2"/><path d="M12 3v2.6M12 18.4V21M21 12h-2.6M5.6 12H3M18.4 5.6l-1.9 1.9M7.5 16.5l-1.9 1.9M18.4 18.4l-1.9-1.9M7.5 7.5 5.6 5.6"/>',
    help: '<circle cx="12" cy="12" r="8.5"/><path d="M9.7 9.6a2.4 2.4 0 1 1 3.4 2.2c-.7.3-1.1.9-1.1 1.6v.5"/><circle class="f" cx="12" cy="16.6" r=".9"/>',
    play: '<path d="M8 5.5v13l10.5-6.5z"/>',
    pause: '<path d="M9 6v12M15 6v12"/>',
    volume: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
    mute: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    skip: '<path d="M6 6.5v11l8.5-5.5z"/><path d="M18 6.5v11"/>',
    enter: '<path d="M19 5v6.5a3 3 0 0 1-3 3H5.5"/><path d="M9 10.5 5 14.5l4 4"/>',
    keys: '<rect x="2.5" y="6.5" width="19" height="11" rx="2"/><path d="M6 10h.01M9.3 10h.01M12.6 10h.01M15.9 10h.01M18.2 10h.01M6.3 13.8h.01M17.7 13.8h.01M9.3 14h5.4"/>',
    exit: '<path d="M13.5 4H6v16h7.5"/><path d="M10.5 12H20M16.5 8.5 20 12l-3.5 3.5"/>',
    sum: '<path d="M17.5 5h-11l6 7-6 7h11"/>',
    filter: '<path d="M4 5.5h16l-6.2 7.2v5.3l-3.6 2v-7.3z"/>',
    bell: '<path d="M6.5 14.7V10a5.5 5.5 0 0 1 11 0v4.7l1.5 1.8h-14z"/><path d="M10.3 18.8a1.7 1.7 0 0 0 3.4 0"/>',
    task: '<rect x="4.5" y="4.5" width="15" height="15" rx="2.5"/><path d="M8.5 12.2l2.4 2.4 4.8-5"/>',
    cal: '<rect x="4" y="5.5" width="16" height="14.5" rx="1.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
    today: '<rect x="4" y="5.5" width="16" height="14.5" rx="1.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/><circle class="f" cx="12" cy="15" r="1.6"/>',
    tomorrow: '<rect x="4" y="5.5" width="16" height="14.5" rx="1.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/><path d="M9 15h6M12.8 12.8 15 15l-2.2 2.2"/>',
    "cal-add": '<rect x="4" y="5.5" width="16" height="14.5" rx="1.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/><path d="M12 12.5v5M9.5 15h5"/>',
    inbox: '<path d="M4 13 6.3 6a1.5 1.5 0 0 1 1.4-1h8.6a1.5 1.5 0 0 1 1.4 1L20 13v5.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5z"/><path d="M4 13h4.5l1 2h5l1-2H20"/>',
    later: '<path d="M7 3.5h10M7 20.5h10"/><path d="M8 3.5V6c0 2.4 4 3.6 4 6s-4 3.6-4 6v2.5M16 3.5V6c0 2.4-4 3.6-4 6s4 3.6 4 6v2.5"/><path class="f" d="M9.6 20.5c.4-1.4 1.4-2.1 2.4-2.1s2 .7 2.4 2.1z"/>',
    coins: '<path d="M15.4 8.6A6 6 0 1 0 8.6 15.4"/><circle cx="14.5" cy="14.5" r="6"/><path d="M11.6 14.5a2.9 2.9 0 0 1 2.9-2.9"/>',
    note: '<path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/><path d="M8.5 12.5h7M8.5 16h5"/>',
    list: '<path d="M9 7h10.5M9 12h10.5M9 17h10.5"/><circle class="f" cx="5.2" cy="7" r="1"/><circle class="f" cx="5.2" cy="12" r="1"/><circle class="f" cx="5.2" cy="17" r="1"/>',
    image: '<rect x="3.5" y="5" width="17" height="14" rx="1.5"/><path d="M3.5 16.5l4.8-4.8a1 1 0 0 1 1.4 0l3.8 3.8 2.3-2.3a1 1 0 0 1 1.4 0l3.3 3.3"/><circle cx="15.5" cy="9" r="1.5"/>',
    eye: '<path d="M3 12s3.2-6 9-6 9 6 9 6-3.2 6-9 6-9-6-9-6z"/><circle cx="12" cy="12" r="2.8"/>',
    hide: '<path d="M3 12s3.2-6 9-6c1.6 0 3 .5 4.2 1.1M21 12s-3.2 6-9 6c-1.6 0-3-.5-4.2-1.1"/><path d="M9.8 14.2a2.8 2.8 0 0 1 4-4M4.5 19.5l15-15"/>',
    heart: '<path d="M12 19.5C8 17 4.5 13.8 4.5 9.8A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5c0 4-3.5 7.2-7.5 9.7z"/>',
    star: '<path d="M12 4l2.4 5 5.4.8-3.9 3.8.9 5.4-4.8-2.6-4.8 2.6.9-5.4-3.9-3.8 5.4-.8z"/>',
    flag: '<path d="M6 20.5v-17"/><path d="M6 4.5h11l-2.4 3.75L17 12H6"/>',
    door: '<path d="M6.5 20.5V5A1.5 1.5 0 0 1 8 3.5h8A1.5 1.5 0 0 1 17.5 5v15.5"/><path d="M4 20.5h16"/><circle class="f" cx="14.6" cy="12.5" r=".95"/>',
    graph: '<circle cx="6.5" cy="16.5" r="2.2"/><circle cx="16.5" cy="6.5" r="2.2"/><circle cx="17.5" cy="17" r="1.6"/><circle cx="7.5" cy="7" r="1.4"/><path d="M8.1 14.9l6.8-6.8M8.7 16.6l7.2.3M16.7 8.7l.6 6.7M7.2 8.4l-.4 5.9"/>',
    compass: '<circle cx="12" cy="12" r="8.5"/><path d="M15.2 8.8l-1.9 4.5-4.5 1.9 1.9-4.5z"/><circle class="f" cx="12" cy="12" r=".8"/>',
    globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.3 2.4 3.4 5.2 3.4 8.5s-1.1 6.1-3.4 8.5c-2.3-2.4-3.4-5.2-3.4-8.5s1.1-6.1 3.4-8.5z"/>',
    wrench: '<path d="M14.5 5.5a4 4 0 0 0-4.9 5.4l-5.4 5.4a1.8 1.8 0 0 0 2.5 2.5l5.4-5.4a4 4 0 0 0 5.4-4.9l-2.4 2.4-2.4-.5-.5-2.4z"/>',
    code: '<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
    basket: '<path d="M4 9.5h16l-1.6 9.1a1.8 1.8 0 0 1-1.8 1.4H7.4a1.8 1.8 0 0 1-1.8-1.4z"/><path d="M8.5 9.5 11 4.5M15.5 9.5 13 4.5"/><path d="M9.5 13v3.5M12 13v3.5M14.5 13v3.5"/>',
    pot: '<path d="M4.5 10.5h15"/><path d="M6 10.5V17a2.5 2.5 0 0 0 2.5 2.5h7A2.5 2.5 0 0 0 18 17v-6.5"/><path d="M4.5 12.5H3M21 12.5h-1.5"/><path d="M9.5 7.5c0-1.2 1-1.3 1-2.5M13.5 7.5c0-1.2 1-1.3 1-2.5"/>',
    plate: '<path d="M3 14.5a9 4 0 1 0 18 0a9 4 0 1 0-18 0"/><path d="M6.5 14a5.5 2.2 0 1 0 11 0a5.5 2.2 0 1 0-11 0"/><path d="M8.2 13.4c.9-2.9 6.7-2.9 7.6 0"/><path d="M10.2 8.5c0-1.1 1-1.3 1-2.5M13.3 8.5c0-1.1 1-1.3 1-2.5"/>',
    glass: '<path d="M6.5 4h11l-1.4 15.2a1.5 1.5 0 0 1-1.5 1.3H9.4a1.5 1.5 0 0 1-1.5-1.3z"/><path d="M7.4 10.5h9.2"/>',
    seal: '<path d="M12 3.4l1.9 1.4 2.4-.2 1 2.1 2.1 1-.2 2.4 1.4 1.9-1.4 1.9.2 2.4-2.1 1-1 2.1-2.4-.2L12 20.6l-1.9-1.4-2.4.2-1-2.1-2.1-1 .2-2.4L3.4 12l1.4-1.9-.2-2.4 2.1-1 1-2.1 2.4.2z"/><circle cx="12" cy="12" r="4.3"/><path class="f" d="M12 9.6c.2 1.3.9 2 2.2 2.2-1.3.2-2 .9-2.2 2.2-.2-1.3-.9-2-2.2-2.2 1.3-.2 2-.9 2.2-2.2z"/>',
    sun: '<circle cx="12" cy="12" r="3.8"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"/>',
    cloud: '<path d="M7 18.5h10a4 4 0 0 0 .5-7.97A5.5 5.5 0 0 0 6.9 9.1 4.7 4.7 0 0 0 7 18.5z"/>',
    fog: '<path d="M4 8.5h12M7.5 12h12.5M4 15.5h10.5M9.5 19h8"/>',
    rain: '<path d="M7 14.5h10a3.5 3.5 0 0 0 .4-6.97A4.8 4.8 0 0 0 7.1 6.3 4.1 4.1 0 0 0 7 14.5z"/><path d="M8.5 17.5 7.5 20M12.5 17.5l-1 2.5M16.5 17.5l-1 2.5"/>',
    snow: '<path d="M7 14.5h10a3.5 3.5 0 0 0 .4-6.97A4.8 4.8 0 0 0 7.1 6.3 4.1 4.1 0 0 0 7 14.5z"/><path d="M8 17.8h.01M12 19.3h.01M16 17.8h.01M10 20.8h.01M14 20.8h.01"/>',
    storm: '<path d="M7 14.5h10a3.5 3.5 0 0 0 .4-6.97A4.8 4.8 0 0 0 7.1 6.3 4.1 4.1 0 0 0 7 14.5z"/><path d="M12.8 15.5 10.8 18.5h2.6l-1.8 3"/>',
    sunset: '<path d="M3.5 17.5h17"/><path d="M7 17.5a5 5 0 0 1 10 0"/><path d="M12 3.5v6M9.5 7.2 12 9.7l2.5-2.5"/><path class="d" d="M7 20.5h10"/>',
    orphan: '<path class="d" d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/><circle class="f" cx="12" cy="14" r="1.3"/>',
    leaf: '<path d="M5 19C5 10.5 10.5 5 19 5c0 8.5-5.5 14-14 14z"/><path d="M5 19l7.5-7.5"/>',
    pulse: '<path d="M3 12h4l2.5-6 5 12 2.5-6h4"/>',
    weight: '<rect x="3.5" y="4.5" width="17" height="15" rx="4"/><path d="M8.5 10a3.5 3.5 0 0 1 7 0z"/><path d="M12 10l1.5-2"/>',
    bed: '<path d="M3 18.5v-11M3 14.5h18v4"/><path d="M21 14.5v-2a3 3 0 0 0-3-3h-6.5v5"/><circle cx="7" cy="11.5" r="2"/>',
    bolt: '<path d="M13 3 5.5 13.5H12L11 21l7.5-10.5H12z"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.8"/><circle class="f" cx="12" cy="12" r="1.4"/>',
    grid: '<rect x="4.5" y="4.5" width="6" height="6" rx="1"/><rect x="13.5" y="4.5" width="6" height="6" rx="1"/><rect x="4.5" y="13.5" width="6" height="6" rx="1"/><rect x="13.5" y="13.5" width="6" height="6" rx="1"/>',
    folder: '<path d="M3.5 7A1.5 1.5 0 0 1 5 5.5h4l2 2h8a1.5 1.5 0 0 1 1.5 1.5v8.5A1.5 1.5 0 0 1 19 19H5a1.5 1.5 0 0 1-1.5-1.5z"/>',
    tag: '<path d="M3.5 12.2V5A1.5 1.5 0 0 1 5 3.5h7.2l8.3 8.3a1.5 1.5 0 0 1 0 2.1l-6.6 6.6a1.5 1.5 0 0 1-2.1 0z"/><circle cx="8" cy="8" r="1.5"/>',
    palette: '<path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 1.8-.9 1.5-1.9-.4-1.3.4-2.6 1.8-2.6H17a3.5 3.5 0 0 0 3.5-3.5c0-5-3.8-9-8.5-9z"/><circle class="f" cx="7.8" cy="11" r="1.1"/><circle class="f" cx="10" cy="7.3" r="1.1"/><circle class="f" cx="14.3" cy="7.3" r="1.1"/>',
    key: '<circle cx="8" cy="15.5" r="4.5"/><path d="M11.2 12.3 20 3.5M17 6.5l2.5 2.5M14.5 9l2 2"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    bookmark: '<path d="M7 3.5h10v17l-5-3.6-5 3.6z"/>',
    bars: '<path d="M5 20v-6M10 20V9M15 20v-8M20 20V5"/>',
    drop: '<path d="M12 3.8c3.3 4.3 6 7.7 6 10.7a6 6 0 0 1-12 0c0-3 2.7-6.4 6-10.7z"/><path d="M9.4 14.8a2.7 2.7 0 0 0 2.3 2.6"/>',
    case: '<rect x="3.5" y="7.5" width="17" height="12" rx="2"/><path d="M9 7.5V6a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 6v1.5"/><path d="M3.5 12.5h17"/><path class="f" d="M10.8 11.3h2.4v2.4h-2.4z"/>',
    dumbbell: '<path d="M6.5 7.5v9M17.5 7.5v9M3.8 10v4M20.2 10v4M6.5 12h11"/>',
    spark: '<path d="M12 3.5c.6 5 3.5 7.9 8.5 8.5-5 .6-7.9 3.5-8.5 8.5-.6-5-3.5-7.9-8.5-8.5 5-.6 7.9-3.5 8.5-8.5z"/>',
    candle: '<path d="M8.5 20.5h7"/><path d="M10 20.5v-9h4v9"/><path d="M12 11.5V9.7"/><path d="M12 3.5c1.2 1.3 1.8 2.4 1.8 3.3a1.8 1.8 0 0 1-3.6 0c0-.9.6-2 1.8-3.3z"/>',
    sunrise: '<path d="M3.5 17.5h17"/><path d="M7 17.5a5 5 0 0 1 10 0"/><path d="M12 6v3M5.8 9.8l1.8 1.5M18.2 9.8l-1.8 1.5"/><path class="d" d="M7 20.5h10"/>',
    guide: '<path d="M12 9C10 7.6 7 7.2 4 7.6v11c3-.4 6 0 8 1.4 2-1.4 5-1.8 8-1.4v-11c-3-.4-6 0-8 1.4z"/><path d="M12 9v11"/><path d="M12 2.6c1 1.1 1.5 2 1.5 2.8a1.5 1.5 0 0 1-3 0c0-.8.5-1.7 1.5-2.8z"/>',
    arch: '<path d="M5 20.5V11a7 7 0 0 1 14 0v9.5"/><path d="M3.5 20.5h17"/><path class="d" d="M9 20.5v-8a3 3 0 0 1 6 0v8"/>',
    shelves: '<path d="M3.5 20h17"/><path d="M6 20V6.5h3V20M9 20V4.5h3.2V20"/><path d="M14.2 7.4l2.9-.8 3.4 12.6-2.9.8z"/>',
    ledger: '<path d="M12 6.5C10 5 7 4.6 4 5v13.2c3-.4 6 0 8 1.4 2-1.4 5-1.8 8-1.4V5c-3-.4-6 0-8 1.5z"/><path d="M12 6.5v13"/><path d="M6.5 9h3M6.5 12h3M14.5 9h3M14.5 12h3M14.5 15h2"/>',
    diary: '<path d="M12 6.5C10 5 7 4.6 4 5v13.2c3-.4 6 0 8 1.4 2-1.4 5-1.8 8-1.4V5c-3-.4-6 0-8 1.5z"/><path d="M12 6.5v13"/>',
    flask: '<path d="M9.5 3.5h5"/><path d="M10.5 3.5v5.2l-5 8.6a2.1 2.1 0 0 0 1.8 3.2h9.4a2.1 2.1 0 0 0 1.8-3.2l-5-8.6V3.5"/><path d="M7.6 14.3c1.5-.7 2.9-.7 4.4 0s2.9.7 4.4 0"/><circle class="f" cx="10.8" cy="17.4" r=".8"/><circle class="f" cx="13.6" cy="16.6" r=".6"/>',
    moon: '<path d="M16.5 4.2a8 8 0 1 0 3.3 13.4A6.6 6.6 0 0 1 16.5 4.2z"/>',
    cards: '<rect x="3.5" y="4.5" width="9" height="6.5" rx="1"/><rect x="11.5" y="13" width="9" height="6.5" rx="1"/><path d="M6 7.75h4M14 16.25h4"/><path class="d" d="M8 11v5.25h3.5"/>',
    vinyl: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.2"/><path d="M12 6.3a5.7 5.7 0 0 1 5.7 5.7M6.3 12a5.7 5.7 0 0 0 5.7 5.7"/>',
    page: '<path d="M14 3.5H7A1.5 1.5 0 0 0 5.5 5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/><path d="M8.5 11h7M8.5 14h7M8.5 17h4"/>',
    book: '<path d="M6 19.5V5a1.5 1.5 0 0 1 1.5-1.5H18V18H7.5A1.5 1.5 0 0 0 6 19.5a1.5 1.5 0 0 0 1.5 1.5H18"/><path d="M9.5 7.5H15"/>',
    cap: '<path d="M2.5 9.5 12 5l9.5 4.5L12 14z"/><path d="M6.5 11.5v4.2c1.6 1.4 3.5 2.1 5.5 2.1s3.9-.7 5.5-2.1v-4.2"/><path d="M21.5 9.5v5"/>',
    pad: '<path d="M7.5 8h9a4.5 4.5 0 0 1 4.3 5.8l-.9 3.1a2.2 2.2 0 0 1-3.7.9L14 15.5h-4l-2.2 2.3a2.2 2.2 0 0 1-3.7-.9l-.9-3.1A4.5 4.5 0 0 1 7.5 8z"/><path d="M8 10.8v3M6.5 12.3h3"/><circle class="f" cx="15.6" cy="11.4" r=".9"/><circle class="f" cx="17.2" cy="13.2" r=".9"/>',
    frame: '<rect x="4" y="3.5" width="16" height="17" rx="1"/><path d="M4 7.5h16M4 16.5h16M7 5.5h1M11 5.5h1M15 5.5h1M7 18.5h1M11 18.5h1M15 18.5h1"/>',
    mic: '<rect x="9" y="3.5" width="6" height="11" rx="3"/><path d="M6 11.5a6 6 0 0 0 12 0M12 17.5v3M9 20.5h6"/>',
    screen: '<rect x="3.5" y="5" width="17" height="12" rx="1.5"/><path d="M9 20.5h6M12 17v3.5"/>',
    video: '<circle cx="12" cy="12" r="8.5"/><path d="M10 8.7v6.6l5.4-3.3z"/>',
    reel: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="1.3"/><circle cx="12" cy="7.2" r="1.7"/><circle cx="16.6" cy="10.5" r="1.7"/><circle cx="14.8" cy="15.9" r="1.7"/><circle cx="9.2" cy="15.9" r="1.7"/><circle cx="7.4" cy="10.5" r="1.7"/>',
    ticket: '<path d="M3.5 7h17v3a2 2 0 0 0 0 4v3h-17v-3a2 2 0 0 0 0-4z"/><path class="d" d="M14.5 7.5v9"/>',
    spot: '<path d="M8.5 3.5h7l-1.2 4.5H9.7z"/><path class="d" d="M9.7 8 5 20.5h14L14.3 8"/>',
    joined: '<rect x="3" y="7" width="7.5" height="10" rx="1"/><rect x="13.5" y="7" width="7.5" height="10" rx="1"/><path d="M10.5 12h3"/>',
    pair: '<rect x="2.5" y="6" width="7.5" height="12" rx="1"/><rect x="14" y="6" width="7.5" height="12" rx="1"/><path d="M12 10.3v3.4M10.3 12h3.4"/>',
    quote: '<path d="M9.5 8C7 8 5.5 9.8 5.5 12.3V16h4v-4H7.3c0-1.5.8-2.4 2.2-2.5zM18.5 8c-2.5 0-4 1.8-4 4.3V16h4v-4h-2.2c0-1.5.8-2.4 2.2-2.5z"/>',
  };
  const ICON_ALIAS = { "§": "diary", "⚗": "flask", "☾": "moon", "◈": "cards", "✦": "spark", "❦": "guide" };
  function icon(name, cls = "") {
    const key = ICONS[name] ? name : ICON_ALIAS[name];
    return key ? `<svg class="vc-ic${cls ? " " + cls : ""}" data-i="${key}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[key]}</svg>` : "";
  }
  function banner({ mark = "", hour = "", photo = "", label = "" } = {}) {
    if (photo) return `<div class="nm-stage-photo" role="img" aria-label="${esc(label)}" style="background-image:url('${esc(photo)}')"></div>`;
    return `<div class="nv-banner"${hour ? ` data-hour="${esc(hour)}"` : ""} aria-hidden="true"><span class="nv-banner-still"><i class="nv-banner-pool"></i>${icon(mark, "nv-banner-mark")}</span></div>`;
  }
  const NETC = new Map();
  async function net(url) {
    if (NETC.has(url)) return NETC.get(url);
    let req = null;
    try { const o = require("obsidian"); if (o && o.requestUrl) req = o.requestUrl; } catch (e) {}
    try { if (!req && window.requestUrl) req = window.requestUrl; } catch (e) {}
    let j;
    if (req) {
      const r = await req({ url, method: "GET", headers: { Accept: "application/json" }, throw: false });
      if (r.status < 200 || r.status >= 300) throw new Error("HTTP " + r.status);
      j = r.json !== undefined ? r.json : JSON.parse(r.text || "{}");
    } else {
      const r = await fetch(url, { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error("HTTP " + r.status);
      j = await r.json();
    }
    NETC.set(url, j);
    return j;
  }
  let PDFJS = null;
  function loadPdf() {
    try { if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib); } catch (e) {}
    return PDFJS || (PDFJS = (async () => {
      try { const o = require("obsidian"); if (o && o.loadPdfJs) return await o.loadPdfJs(); } catch (e) {}
      for (const [src, type, worker] of [["/lib/pdfjs/pdf.min.mjs", "module", "/lib/pdfjs/pdf.worker.min.mjs"], ["/lib/pdfjs/pdf.min.js", "text/javascript", "/lib/pdfjs/pdf.worker.min.js"]]) {
        const ok = await new Promise(done => { const s = document.createElement("script"); s.type = type; s.src = src;
          const t = setTimeout(() => done(false), 15000);
          s.onload = () => { clearTimeout(t); done(true); }; s.onerror = () => { clearTimeout(t); s.remove(); done(false); }; document.body.appendChild(s); });
        if (!ok || !window.pdfjsLib) continue;
        try { if (!window.pdfjsLib.GlobalWorkerOptions.workerSrc) window.pdfjsLib.GlobalWorkerOptions.workerSrc = worker; } catch (e) {}
        return window.pdfjsLib;
      }
      PDFJS = null; return null;
    })());
  }
  function iconify(root) {
    if (!root || typeof root.querySelectorAll !== "function") return;
    root.querySelectorAll("[data-ic]").forEach(el => {
      if (el.querySelector(".vc-ic")) return;
      const svg = icon(el.getAttribute("data-ic"));
      if (svg) el.insertAdjacentHTML("afterbegin", svg);
    });
  }
  const MOON_NAMES = ["new moon", "waxing crescent", "first quarter", "waxing gibbous", "full moon", "waning gibbous", "last quarter", "waning crescent"];
  function moonNow(at = Date.now()) {
    const synodic = 29.53058867, days = (at - Date.parse("2000-01-06T18:14:00Z")) / 864e5;
    const phase = ((days % synodic) + synodic) % synodic / synodic;
    return { phase, name: MOON_NAMES[Math.floor(phase * 8 + 0.5) % 8] };
  }
  function moonMark(phase, lat, cls = "") {
    const k = Math.cos(2 * Math.PI * phase), right = (phase < .5) !== (lat < 0);
    const rx = Math.abs(k * 8.5).toFixed(2), limb = right ? 1 : 0, term = right ? (k > 0 ? 0 : 1) : (k > 0 ? 1 : 0);
    return `<svg class="vc-ic vc-moon${cls ? " " + cls : ""}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><path class="f" d="M12 3.5A8.5 8.5 0 0 ${limb} 12 20.5A${rx} 8.5 0 0 ${term} 12 3.5z"/></svg>`;
  }

  const dayNote = (() => {
    const PLAN_OPEN = /%%\s*nm-plan:([^\s%]*)\s*([\d-]*)\s*%%/;
    const TASK = /^(\s*(?:>\s*)*-\s\[)([ xX])(\]\s?)(.*)$/;
    const PLANNED = "Nutrition", SECTION_ORDER = ["Today", "Capture", "Timeline", PLANNED, "Routines", "Focus", "Money", "Journal", "Reflection"];
    const CALLOUTS = { "The System": { kind: "todo", section: "Capture", fields: ["highlight"] },
      "Evening Audit": { kind: "abstract", section: "Reflection", fields: ["day_reflection", "recovery_balance", "tomorrow_intention", "good_thing"] } };
    const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    function sectionRange(lines, name) {
      let start = -1, end = lines.length;
      const re = new RegExp("^##\\s+" + reEsc(name) + "\\s*$");
      for (let i = 0; i < lines.length; i++) {
        if (re.test(lines[i])) { start = i; continue; }
        if (start >= 0 && i > start && (/^##\s+/.test(lines[i]) || PLAN_OPEN.test(lines[i]))) { end = i; break; }
      }
      return start < 0 ? null : { start, end };
    }
    const sectionAt = (lines, name) => lines.findIndex(l => new RegExp("^##\\s+" + reEsc(name) + "\\s*$").test(l) || (name === PLANNED && PLAN_OPEN.test(l)));
    function ensureSection(lines, name) {
      if (sectionRange(lines, name)) return false;
      let at = -1;
      for (const later of SECTION_ORDER.slice(SECTION_ORDER.indexOf(name) + 1)) { at = sectionAt(lines, later); if (at >= 0) break; }
      if (at < 0) lines.push("", "## " + name, "");
      else {
        lines.splice(at, 0, "## " + name, "");
        if (at > 0 && lines[at - 1].trim() !== "") { lines.splice(at, 0, ""); at++; }
        while (lines[at + 2] === "" && at + 2 < lines.length - 1) lines.splice(at + 2, 1);
      }
      return true;
    }
    const calloutHead = (lines, title) => lines.findIndex(l => /^>\s*\[!\w+\][+-]?\s*/.test(l) && l.includes(title));
    function ensureCallout(lines, title) {
      if (calloutHead(lines, title) >= 0) return false;
      const c = CALLOUTS[title];
      ensureSection(lines, c.section);
      const r = sectionRange(lines, c.section);
      let at = r.end;
      while (at > r.start + 1 && lines[at - 1].trim() === "") at--;
      lines.splice(at, 0, ...(at === r.start + 1 ? [""] : []), `> [!${c.kind}]+ ${title}`, ...c.fields.map(f => `> ${f}:: `));
      return true;
    }
    function calloutRange(lines, title) {
      const head = calloutHead(lines, title);
      if (head < 0) return null;
      let end = head + 1;
      while (end < lines.length && /^>/.test(lines[end])) end++;
      return { start: head, end };
    }
    function addTask(lines, text) {
      ensureCallout(lines, "The System");
      const r = calloutRange(lines, "The System");
      let last = -1;
      for (let i = r.start + 1; i < r.end; i++) if (TASK.test(lines[i])) last = i;
      const at = last >= 0 ? last + 1 : Math.min(r.start + 2, r.end);
      const raw = `> - [ ] ${String(text).replace(/\n/g, " ").trim()}`;
      lines.splice(at, 0, raw);
      return { at, raw };
    }
    function addJournal(lines, text, hhmm) {
      const parts = String(text).replace(/\r/g, "").trim().split("\n");
      ensureSection(lines, "Journal");
      const r = sectionRange(lines, "Journal");
      let at = r.end;
      while (at > r.start + 1 && lines[at - 1].trim() === "") at--;
      const raw = `**${hhmm}** — ${parts[0]}`;
      lines.splice(at, 0, "", raw, ...parts.slice(1));
      return { at: at + 1, raw };
    }
    const SPENT = ["food", "transport", "health", "bills", "other"];
    function addMoney(lines, field, v, hhmm, what) {
      ensureSection(lines, "Money");
      const r = sectionRange(lines, "Money");
      let at = r.end;
      while (at > r.start + 1 && lines[at - 1].trim() === "") at--;
      const raw = `- ${field}:: ${(Math.round(v * 100) / 100).toFixed(2)} · ${hhmm}${what ? " · " + String(what).replace(/·/g, "-") : ""}`;
      const first = at === r.start + 1;
      lines.splice(at, 0, ...(first ? ["", raw] : [raw]));
      return { at: first ? at + 1 : at, raw };
    }
    return { SECTION_ORDER, SPENT, sectionRange, ensureSection, ensureCallout, calloutRange, addTask, addJournal, addMoney };
  })();

  const theme = (() => {
    const unq = s => String(s || "").trim().replace(/^["']|["']$/g, "");
    function blocks(css) {
      const text = String(css || "").replace(/\/\*[\s\S]*?\*\//g, "");
      const out = [], re = /["'{};]/g; let depth = 0, from = 0, head = "", m;
      while ((m = re.exec(text))) {
        const ch = m[0], i = m.index;
        if (ch === '"' || ch === "'") { const j = text.indexOf(ch, i + 1); re.lastIndex = j < 0 ? text.length : j + 1; continue; }
        if (ch === ";") { if (!depth) from = i + 1; continue; }
        if (ch === "{") { if (!depth++) { head = text.slice(from, i); from = i + 1; } continue; }
        if (!depth) { out.push({ head: text.slice(from, i).trim(), body: "" }); from = i + 1; continue; }
        if (!--depth) { out.push({ head: head.trim(), body: text.slice(from, i) }); from = i + 1; }
      }
      return out;
    }
    function decls(body) {
      const s = String(body || ""), out = [], re = /["'();]/g; let depth = 0, from = 0, m;
      const push = to => { const cur = s.slice(from, to), at = cur.indexOf(":"); if (at > 0) { const v = cur.slice(at + 1).trim(); out.push([cur.slice(0, at).trim(), v.includes("\n") ? v.replace(/\s*\n\s*/g, " ") : v]); } };
      while ((m = re.exec(s))) {
        const ch = m[0], i = m.index;
        if (ch === '"' || ch === "'") { const j = s.indexOf(ch, i + 1); re.lastIndex = j < 0 ? s.length : j + 1; continue; }
        if (ch === "(") depth++; else if (ch === ")") depth--;
        else if (depth <= 0) { push(i); from = i + 1; }
      }
      push(s.length);
      return out;
    }
    const ENTRY = /^\[data-style="([\w-]+)"\](?:\[data-palette="([\w-]+)"\])?$/;
    const NESTS = /^@(?:media|supports|container|layer|scope|starting-style)\b/i;
    function parse(input) {
      const sheets = (Array.isArray(input) ? input : [input]).map(f => f && typeof f === "object"
        ? { name: String(f.name || ""), css: String(f.css || "") } : { name: "", css: String(f || "") });
      sheets.sort((a, b) => a.name.length - b.name.length || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
      const styles = [];
      for (const sheet of sheets) {
        const all = blocks(sheet.css), named = all.map(b => b.head.match(ENTRY)).find(Boolean);
        if (!named || styles.some(x => x.id === named[1])) continue;
        const st = { id: named[1], name: named[1], about: "", group: "", order: 1e9, from: sheet.name, set: [], palettes: [], faces: [], rules: [] };
        styles.push(st);
        for (const b of all) {
          if (/^@font-face/i.test(b.head)) {
            const fam = decls(b.body).find(d => d[0] === "font-family");
            st.faces.push({ family: unq(fam && fam[1]), css: "@font-face {" + b.body.trimEnd() + "\n}" });
            continue;
          }
          const e = b.head.match(ENTRY);
          if (!e) { st.rules.push({ loose: /^@/.test(b.head) && !NESTS.test(b.head), css: b.head + " {" + b.body.trimEnd() + "\n}" }); continue; }
          if (e[1] !== st.id) continue;
          const meta = {}, set = [];
          decls(b.body).forEach(([k, v]) => { if (k.startsWith("--theme-")) meta[k.slice(8)] = v; else if (k.startsWith("--")) set.push([k, v]); });
          if (e[2]) st.palettes.push({ id: e[2], name: unq(meta.name) || e[2], swatch: String(meta.swatch || "").split(/\s+/).filter(Boolean), set,
            ...(meta.match ? { match: unq(meta.match), matchGround: unq(meta["match-ground"]) } : {}) });
          else {
            st.name = unq(meta.name) || st.id; st.about = unq(meta.about); st.group = unq(meta.group); st.set = set;
            if (isFinite(parseFloat(meta.order))) st.order = parseFloat(meta.order);
          }
        }
      }
      styles.sort((a, b) => a.order - b.order || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
      return { styles };
    }
    function pick(reg, styleId, paletteId) {
      const st = reg && reg.styles && (reg.styles.find(s => s.id === styleId) || reg.styles[0]);
      if (!st) return null;
      const pal = st.palettes.find(p => p.id === paletteId) || st.palettes[0] || { id: "", name: "", swatch: [], set: [] };
      return { st, pal };
    }
    const hash = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return h.toString(36); };
    function layers(got) {
      const first = got.st.palettes[0], all = [...got.st.set, ...(first && first !== got.pal ? first.set : []), ...got.pal.set];
      const last = new Map(); all.forEach(([k], i) => last.set(k, i));
      return all.filter(([k], i) => last.get(k) === i);
    }
    const OVER = ":is(body, #vault-theme)";
    function rulesOf(st) {
      const loose = st.rules.filter(r => r.loose).map(r => r.css), held = st.rules.filter(r => !r.loose).map(r => r.css);
      return (loose.length ? loose.join("\n") + "\n" : "") + (held.length ? OVER + " {\n" + held.join("\n") + "\n}\n" : "");
    }
    const lin = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    const gam = v => 255 * (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055);
    const hexIn = h => { const m = String(h || "").trim().match(/^#([0-9a-f]{6})$/i); return m ? [0, 2, 4].map(i => parseInt(m[1].slice(i, i + 2), 16)) : null; };
    const hexOf = rgb => "#" + rgb.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("");
    function oklab(rgb) {
      const [r, g, b] = rgb.map(lin);
      const l = Math.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b), m = Math.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b), s = Math.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b);
      return [0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s, 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s];
    }
    function linOf([L, a, b]) {
      const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3, m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3, s = (L - 0.0894841775 * a - 1.2914855480 * b) ** 3;
      return [4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s, -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s];
    }
    const lchOf = hex => { const [L, a, b] = oklab(hexIn(hex)); return { L, C: Math.hypot(a, b), h: Math.atan2(b, a) * 180 / Math.PI }; };
    function fromLch(L, C, h) {
      L = Math.max(0, Math.min(1, L));
      const at = c => { const r = h * Math.PI / 180; return linOf([L, c * Math.cos(r), c * Math.sin(r)]); };
      const fits = v => v.every(x => x >= -1e-4 && x <= 1 + 1e-4);
      let c = Math.max(0, C);
      if (!fits(at(c))) { let lo = 0, hi = c; for (let i = 0; i < 20; i++) { const mid = (lo + hi) / 2; if (fits(at(mid))) lo = mid; else hi = mid; } c = lo; }
      return hexOf(at(c).map(x => gam(Math.max(0, Math.min(1, x)))));
    }
    const lumOf = hex => { const [r, g, b] = hexIn(hex).map(lin); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
    const contrast = (x, y) => { const p = lumOf(x), q = lumOf(y); return (Math.max(p, q) + 0.05) / (Math.min(p, q) + 0.05); };
    const lab76 = hex => {
      const [r, g, b] = hexIn(hex).map(lin), f = t => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
      const x = f((0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047), y = f(0.2126 * r + 0.7152 * g + 0.0722 * b), z = f((0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883);
      return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
    };
    const apart = (x, y) => { const p = lab76(x), q = lab76(y); return Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]); };
    function pictureColours(px) {
      let n = 0, sL = 0, sa = 0, sb = 0;
      const bins = new Float64Array(36), count = new Float64Array(36), vivid = [];
      for (let i = 0; i + 3 < px.length; i += 4) {
        if (px[i + 3] < 128) continue;
        const lab = oklab([px[i], px[i + 1], px[i + 2]]); n++; sL += lab[0]; sa += lab[1]; sb += lab[2];
        const C = Math.hypot(lab[1], lab[2]);
        if (C < 0.035 || lab[0] < 0.2 || lab[0] > 0.96) continue;
        const h = (Math.atan2(lab[2], lab[1]) * 180 / Math.PI + 360) % 360;
        vivid.push([Math.floor(h / 10) % 36, lab, C, h]);
      }
      if (!n) return null;
      const castC = Math.hypot(sa / n, sb / n), castH = (Math.atan2(sb / n, sa / n) * 180 / Math.PI + 360) % 360;
      const cast = fromLch(sL / n, castC, castH);
      if (!vivid.length) return [cast, cast];
      vivid.forEach(([bin, , C, h]) => { const d = castC >= 0.02 ? Math.abs(((h - castH + 540) % 360) - 180) / 180 : 0; bins[bin] += C * C * C * (1 + 2 * d); count[bin]++; });
      const near = (arr, b) => arr[(b + 35) % 36] / 2 + arr[b] + arr[(b + 1) % 36] / 2;
      let best = -1, most = -1;
      for (let b = 0; b < 36; b++) { const w = near(bins, b); if (near(count, b) >= n / 50 && w > most) { most = w; best = b; } }
      if (best < 0) for (let b = 0; b < 36; b++) { const w = near(bins, b); if (w > most) { most = w; best = b; } }
      const binsApart = (b, t) => Math.min((b - t + 36) % 36, (t - b + 36) % 36);
      const colourAt = at => {
        const there = vivid.filter(([b]) => binsApart(b, at) <= 1).sort((x, y) => y[2] - x[2]);
        const top = there.slice(0, Math.max(1, Math.ceil(there.length / 2)));
        let L = 0, a = 0, bb = 0, w = 0; top.forEach(([, lab, C]) => { L += lab[0] * C; a += lab[1] * C; bb += lab[2] * C; w += C; });
        return fromLch(L / w, Math.hypot(a / w, bb / w), Math.atan2(bb / w, a / w) * 180 / Math.PI);
      };
      const taken = [best], more = [];
      const peaks = [...Array(36).keys()].map(b => [b, near(bins, b)]).sort((x, y) => y[1] - x[1]);
      for (const [b, w] of peaks) {
        if (more.length >= 4 || w < most / 40) break;
        if (near(count, b) < n / 100 || taken.some(t => binsApart(b, t) < 3)) continue;
        if (near(bins, (b + 35) % 36) > w || near(bins, (b + 1) % 36) > w) continue;
        taken.push(b); more.push(colourAt(b));
      }
      return [cast, colourAt(best), ...more];
    }
    const ACCENT = ["--lp-a", "--lp-a-hi", "--lp-a-lo", "--lp-a-pale", "--lp-on-a", "--lp-lamp", "--lp-moon", "--lp-moon-hi", "--lp-moon-lo"];
    const GROUND = ["--lp-bg", "--lp-bg-1", "--lp-bg-2", "--lp-bg-3", "--lp-bg-4", "--lp-ink"], INK = ["--lp-tx", "--lp-bright", "--lp-dim", "--lp-fnt", "--lp-light"];
    const MEANT = [["--lp-planned", "--lp-planned-lo"], ["--lp-reached"], ["--lp-over", "--lp-over-hi", "--lp-over-bg"]];
    const LAWS = new WeakMap();
    function lawsOf(reg) {
      if (LAWS.has(reg)) return LAWS.get(reg);
      const st = reg.styles[0], p = st && st.palettes[0], l = p ? new Map(layers({ st, pal: p })) : new Map();
      const a = l.get("--lp-a"), mean = MEANT.map(g => l.get(g[0])).filter(hexIn);
      const floor = hexIn(a) && mean.length ? Math.min(...mean.map(m => apart(a, m)), ...mean.flatMap((m, i) => mean.slice(i + 1).map(n => apart(m, n)))) : 30;
      const out = { gold: hexIn(l.get("--lp-eaten")) ? l.get("--lp-eaten") : hexIn(a) ? a : "", floor, chrome: [...l].filter(([, v]) => hexIn(v)) };
      LAWS.set(reg, out);
      return out;
    }
    function paint(lines, colours, opts) {
      const map = new Map(lines), get = k => (hexIn(map.get(k)) ? lchOf(map.get(k)) : null);
      const a0 = get("--lp-a"); if (!a0) return lines;
      (opts.chrome || []).forEach(([k, v]) => { if (!map.has(k)) map.set(k, v); });
      const G = lchOf(colours[0]), A = lchOf(colours[1]);
      const hued = A.C >= 0.03, accH = hued ? A.h : a0.h, turn = accH - a0.h;
      const ratio = hued ? Math.max(0.7, Math.min(1.3, A.C / Math.max(a0.C, 0.02))) : 0.5;
      const toAccent = opts.ground === "accent";
      ACCENT.forEach(k => { const c = get(k); if (c) map.set(k, fromLch(c.L, k === "--lp-on-a" ? c.C : c.C * ratio, c.h + turn)); });
      [...GROUND, ...INK].forEach(k => {
        const c = get(k); if (!c) return;
        const ink = INK.includes(k);
        if (toAccent ? hued : G.C >= 0.02) map.set(k, fromLch(c.L, toAccent ? c.C : Math.min(ink ? 0.028 : 0.04, c.C + G.C * (ink ? 0.1 : 0.22)), toAccent ? accH : G.h));
        else map.set(k, fromLch(c.L, c.C * 0.3, c.h));
      });
      if (!hexIn(map.get("--lp-eaten")) && opts.gold) map.set("--lp-eaten", opts.gold);
      const P = [...colours.slice(1), colours[0]].filter(hexIn).map((h, i) => Object.assign(lchOf(h), { accent: i === 0 })).filter(c => c.C >= 0.03);
      const own = new Set([...ACCENT, ...GROUND, ...INK]), held = new Set([...MEANT.map(g => g[0]), "--lp-eaten"]);
      const leadOf = k => { const m = k.match(/^(--lp-[\w-]+?)-(?:hi|lo|bg|pale)$/); return m && map.has(m[1]) && !own.has(m[1]) ? m[1] : k; };
      const turnOf = (c, apartFromAccent) => {
        if (!P.length || c.C < 0.02) return { by: 0, k: 1 };
        const nearest = ps => ps.map(p => ((p.h - c.h + 540) % 360) - 180).sort((x, y) => Math.abs(x) - Math.abs(y))[0];
        const d = nearest(apartFromAccent ? P.filter(p => !p.accent) : P);
        if (d === undefined) return { by: 0, k: 1 };
        return Math.abs(d) <= 60 ? { by: d, k: 1 } : { by: Math.sign(d) * Math.min(45, Math.abs(d) / 2), k: 0.8 };
      };
      const turns = new Map(), was = new Map();
      [...map.keys()].filter(k => !own.has(k) && hexIn(map.get(k))).forEach(k => {
        const c = get(k), lead = leadOf(k), keep = held.has(lead);
        if (!turns.has(lead)) turns.set(lead, turnOf(get(lead), keep));
        was.set(k, c);
        const t = turns.get(lead);
        if (c.C >= 0.02) map.set(k, fromLch(c.L, c.C * (keep ? 1 : ratio) * t.k, c.h + t.by));
      });
      const e0 = was.get("--lp-eaten"), te = turns.get("--lp-eaten");
      if (e0 && opts.gold && apart(map.get("--lp-eaten"), opts.gold) > opts.floor * 0.6 - 1) {
        const at = t => fromLch(e0.L, e0.C * (1 + t * (te.k - 1)), e0.h + t * te.by);
        let lo = 0, hi = 1; for (let i = 0; i < 16; i++) { const mid = (lo + hi) / 2; if (apart(at(mid), opts.gold) <= opts.floor * 0.6 - 1) lo = mid; else hi = mid; }
        map.set("--lp-eaten", apart(at(lo), opts.gold) <= opts.floor * 0.6 - 1 ? at(lo) : opts.gold);
      }
      const lift = (k, least, against) => {
        let v = map.get(k); if (!hexIn(v) || !hexIn(against)) return;
        const c = lchOf(v), up = lumOf(against) < 0.18 ? 0.01 : -0.01;
        for (let i = 0; i < 80 && contrast(v, against) < least; i++) { c.L = Math.max(0, Math.min(1, c.L + up)); v = fromLch(c.L, c.C, c.h); }
        map.set(k, v);
      };
      const bg = map.get("--lp-bg");
      lift("--lp-tx", 7.1, bg); lift("--lp-dim", 4.6, bg); lift("--lp-fnt", 4.6, bg); lift("--lp-a", 4.6, bg);
      lift("--lp-on-a", 4.6, map.get("--lp-a"));
      const need = opts.floor * 0.6 + 0.5, kOf = grp => (turns.get(grp[0]) || { k: 1 }).k;
      [...MEANT].sort((x, y) => kOf(x) - kOf(y)).forEach(grp => {
        const k = grp[0]; if (!hexIn(map.get(k))) return;
        const others = () => [map.get("--lp-a"), map.get("--lp-eaten"), ...MEANT.map(g => g[0]).filter(x => x !== k).map(x => map.get(x))].filter(hexIn);
        const clear = hex => others().every(o => apart(hex, o) >= need);
        if (clear(map.get(k))) return;
        const from = grp.map(x => was.get(x) || get(x));
        const onto = P.filter(p => !p.accent).map(p => [((p.h - from[0].h + 540) % 360) - 180, 0]);
        const wheel = [0, 20, -20, 40, -40, 60, -60, 80, -80, 100, -100, 120, -120, 150, -150, 180].map(d => [d, 30]);
        for (const [step] of [...onto, ...wheel].sort((x, y) => Math.abs(x[0]) + x[1] - Math.abs(y[0]) - y[1])) {
          if (!clear(fromLch(from[0].L, from[0].C, from[0].h + step))) continue;
          grp.forEach((x, i) => { if (from[i]) map.set(x, fromLch(from[i].L, from[i].C, from[i].h + step)); });
          break;
        }
      });
      return [...map];
    }
    function linesOf(reg, got, match) {
      if (!got.pal.match) return layers(got);
      const base = got.st.palettes.find(p => p.id === got.pal.match && !p.match) || got.st.palettes[0];
      const lines = layers({ st: got.st, pal: base });
      const cs = match && Array.isArray(match.colours) ? match.colours.map(String) : [];
      return cs.length >= 2 && hexIn(cs[0]) && hexIn(cs[1]) ? paint(lines, cs, Object.assign({ ground: got.pal.matchGround }, lawsOf(reg))) : lines;
    }
    function compose(reg, styleId, paletteId, match) {
      const got = pick(reg, styleId, paletteId);
      if (!got) return "";
      const { st, pal } = got;
      const faces = st.faces.map(f => f.css).join("\n");
      const lines = linesOf(reg, got, match).map(([k, v]) => "  " + k + ": " + v + ";").join("\n");
      const rules = rulesOf(st);
      const mark = st.id + "/" + pal.id + "/" + hash(faces + lines + rules);
      return (faces ? faces + "\n" : "") + "body, body.theme-dark, body.theme-light {\n  --vault-theme: \"" + mark + "\";\n" + lines + (lines ? "\n" : "") + "}\n" + rules;
    }
    const marked = css => { const m = String(css || "").match(/--vault-theme:\s*"([^"]*)"/); return m ? m[1] : ""; };
    function vars(reg, styleId, paletteId, match) {
      const got = pick(reg, styleId, paletteId);
      return got ? linesOf(reg, got, match) : [];
    }
    function tinted(reg, styleId, paletteId, colours) {
      const got = pick(reg, styleId, paletteId);
      const cs = Array.isArray(colours) ? colours.map(String) : [];
      if (!got || cs.length < 2 || !hexIn(cs[0]) || !hexIn(cs[1])) return [];
      const base = got.pal.match ? (got.st.palettes.find(p => p.id === got.pal.match && !p.match) || got.st.palettes[0]) : got.pal;
      const ground = got.pal.match ? got.pal.matchGround : (got.st.palettes.find(p => p.match) || {}).matchGround;
      return paint(layers({ st: got.st, pal: base }), cs, Object.assign({ ground }, lawsOf(reg)));
    }
    return { parse, pick, compose, vars, tinted, marked, pictureColours };
  })();

  const KEYS = [];
  const vaultKeys = kind => KEYS.filter(k => !kind || k.views.includes(kind)).map(k => ({ ...k }));

  const money = (() => {
    const KINDS = dayNote.SPENT;
    const two = n => String(n).padStart(2, "0");
    const isoOf = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
    const atNoon = iso => new Date(iso + "T12:00:00");
    const shift = (iso, n) => { const d = atNoon(iso); d.setDate(d.getDate() + n); return isoOf(d); };
    const diff = (iso, from) => Math.round((atNoon(iso) - atNoon(from)) / 864e5);
    const clampDom = (y, m, dom) => { const last = new Date(y, m + 1, 0).getDate(); return isoOf(new Date(y, m, Math.min(dom, last), 12)); };
    const isoLike = v => /^\d{4}-\d{2}-\d{2}$/.test(String(v || ""));
    const obj = v => v && typeof v === "object" && !Array.isArray(v) ? v : {};

    function dayFlow(text) {
      const grab = field => { let sum = 0; for (const m of String(text || "").matchAll(new RegExp(field + "::\\s*(-?[0-9]+(?:\\.[0-9]+)?)", "g"))) sum += parseFloat(m[1]) || 0; return sum; };
      const byCat = Object.fromEntries(KINDS.map(k => [k, grab("spent_" + k)]));
      return { income: grab("income_work") + grab("income_other"), spend: Object.values(byCat).reduce((a, b) => a + b, 0), byCat };
    }
    function nextPayday(S, today) {
      const t = atNoon(today);
      if (S.fin_payday_mode === "weekly") { let add = (Number(S.fin_payday_weekday) - t.getDay() + 7) % 7; if (add === 0) add = 7; return shift(today, add); }
      if (S.fin_payday_mode === "monthly") { let c = clampDom(t.getFullYear(), t.getMonth(), Number(S.fin_payday_day) || 28); if (c <= today) c = clampDom(t.getFullYear(), t.getMonth() + 1, Number(S.fin_payday_day) || 28); return c; }
      if (S.fin_payday_mode === "dates") { const fut = (S.fin_payday_dates || []).map(String).filter(d => d > today).sort(); if (fut.length) return fut[0]; }
      return shift(today, 30);
    }
    const keyOf = fx => String(fx.label || fx.type || "bill").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "bill";
    const recurOf = fx => fx.recur === "weekly" || fx.recur === "once" ? fx.recur : "monthly";
    function nextDue(fx, S, today) {
      const lastPaid = String(obj(S.paid)[keyOf(fx)] || ""), recur = recurOf(fx);
      if (recur === "once") { const dt = isoLike(fx.date) ? String(fx.date) : today; return lastPaid >= dt ? null : dt; }
      if (recur === "weekly") {
        let due = shift(today, (Number(fx.weekday ?? 5) - atNoon(today).getDay() + 7) % 7), g = 0;
        while (due <= lastPaid && g++ < 60) due = shift(due, 7);
        return due;
      }
      const t = atNoon(today); let y = t.getFullYear(), m = t.getMonth(), due = clampDom(y, m, Number(fx.day) || 1), g = 0;
      while ((due < today || due <= lastPaid) && g++ < 24) { m++; if (m > 11) { m = 0; y++; } due = clampDom(y, m, Number(fx.day) || 1); }
      return due;
    }
    function fixedRows(S, envMap, today, payday) {
      const defMap = obj(S.deferred);
      return (S.fixed_costs || []).map((fx, i) => {
        const key = keyOf(fx), due = nextDue(fx, S, today);
        if (!due) return null;
        const recur = recurOf(fx), amount = Number(fx.amount) || 0, env = Math.min(amount, Number(envMap[key]) || 0);
        const remaining = Math.max(0, amount - env), daysTo = diff(due, today), overdue = recur === "once" && daysTo < 0, deferred = String(defMap[key] || "") > today;
        return { ...fx, i, key, recur, due, amount, env, remaining, daysTo, overdue, deferred, inWindow: due <= payday,
          rate: overdue || deferred || remaining <= 0 ? 0 : remaining / Math.max(1, daysTo) };
      }).filter(Boolean).sort((x, y) => x.due.localeCompare(y.due));
    }
    function accrue(S, today) {
      let last = isoLike(S.env_last_accrual) ? String(S.env_last_accrual) : shift(today, -1);
      if (last >= today) return null;
      const env = Object.assign({}, obj(S.envelopes));
      let iso = shift(last, 1), steps = 0;
      while (iso <= today && steps++ < 31) {
        fixedRows(S, env, today, nextPayday(S, today)).forEach(fx => {
          if (fx.remaining <= 0 || fx.overdue || fx.deferred) return;
          const d = Math.max(1, Math.round((atNoon(fx.due) - atNoon(iso)) / 864e5));
          env[fx.key] = Math.round(((Number(env[fx.key]) || 0) + fx.remaining / d) * 100) / 100;
        });
        iso = shift(iso, 1);
      }
      return env;
    }
    function reckon(S, days, today) {
      const anchor = isoLike(S.fin_anchor_date) ? String(S.fin_anchor_date) : null;
      const flowFrom = anchor || shift(today, -120), flowDays = days.filter(d => d.iso >= flowFrom);
      const balance = Number(S.fin_anchor_amount || 0) + flowDays.reduce((a, d) => a + d.income, 0) - flowDays.reduce((a, d) => a + d.spend, 0);
      const payday = nextPayday(S, today), daysTo = Math.max(1, diff(payday, today));
      const rows = fixedRows(S, obj(S.envelopes), today, payday);
      const savTarget = Number(S.fin_savings_target) || 0;
      const savDaily = savTarget > 0 ? savTarget / Math.max(1, diff(String(S.fin_savings_by), today)) : 0;
      const savingsReserve = String(S.sav_deferred_until || "") > today ? 0 : savDaily * daysTo;
      const needsSet = new Set(S.fin_cat_needs || []), from28 = shift(today, -28);
      let needs28 = 0; days.forEach(d => { if (d.iso >= from28) Object.entries(d.byCat).forEach(([c, v]) => { if (needsSet.has(c)) needs28 += v; }); });
      const needsCost = needs28 / 28 * daysTo;
      const envHeld = rows.reduce((a, fx) => a + fx.env, 0);
      rows.forEach(fx => { fx.committed = fx.deferred || fx.overdue ? 0 : fx.inWindow ? fx.remaining : Math.min(fx.remaining, fx.rate * daysTo); });
      const committed = rows.reduce((a, fx) => a + fx.committed, 0);
      const r2 = balance - needsCost, r3 = r2 - envHeld, r4 = r3 - committed, wf4 = r4 - savingsReserve;
      return { anchored: !!anchor, anchor, flowFrom, flowDays, balance, payday, daysTo, rows, envHeld, committed, needsCost, savingsReserve, savDaily, r2, r3, r4, wf4, safe: wf4 / daysTo };
    }
    async function days(app, folder, from, to, read) {
      const dir = String(folder || "").replace(/\/?$/, "/");
      const files = (app.vault.getFiles() || []).filter(f => (dir === "/" || f.path.startsWith(dir)) && isoLike(f.basename) && f.basename >= from && f.basename <= to)
        .sort((a, b) => a.basename.localeCompare(b.basename));
      const out = [];
      for (const f of files) { let t = ""; try { t = await (read ? read(f) : app.vault.cachedRead(f)); } catch (e) { continue; } out.push(Object.assign({ iso: f.basename }, dayFlow(t))); }
      return out;
    }
    async function wants(app, read) {
      const out = [];
      for (const f of app.vault.getMarkdownFiles() || []) {
        const fm = (app.metadataCache.getFileCache(f) || {}).frontmatter || {};
        if (String(fm.type || "") !== "want" || /^(got|bought|dropped)$/i.test(String(fm.status || "").trim())) continue;
        let text = ""; try { text = read ? await read(f) : await app.vault.cachedRead(f); } catch (e) {}
        const m = /^\s*-?\s*price::[ \t]*([^\n]*)$/m.exec(text || ""), price = m ? parseFloat(m[1].replace(/[^\d.]/g, "")) || 0 : 0;
        if (price > 0) out.push({ path: f.path, title: f.basename, price });
      }
      return out.sort((a, b) => a.price - b.price);
    }
    const daysOf = (price, safe) => safe > 0 && price > 0 ? Math.ceil(price / safe - 1e-9) : null;
    return { KINDS, dayFlow, nextPayday, keyOf, recurOf, nextDue, fixedRows, accrue, reckon, days, wants, daysOf };
  })();

  const vaultSettings = (() => {
    const PATH = "99_Meta/Vault Settings.md";
    const read = app => {
      try { const f = app.vault.getAbstractFileByPath(PATH); return Object.assign({}, (f && (app.metadataCache.getFileCache(f) || {}).frontmatter) || {}); }
      catch (e) { return {}; }
    };
    async function write(app, patch) {
      const f = app.vault.getAbstractFileByPath(PATH);
      if (!f) return null;
      let wrote = null;
      await app.fileManager.processFrontMatter(f, fm => { Object.entries(patch || {}).forEach(([k, v]) => { if (v === null) delete fm[k]; else fm[k] = v; }); wrote = { ...fm }; });
      return wrote;
    }
    return { PATH, read, write };
  })();

  const tasks = (() => {
    const LINE = /^(\s*(?:>\s*)*-\s\[)([ xX])(\]\s?)(.*)$/;
    const two = n => String(n).padStart(2, "0");
    const shift = (iso, n) => { const d = new Date(iso + "T12:00:00"); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`; };
    const dated = (body, m) => { const i = body.indexOf(m); if (i < 0) return ""; const x = /^\s*(\d{4}-\d{2}-\d{2})/.exec(body.slice(i + m.length)); return x ? x[1] : ""; };
    const MARKS = /(?:📅|⏳|✅|➕)\s*\d{4}-\d{2}-\d{2}/gu;
    function parse(line) {
      const m = LINE.exec(String(line || "")); if (!m) return null;
      const body = m[4].replace(/\r$/, "");
      const every = (/🔁\s*([^#📅⏳✅➕]+)/u.exec(body) || [, ""])[1].trim();
      const text = body.replace(/\[\[([^|\]]+)(?:\|([^\]]+))?\]\]/g, (_, a, b) => b || a).replace(MARKS, "").replace(/🔁[^#📅⏳✅➕]*/gu, "")
        .replace(/#\S+/g, "").replace(/\s*\^[\w-]+\s*$/, "").replace(/\s+/g, " ").trim();
      return { done: m[2] !== " ", body, text, plain: body.replace(/\s*#task\b/g, "").replace(/\s*📅\s*\d{4}-\d{2}-\d{2}/u, "").trim(),
        due: dated(body, "📅"), someday: dated(body, "⏳"), fin: dated(body, "✅"), made: dated(body, "➕"), every,
        task: /#task\b/.test(body), study: /#study\b/.test(body), q: (/#eis\/(do|schedule|delegate|eliminate)\b/.exec(body) || [, null])[1] };
    }
    function tick(line, on, iso) {
      const m = LINE.exec(String(line || "")); if (!m) return line;
      const cr = /\r$/.test(m[4]) ? "\r" : "", body = m[4].replace(/\r$/, "").replace(/\s*✅\s*\d{4}-\d{2}-\d{2}/u, "");
      return m[1] + (on ? "x" : " ") + m[3] + body + (on ? ` ✅ ${iso}` : "") + cr;
    }
    async function tickAt(app, path, at, raw, on, iso) {
      const f = app.vault.getAbstractFileByPath(path); if (!f) return null;
      const before = await app.vault.read(f), L = before.split("\n");
      if (L[at] !== raw) { const k = L.indexOf(raw); if (k < 0) return null; at = k; }
      L[at] = tick(raw, on, iso);
      await app.vault.modify(f, L.join("\n"));
      return { path, before };
    }
    async function carried(app, folder, iso, { days = 21, read } = {}) {
      const dir = folder ? String(folder).replace(/\/?$/, "/") : "", from = shift(iso, -days), out = [];
      const files = (app.vault.getMarkdownFiles() || []).filter(f => /^\d{4}-\d{2}-\d{2}$/.test(f.basename) && f.basename < iso && f.basename >= from && (!dir || f.path.startsWith(dir)));
      for (const f of files) {
        let t = ""; try { t = String(read ? await read(f) : await app.vault.cachedRead(f)); } catch (e) { continue; }
        t.split("\n").forEach((raw, line) => { const k = parse(raw); if (k && !k.done && k.due && k.due <= iso && !k.someday) out.push(Object.assign({ path: f.path, day: f.basename, line, raw }, k)); });
      }
      return out.sort((a, b) => a.due.localeCompare(b.due) || a.day.localeCompare(b.day));
    }
    return { LINE, parse, tick, tickAt, carried };
  })();

  const habits = (() => {
    const offered = () => [["", "by hand"], ["journal", "the journal"], ...Object.entries(SOURCES).map(([k, s]) => [k, s.label]), ["weight", "a weight"]];
    const journalled = text => {
      const L = String(text || "").replace(/\r\n/g, "\n").split("\n"), h = L.findIndex(l => /^##\s+Journal\s*$/.test(l));
      if (h < 0) return false;
      for (let i = h + 1; i < L.length && !/^#{1,2}\s/.test(L[i]); i++) if (/^\*\*\d{1,2}:\d{2}\*\*/.test(L[i].trim())) return true;
      return false;
    };
    function kept(h, rec) {
      if (!h || !rec) return false;
      if (rec.fm && rec.fm["habit_" + h.id] === true) return "hand";
      const from = String(h.from || "").trim();
      if (!from) return false;
      if (from === "journal") return journalled(rec.text) ? from : false;
      if (SOURCES[from]) return rec.by && rec.by[from] ? from : false;
      const v = rec.fm ? rec.fm[from] : undefined;
      return v != null && v !== "" && v !== false ? from : false;
    }
    const wants = list => new Set((list || []).map(h => String((h && h.from) || "").trim()).filter(Boolean));
    async function records(app, isos, list, { today = isos[isos.length - 1], read } = {}) {
      const need = wants(list), dir = dailyFolder(app), out = {}, by = {};
      for (const k of need) {
        if (!SOURCES[k]) continue;
        try { by[k] = new Set((await SOURCES[k].read(app, isos, { today, read })) || []); } catch (e) { by[k] = new Set(); }
      }
      for (const iso of isos) {
        const f = app.vault.getAbstractFileByPath(`${dir ? dir + "/" : ""}${iso}.md`);
        const fm = (f && (app.metadataCache.getFileCache(f) || {}).frontmatter) || {};
        let text = "";
        if (f && need.has("journal")) { try { text = String(read ? await read(f) : await app.vault.cachedRead(f)); } catch (e) {} }
        out[iso] = { fm, text, by: Object.fromEntries(Object.entries(by).map(([k, s]) => [k, s.has(iso)])) };
      }
      return out;
    }
    return { get SOURCES() { return offered(); }, kept, wants, records };
  })();

  const kinds = (() => {
    const LIT = "01_Zettelkasten/Literature/", PERM = "01_Zettelkasten/Permanent/";
    const INBOX = "00_Inbox/Inbox.md";
    const STATES = ["queue", "active", "done", "dropped"], WANT_STATES = ["want", "got", "dropped"];
    const LIT_TYPES = ["movie", "show", "book", "course", "video", "article", "podcast", "album", "game"];
    const two = n => String(n).padStart(2, "0");
    const idOf = d => `${d.getFullYear()}${two(d.getMonth() + 1)}${two(d.getDate())}${two(d.getHours())}${two(d.getMinutes())}${two(d.getSeconds())}`;
    const dayOf = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
    const atOf = d => `${dayOf(d)} ${two(d.getHours())}:${two(d.getMinutes())}`;
    const idSafe = s => String(s || "").replace(/[\\/:*?"<>|#^[\]]/g, "–").trim();
    const litSafe = s => String(s || "").replace(/\s+[-|]\s+|:\s+/g, " — ").replace(/\[/g, "(").replace(/\]/g, ")").replace(/[\\/]/g, "-")
      .replace(/[:*?"<>|#^]/g, "").replace(/\s+/g, " ").trim();
    const F2 = (k, v) => `- ${k}:: ${v == null ? "" : v}`;
    const yaml = v => { v = String(v == null ? "" : v).trim(); return !v ? "" : /[:#\[\]{}&*!|>'"%@`,?]|^[-\s]/.test(v) ? JSON.stringify(v) : v; };
    const status = (st, list = STATES) => (list.includes(st) ? st : list[0]);

    function literature(type, title, st = "queue", now = new Date(), d = {}) {
      st = status(st); type = LIT_TYPES.includes(type) ? type : "book";
      const head = ["---", `id: ${idOf(now)}`, `created: ${atOf(now)}`, "type: literature", "tags:", "  - literature", `  - ${type}/${st}`, "---", `# ${title}`, ""];
      const body = type === "book" ? ["## Reference", F2("type", "book"), F2("status", st), F2("author", d.author || ""), F2("genre", ""), F2("rating", ""), F2("page", ""), F2("pages", d.pages || ""), F2("link", d.link || ""),
          "", "## Summary", "*2-3 sentences in your own words.*", "", "## Key Points", "", "## Quotes", "- quote:: ", "", "## Atomic notes spawned", "*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*"]
        : type === "album" ? ["## Reference", F2("type", "album"), F2("status", st), F2("author", d.author || ""), F2("genre", ""), F2("rating", ""), F2("length", d.minutes || ""), F2("link", d.link || ""),
          "", "## Overall Vibe", "*2-3 sentences describing the sound and feel of the album.*", "", "## Standout Tracks", "", "## Favorite Lyrics", "- quote:: ", "", "## Atomic notes spawned", "*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*"]
        : ["## Reference", F2("type", type), F2("status", st), F2("author", d.author || ""), F2("genre", ""), F2("rating", ""), F2("progress", ""), F2("length", d.minutes || ""), F2("platform", d.platform || ""), F2("link", d.link || ""),
          "", "## Summary", "*2-3 sentences in your own words.*", "", "## Key Points", "", "## Quotes", "- quote:: ", "", "## Atomic notes spawned", "*Write the atomic note, link back to this one from inside it, and it appears in the backlinks below.*"];
      return { path: `${LIT}${litSafe(title)}.md`, text: [...head, ...body, ""].join("\n") };
    }
    function want(title, now = new Date()) {
      const text = ["---", `id: ${idOf(now)}`, `created: ${atOf(now)}`, "type: want", "status: want", "tags:", "  - permanent", "  - want", "---", `# ${title}`, "",
        F2("price", ""), F2("where", ""), F2("link", ""), F2("why", ""), "", ""].join("\n");
      return { path: `${PERM}${litSafe(title)}.md`, text };
    }
    function permanent(title, now = new Date(), home = null, tags = []) {
      const tagsArr = ["permanent", ...tags.filter(t => t !== "permanent")];
      const id = idOf(now);
      const text = ["---", `id: ${id}`, `created: ${atOf(now)}`, "type: permanent", ...(home ? [`up: "[[${home.name}]]"`] : []), "tags:", ...tagsArr.map(t => "  - " + t), "---",
        `# ${title}`, "", "*Write the idea in your own words — what it is, why it matters, where it connects.*", ""].join("\n");
      return { path: `${PERM}${id} - ${idSafe(title)}.md`, text };
    }
    return { LIT, PERM, INBOX, STATES, WANT_STATES, LIT_TYPES, idOf, dayOf, atOf, litSafe, idSafe, yaml, F2, status,
      literature, want, permanent };
  })();

  const maps = (() => {
    const FOLDER = "02_Maps/", OLD = "02_MOCs/", ROOT = "02_Maps/Maps.md", ARCHIVE = "Archive";
    const fmOf = (app, f) => (app.metadataCache.getFileCache(f) || {}).frontmatter || {};
    const typeOf = fm => String((fm && fm.type) || "").trim().toLowerCase();
    function upOf(fm) {
      let v = fm && fm.up;
      while (Array.isArray(v)) v = v[0];
      if (v == null) return null;
      const s = String(v).trim().replace(/^\[\[/, "").replace(/\]\]$/, "").split("|")[0].split("#")[0].trim();
      return s || null;
    }
    const isMap = fm => ["map", "moc"].includes(typeOf(fm));
    const NOT_NOTES = ["want", "map", "moc", "maps", "literature", "lesson"];
    function isPermanent(file, fm) {
      const t = typeOf(fm); if (NOT_NOTES.includes(t)) return false;
      return t === "permanent" || String((file && file.path) || "").startsWith(kinds.PERM);
    }
    const isSource = fm => typeOf(fm) === "literature";
    const archivedAt = path => [FOLDER, OLD].some(d => path.startsWith(d + ARCHIVE + "/"));
    const dateOf = v => { const m = /^(\d{4}-\d{2}-\d{2})/.exec(String(v == null ? "" : v).trim()); return m ? m[1] : null; };
    const hasWords = c => ((c && c.sections) || []).some(s => !["yaml", "heading"].includes(s.type));

    function build(app, today) {
      const files = app.vault.getMarkdownFiles() || [];
      const recs = new Map(), notesOf = new Map(), sourcesOf = new Map(), homeOf = new Map(), childrenOf = new Map(), unf = [];
      const resolve = (link, from) => { const d = link ? app.metadataCache.getFirstLinkpathDest(link, from) : null; return d && recs.has(d.path) ? d.path : null; };
      for (const f of files) {
        const fm = fmOf(app, f); if (!isMap(fm)) continue;
        recs.set(f.path, { path: f.path, name: f.basename, mark: String(fm.mark || "").trim(), aliases: [].concat(fm.aliases || []).map(String).filter(Boolean),
          tags: [].concat(fm.tags || []).map(t => String(t).replace(/^#/, "").toLowerCase()).filter(t => t && !["moc", "map"].includes(t)),
          up: null, archived: archivedAt(f.path), resting: dateOf(fm.resting), words: hasWords(app.metadataCache.getFileCache(f)), _up: upOf(fm) });
      }
      for (const m of recs.values()) {
        const to = resolve(m._up, m.path); delete m._up;
        if (to && to !== m.path) { m.up = to; (childrenOf.get(to) || childrenOf.set(to, []).get(to)).push(m); }
      }
      for (const f of files) {
        if (recs.has(f.path)) continue;
        const fm = fmOf(app, f), link = upOf(fm), perm = isPermanent(f, fm), src = !perm && isSource(fm);
        if (!perm && !src) continue;
        const to = resolve(link, f.path);
        if (to) { homeOf.set(f.path, to); const into = perm ? notesOf : sourcesOf; (into.get(to) || into.set(to, []).get(to)).push(f.path); }
        if (perm && (!to || recs.get(to).archived)) unf.push({ path: f.path, why: !link ? "none" : !to ? "missing" : "archived" });
      }
      const byName = (a, b) => a.name.localeCompare(b.name);
      for (const l of childrenOf.values()) l.sort(byName);
      const trail = p => {
        const out = [], seen = new Set(); let m = recs.get(p);
        while (m && !seen.has(m.path)) { seen.add(m.path); out.unshift(m); m = m.up ? recs.get(m.up) : null; }
        return out;
      };
      const below = p => { const out = [], seen = new Set([p]), go = q => (childrenOf.get(q) || []).forEach(c => { if (seen.has(c.path)) return; seen.add(c.path); out.push(c); go(c.path); }); go(p); return out; };
      const count = p => { const all = [p, ...below(p).map(m => m.path)]; return { notes: all.reduce((n, q) => n + (notesOf.get(q) || []).length, 0), topics: all.length - 1, sources: all.reduce((n, q) => n + (sourcesOf.get(q) || []).length, 0) }; };
      const restingUntil = p => trail(p).map(m => m.resting).filter(d => d && d > today).sort().pop() || null;
      const I = {
        today, maps: [...recs.values()].sort(byName),
        byPath: p => recs.get(p) || null,
        home: p => recs.get(homeOf.get(p)) || null,
        trail, below,
        children: p => (childrenOf.get(p) || []).slice(),
        notes: p => (notesOf.get(p) || []).slice(),
        sources: p => (sourcesOf.get(p) || []).slice(),
        count, restingUntil,
        unfiled: () => unf.slice(),
      };
      const said = path => {
        const f = app.vault.getAbstractFileByPath(path), c = (f && app.metadataCache.getFileCache(f)) || {}, fm = c.frontmatter || {};
        const tags = [...[].concat(fm.tags || []), ...(c.tags || []).map(t => t.tag)].map(t => String(t).replace(/^#/, "").toLowerCase()).filter(Boolean);
        const links = (c.links || []).map(l => { const d = app.metadataCache.getFirstLinkpathDest(String(l.link).split("#")[0], path); return d ? d.path : null; }).filter(Boolean);
        return { tags, links, title: f ? f.basename : "" };
      };
      I.guesses = path => guessesFor(I, said(path));
      I.guess = path => I.guesses(path)[0] || null;
      return I;
    }
    const KEPT = new WeakMap(), WATCHED = new WeakSet();
    function index(app, today) {
      const k = KEPT.get(app);
      if (k && k.today === today && WATCHED.has(app)) return k;
      const I = build(app, today);
      KEPT.set(app, I);
      return I;
    }
    function watch(app, hear) {
      if (WATCHED.has(app)) return;
      WATCHED.add(app);
      const drop = () => KEPT.delete(app);
      ["changed", "deleted", "rename"].forEach(ev => { try { hear(app.metadataCache, ev, drop); } catch (e) {} });
    }
    const LINK_ALONE = /^!?\[\[[^\]]*\]\](\s*\|\s*!?\[\[[^\]]*\]\])*$|^!?\[[^\]]*\]\([^)]*\)$/;
    const plain = s => String(s)
      .replace(/!?\[\[([^\]|]*)\|([^\]]*)\]\]/g, "$2").replace(/!?\[\[([^\]]*)\]\]/g, (m, a) => a.split("#")[0].split("/").pop())
      .replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/\*\*|__|`/g, "").replace(/(^|\s)[*_](\S[^*_]*\S|\S)[*_](?=\s|$|[.,;:!?])/g, "$1$2")
      .replace(/\s+/g, " ").trim();
    function lines(text) {
      let t = String(text || "").replace(/\r\n/g, "\n");
      for (let i = 0; i < 2; i++) t = t.replace(/^\s*---\n[\s\S]*?\n---[ \t]*(\n|$)/, "");
      const out = []; let fence = false;
      for (const raw of t.split("\n")) {
        const quoted = /^\s*>/.test(raw), l = raw.trim().replace(/^(>\s?)+/, "").trim();
        if (/^(`{3}|~{3})/.test(l)) { fence = !fence; continue; }
        if (fence || !l || /^\[!/.test(l) || /^#{1,6}(\s|$)/.test(l) || /^(-{3,}|\*{3,}|_{3,})$/.test(l) || /^%%|^<!--|^\|/.test(l)) continue;
        const li = /^(?:[-*+]|\d+[.)])\s+(?:\[.\]\s*)?(.*)$/.exec(l);
        const body = li ? li[1].trim() : l;
        if (!body || LINK_ALONE.test(body) || /^[\w-]+::?\s*\S*$/.test(body) || /^\*\*[^*]+\*\*:?$/.test(body)) continue;
        if (/^\*[^*].*\*$|^_[^_].*_$/.test(body)) continue;
        out.push({ kind: quoted ? "quote" : li ? "list" : "prose", text: body });
      }
      return out;
    }
    const sentenceOf = s => { const m = /^[\s\S]*?[.!?](?=\s|$)/.exec(s); return (m ? m[0] : s).trim(); };
    function start(text) {
      const L = lines(text);
      let at = L.findIndex(x => x.kind !== "quote" && plain(x.text));
      if (at < 0) at = L.findIndex(x => plain(x.text));
      return at < 0 ? [] : L.slice(at).filter(x => x.kind === L[at].kind || (L[at].kind !== "quote" && x.kind !== "quote"));
    }
    function firstSentence(text) { const L = start(text); return L.length ? sentenceOf(plain(L[0].text)) : ""; }
    const OPENING = 600;
    function opening(text, size = OPENING) {
      const s = start(text).map(x => plain(x.text)).join(" ").trim();
      if (s.length <= size) return s;
      const cut = s.slice(0, size), sp = cut.lastIndexOf(" ");
      return (sp > size * 0.6 ? cut.slice(0, sp) : cut).replace(/[\s,;:—-]+$/, "") + "…";
    }
    const norm = s => String(s || "").toLowerCase().replace(/^moc\s*-\s*/, "").replace(/[-_/]+/g, " ").replace(/\s+/g, " ").trim();
    const namesOf = m => [m.name, ...m.aliases].map(norm);
    function byTag(I, t) {
      const parts = t.split("/"), tries = [parts[parts.length - 1], t, parts[0]];
      for (const c of tries) {
        const hit = I.maps.filter(m => namesOf(m).includes(norm(c)) || m.tags.includes(t)).sort((a, b) => a.archived - b.archived)[0];
        if (hit) return hit;
      }
      return null;
    }
    function guessesFor(I, { tags = [], links = [], title = "" }) {
      const out = [], add = (map, why) => { if (map && out.length < 2 && !out.some(g => g.map === map)) out.push({ map, why }); };
      for (const t of tags) { const m = byTag(I, String(t).replace(/^#/, "").toLowerCase()); if (m) add(m, `tagged #${t}`); }
      for (const l of links) { const m = I.byPath(l); if (m) add(m, `links to ${m.name}`); }
      const per = new Map(); for (const l of links) { const h = I.home(l); if (h) per.set(h, (per.get(h) || 0) + 1); }
      [...per].filter(([, k]) => k >= 2).sort((a, b) => b[1] - a[1]).forEach(([m]) => add(m, `its links point into ${m.name}`));
      const words = ` ${norm(title).replace(/[^a-z0-9 ]+/g, " ")} `;
      I.maps.map(m => ({ m, n: namesOf(m).filter(x => x && words.includes(` ${x} `)).sort((a, b) => b.length - a.length)[0] }))
        .filter(x => x.n).sort((a, b) => b.n.length - a.n.length || a.m.archived - b.m.archived).forEach(x => add(x.m, `its title names ${x.m.name}`));
      return out;
    }
    const guessForText = (I, { tags = [], title = "" } = {}) => guessesFor(I, { tags, title });

    function scoreOf(I, m, q) {
      const names = [m.name, ...m.aliases];
      let best = 0, via = null;
      names.forEach((raw, i) => {
        const ns = [raw.toLowerCase(), norm(raw)];
        const s = Math.max(...ns.map(n => n === q ? 100 : n.startsWith(q) ? 80 : n.split(/[\s&-]+/).some(w => w && w.startsWith(q)) ? 60 : n.includes(q) ? 40 : 0));
        if (s > best) { best = s; via = i ? raw : null; }
      });
      if (!best && I.trail(m.path).map(x => x.name).join(" › ").toLowerCase().includes(q)) best = 30;
      if (!best) { let i = 0; for (const c of norm(m.name)) if (c === q[i]) i++; if (i === q.length) best = 15; }
      return { score: best, via };
    }
    function rank(query, I) {
      const q = String(query || "").trim().toLowerCase(); if (!q) return [];
      return I.maps.map(m => Object.assign({ map: m }, scoreOf(I, m, q))).filter(x => x.score)
        .sort((a, b) => b.score - a.score || a.map.archived - b.map.archived || a.map.name.localeCompare(b.map.name));
    }
    function pickerRows({ query = "", guesses = [], lately = [], index: I, from = null, moving = null, parentAt = 0 }) {
      const out = [], q = String(query || "").replace(/\s+/g, " ").trim();
      const barred = new Set([from, ...(moving ? [moving, ...I.below(moving).map(m => m.path)] : [])].filter(Boolean));
      const key = m => I.trail(m.path).map(x => x.name).join(" › ");
      const live = I.maps.filter(m => !m.archived && !barred.has(m.path)).sort((a, b) => key(a).localeCompare(key(b)));
      const listed = new Set();
      const put = (m, group, why = "") => { listed.add(m.path); out.push({ kind: "map", map: m, group, why }); };
      if (!q) {
        guesses.slice(0, 2).forEach(g => { if (g && g.map && !barred.has(g.map.path) && !listed.has(g.map.path)) put(g.map, "best guess", g.why || ""); });
        lately.map(p => I.byPath(p)).forEach(m => { if (m && !m.archived && !barred.has(m.path) && !listed.has(m.path)) put(m, "lately"); });
        live.forEach(m => { if (!listed.has(m.path)) put(m, "maps and topics"); });
        const n = I.maps.filter(m => m.archived && !barred.has(m.path)).length;
        if (n) out.push({ kind: "archived-fold", n });
        return out;
      }
      const hits = rank(q, I).filter(x => !barred.has(x.map.path));
      const exact = hits.some(x => x.score === 100);
      const name = q.charAt(0).toUpperCase() + q.slice(1);
      const g0 = (guesses.find(g => g && g.map && !g.map.archived && !barred.has(g.map.path)) || {}).map;
      const parents = g0 ? [g0, ...live.filter(m => m !== g0)] : live;
      const make = exact ? [] : [{ kind: "new-map", name }, ...(parents.length ? [{ kind: "new-topic", name, parent: parents[((parentAt % parents.length) + parents.length) % parents.length] }] : [])];
      const row = x => ({ kind: "map", map: x.map, group: x.map.archived ? "archived" : "found", why: x.via ? `also called ${x.via}` : "" });
      const strong = hits.filter(x => x.score >= 60), weak = hits.filter(x => x.score < 60);
      return strong.length ? [...strong.map(row), ...make, ...weak.map(row)] : [...make, ...hits.map(row)];
    }
    const place = (app, mk) => ({ path: mk.path, text: mk.text, map: null });
    const BAD = /[\\/:*?"<>|#^[\]]/g;
    const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const dayName = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || "")); return m ? `${+m[3]} ${MONTHS[+m[2] - 1]}` : String(iso || ""); };
    const now = () => kinds.dayOf(new Date());
    const fileAt = (app, p) => app.vault.getAbstractFileByPath(p);
    const link = m => `[[${m.name}]]`;
    const nameOf = f => f.basename || String(f.path).split("/").pop().replace(/\.md$/, "");
    async function folder(app, dir) { if (dir && !fileAt(app, dir)) { try { await app.vault.createFolder(dir); } catch (e) {} } }
    async function keep(app, files) { const out = []; for (const f of files) out.push({ path: f.path, text: await app.vault.read(f) }); return out; }
    const putBack = (app, kept) => async () => { for (const k of kept) { const f = fileAt(app, k.path); if (f) await app.vault.modify(f, k.text); else await app.vault.create(k.path, k.text); } };
    const both = (...fns) => async () => { for (const fn of fns.filter(Boolean).reverse()) await fn(); };
    async function move(app, m, to) {
      const f = fileAt(app, m.path); if (!f) return { why: `${m.name} is not in the vault` };
      if (fileAt(app, to)) return { why: `${to} is in the vault already` };
      await folder(app, to.slice(0, to.lastIndexOf("/")));
      const from = m.path;
      await app.fileManager.renameFile(f, to);
      return { path: to, undo: async () => { const g = fileAt(app, to); if (g) await app.fileManager.renameFile(g, from); } };
    }
    async function make(app, { name, mark = "", up = null } = {}) {
      name = String(name || "").replace(/\s+/g, " ").trim();
      if (!name) return { why: "a map wants a name" };
      const bad = [...new Set(name.match(BAD) || [])];
      if (bad.length) return { why: `a map's name cannot hold ${bad.join(" ")}` };
      const I = index(app, now()), n = norm(name);
      const twin = I.maps.find(m => namesOf(m).includes(n));
      if (twin && twin.archived) return { why: `${twin.name} is an archived map`, archived: twin };
      if (twin) return { why: `${twin.name} is a map already${twin.name.toLowerCase() === name.toLowerCase() ? "" : `, called ${name} too`}` };
      if ((app.vault.getMarkdownFiles() || []).some(f => nameOf(f).toLowerCase() === name.toLowerCase())) return { why: `a note is called ${name} already, so a link to the map would land on it` };
      const path = `${FOLDER}${name}.md`;
      await folder(app, FOLDER.replace(/\/$/, ""));
      const text = ["---", "type: map", ...(mark ? [`mark: ${kinds.yaml(mark)}`] : []), ...(up ? [`up: "${link(up)}"`] : []), "---", ""].join("\n");
      await app.vault.create(path, text);
      const rec = { path, name, mark, aliases: [], tags: [], up: up ? up.path : null, archived: false, resting: null, words: false };
      return { map: rec, said: `<b>${esc(name)}</b>, a new ${up ? `topic under ${esc(up.name)}` : "map"}`,
        undo: async () => { const f = fileAt(app, path); if (f) await app.vault.trash(f, true); } };
    }
    async function archive(app, m) {
      if (m.archived) return { why: `${m.name} is archived already` };
      const r = await move(app, m, `${FOLDER}${ARCHIVE}/${m.name}.md`); if (r.why) return r;
      return { said: `<b>${esc(m.name)}</b> archived; filing into it brings it back`, undo: r.undo };
    }
    async function bringBack(app, m) {
      if (!m.archived) return { why: `${m.name} is not archived` };
      const r = await move(app, m, `${FOLDER}${m.name}.md`); if (r.why) return r;
      return { said: `<b>${esc(m.name)}</b> brought back`, undo: r.undo, map: Object.assign({}, m, { path: r.path, archived: false }) };
    }
    async function homeFor(app, target) {
      if (target.map) {
        if (!target.map.archived) return { map: target.map, said: "", undo: null };
        const b = await bringBack(app, target.map); if (b.why) return b;
        return { map: b.map, said: ", brought back", undo: b.undo };
      }
      const r = await make(app, { name: target.name, mark: target.mark, up: target.make === "topic" ? target.parent : null });
      if (r.archived) return homeFor(app, { map: r.archived });
      if (r.why) return r;
      return { map: r.map, said: `, a new ${target.make === "topic" ? `topic under ${esc(target.parent.name)}` : "map"}`, undo: r.undo };
    }
    async function setHome(app, files, target) {
      files = files.filter(Boolean); if (!files.length) return { why: "no note was given" };
      const h = target ? await homeFor(app, target) : { map: null, said: "", undo: null };
      if (h.why) return h;
      const kept = await keep(app, files);
      for (const f of files) await app.fileManager.processFrontMatter(f, fm => { if (h.map) fm.up = link(h.map); else delete fm.up; });
      const who = files.length === 1 ? `<b>${esc(nameOf(files[0]))}</b>` : `${files.length} notes`;
      return { map: h.map, said: h.map ? `${who} → ${esc(h.map.name)}${h.said}` : `${who}: no home, waiting in Unfiled`, undo: both(h.undo, putBack(app, kept)) };
    }
    async function rest(app, m, iso) {
      const f = fileAt(app, m.path); if (!f) return { why: `${m.name} is not in the vault` };
      const kept = await keep(app, [f]);
      await app.fileManager.processFrontMatter(f, fm => { if (iso) fm.resting = iso; else delete fm.resting; });
      return { said: iso ? `<b>${esc(m.name)}</b> rests until ${dayName(iso)}` : `<b>${esc(m.name)}</b> is awake`, undo: putBack(app, kept) };
    }
    async function notPermanent(app, f) {
      const to = `${kinds.INBOX.slice(0, kinds.INBOX.lastIndexOf("/") + 1)}${f.name || nameOf(f) + ".md"}`;
      const kept = await keep(app, [f]), name = nameOf(f);
      const r = await move(app, { path: f.path, name }, to); if (r.why) return r;
      const g = fileAt(app, to);
      if (g) await app.fileManager.processFrontMatter(g, fm => { if (typeOf(fm) === "permanent") delete fm.type; });
      return { said: `<b>${esc(name)}</b> → the inbox, as not a permanent note`, undo: async () => { await r.undo(); await putBack(app, kept)(); } };
    }
    const under = (I, m, p) => p && (p.path === m.path || I.below(m.path).some(x => x.path === p.path));
    async function moveMap(app, m, parent) {
      const I = index(app, now());
      if (under(I, m, parent)) return { why: `${m.name} cannot go under ${parent.path === m.path ? "itself" : `its own topic ${parent.name}`}` };
      const f = fileAt(app, m.path); if (!f) return { why: `${m.name} is not in the vault` };
      const kept = await keep(app, [f]);
      await app.fileManager.processFrontMatter(f, fm => { if (parent) fm.up = link(parent); else delete fm.up; });
      return { said: parent ? `<b>${esc(m.name)}</b> → under ${esc(parent.name)}` : `<b>${esc(m.name)}</b> is a map of its own`, undo: putBack(app, kept) };
    }
    async function merge(app, from, into) {
      const I = index(app, now());
      if (!into || under(I, from, into)) return { why: `${from.name} cannot be merged into ${into && into.path !== from.path ? `its own topic ${into.name}` : "itself"}` };
      const paths = [...I.notes(from.path), ...I.sources(from.path), ...I.children(from.path).map(m => m.path)];
      const files = paths.map(p => fileAt(app, p)).filter(Boolean), self = fileAt(app, from.path);
      const kept = await keep(app, [...files, ...(self ? [self] : [])]);
      for (const f of files) await app.fileManager.processFrontMatter(f, fm => { fm.up = link(into); });
      if (self) await app.vault.trash(self, true);
      return { said: `<b>${esc(from.name)}</b> merged into ${esc(into.name)}: ${files.length} moved`, undo: putBack(app, kept) };
    }
    const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
    const tagsOf = c => [...[].concat((c.frontmatter || {}).tags || []), ...(c.tags || []).map(t => t.tag)].map(t => String(t).replace(/^#/, "").toLowerCase()).filter(Boolean);
    function splitGroups(I, mapPath, app) {
      const m = I.byPath(mapPath); if (!m) return [];
      const notes = I.notes(mapPath), inMap = new Set(notes), cacheOf = p => { const f = fileAt(app, p); return (f && app.metadataCache.getFileCache(f)) || {}; };
      const taken = new Set(), out = [];
      const to = new Map(), up = new Map();
      for (const p of notes) for (const l of cacheOf(p).links || []) {
        const d = app.metadataCache.getFirstLinkpathDest(String(l.link).split("#")[0], p); if (!d || d.path === p || !inMap.has(d.path)) continue;
        const s = to.get(d.path) || to.set(d.path, new Set()).get(d.path); s.add(p);
        if (/^↑/.test(String(l.displayText || ""))) up.set(d.path, (up.get(d.path) || 0) + 1);
      }
      const hubs = [...to].map(([h, s]) => ({ h, s: [...s] })).filter(x => x.s.length >= 3).sort((a, b) => b.s.length - a.s.length || a.h.localeCompare(b.h));
      hubs.forEach(x => taken.add(x.h));
      for (const { h, s } of hubs) {
        const members = s.filter(p => !taken.has(p)); if (members.length < 3) { taken.delete(h); continue; }
        members.forEach(p => taken.add(p));
        const name = nameOf({ path: h }), pts = (up.get(h) || 0) >= members.length;
        out.push({ id: "hub:" + h, name, from: "note", hub: h, why: `${members.length} notes ${pts ? "point up to" : "link to"} the note ${name}`, notes: members });
      }
      const rest = () => notes.filter(p => !taken.has(p));
      const by = (keyOf) => { const g = new Map(); for (const p of rest()) for (const k of keyOf(p)) (g.get(k) || g.set(k, []).get(k)).push(p); return [...g].filter(([, ps]) => ps.length >= 3).sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0])); };
      for (const [t, ps] of by(p => [...new Set(tagsOf(cacheOf(p)).filter(t => t.includes("/")))])) {
        const members = ps.filter(p => !taken.has(p)); if (members.length < 3) continue;
        members.forEach(p => taken.add(p));
        out.push({ id: "tag:" + t, name: cap(t.split("/").pop().replace(/[-_]+/g, " ")), from: "new", hub: null, why: `${members.length} notes share #${t}`, notes: members });
      }
      const skip = new Set(["the", "a", "an", ...norm(m.name).split(" ")]);
      for (const [w, ps] of by(p => { const w = norm(nameOf({ path: p })).split(" ")[0]; return w && !skip.has(w) ? [w] : []; })) {
        const members = ps.filter(p => !taken.has(p)); if (members.length < 3) continue;
        members.forEach(p => taken.add(p));
        const shown = nameOf({ path: members[0] }).split(/\s+/)[0];
        out.push({ id: "word:" + w, name: cap(shown), from: "new", hub: null, why: `${members.length} titles begin with ${cap(shown)}`, notes: members });
      }
      return out;
    }
    async function split(app, { mapPath, groups }) {
      const I = index(app, now()), m = I.byPath(mapPath); if (!m) return { why: "that map is not in the vault" };
      const touched = new Set(); groups.forEach(g => { g.notes.forEach(p => touched.add(p)); if (g.hub) touched.add(g.hub); });
      const kept = await keep(app, [...touched].map(p => fileAt(app, p)).filter(Boolean)), undos = [];
      let moved = 0;
      for (const g of groups) {
        let topic;
        if (g.hub && g.from === "note") {
          const f = fileAt(app, g.hub); if (!f) continue;
          await app.fileManager.processFrontMatter(f, fm => { fm.type = "map"; fm.up = link(m); });
          topic = { name: nameOf(f), path: f.path };
        } else {
          const r = await make(app, { name: g.name, up: m });
          if (r.why) { await both(...undos, putBack(app, kept))(); return { why: `${g.name}: ${r.why}` }; }
          undos.push(r.undo); topic = r.map;
          if (g.hub) { const f = fileAt(app, g.hub); if (f) await app.fileManager.processFrontMatter(f, fm => { fm.up = link(topic); }); }
        }
        for (const p of g.notes) { const f = fileAt(app, p); if (f) { await app.fileManager.processFrontMatter(f, fm => { fm.up = link(topic); }); moved++; } }
      }
      const left = I.notes(mapPath).filter(p => !touched.has(p)).length;
      return { said: `${esc(m.name)}: ${groups.length} ${groups.length === 1 ? "topic" : "topics"} made, ${moved} ${moved === 1 ? "note" : "notes"} moved, ${left} kept`,
        undo: both(...undos, putBack(app, kept)) };
    }

    function unfiledGroups(I, app) {
      const groups = new Map(), loose = [];
      const put = (key, g, p, why) => { const x = groups.get(key) || groups.set(key, Object.assign({ key, notes: [], whys: {} }, g)).get(key); x.notes.push(p); x.whys[p] = why; };
      for (const u of I.unfiled()) {
        if (u.why === "archived") { const h = I.home(u.path); put("map:" + h.path, { kind: "archived", map: h, name: h.name, tag: null }, u.path, `its home, ${h.name}, is archived`); continue; }
        const g = I.guess(u.path);
        if (g) put("map:" + g.map.path, { kind: g.map.archived ? "archived" : "live", map: g.map, name: g.map.name, tag: null }, u.path, g.why);
        else loose.push(u.path);
      }
      const tagsAt = p => { const f = fileAt(app, p); return [...new Set(tagsOf((f && app.metadataCache.getFileCache(f)) || {}))].filter(t => t !== "permanent" && !byTag(I, t)); };
      const per = new Map(); for (const p of loose) for (const t of tagsAt(p)) (per.get(t) || per.set(t, []).get(t)).push(p);
      const done = new Set();
      [...per].sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0])).forEach(([t, ps]) => {
        const left = ps.filter(p => !done.has(p)); if (left.length < 3) return;
        left.forEach(p => { done.add(p); put("tag:" + t, { kind: "new", map: null, name: cap(t.split("/").pop().replace(/[-_]+/g, " ")), tag: t }, p, `tagged #${t}`); });
      });
      loose.filter(p => !done.has(p)).forEach(p => put("none", { kind: "none", map: null, name: "No guess", tag: null }, p, "nothing in it names a map"));
      const order = { live: 0, new: 1, archived: 2, none: 3 };
      return [...groups.values()].map(g => Object.assign(g, { why:
        g.kind === "none" ? "Nothing in them points anywhere. Choose a home, or pick several and make a map for them."
        : g.kind === "new" ? `${g.notes.length} notes share #${g.tag}, and no map has it.`
        : g.kind === "archived" ? `Their home. Bringing ${g.name} back puts it on the rail again.`
        : g.notes.every(p => g.whys[p] === g.whys[g.notes[0]]) ? `Guessed: ${g.whys[g.notes[0]]}.` : "Guessed from their words." }))
        .sort((a, b) => order[a.kind] - order[b.kind] || b.notes.length - a.notes.length || a.name.localeCompare(b.name));
    }
    return { FOLDER, OLD, ROOT, ARCHIVE, upOf, isMap, isPermanent, index, watch, firstSentence, opening, guessForText, rank, pickerRows,
      make, homeFor, setHome, archive, bringBack, rest, notPermanent, moveMap, merge, dayName, splitGroups, split, unfiledGroups, place };
  })();

  const back = (() => {
    const PATH = "99_Meta/Back Today.md", STEPS = [1, 7, 30, 90, 180, 365];
    const HEAD = "The notes that come back: a line a permanent note, with its step, the day it is next due, and the days it was last seen and shown. The Hall and the map pages write it; nothing else needs to.";
    const ISO = /^\d{4}-\d{2}-\d{2}$/;
    const addDays = (iso, n) => { const d = new Date(iso + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
    const keyOf = (file, fm) => (fm && fm.id != null && String(fm.id).trim()) ? String(fm.id).trim() : file.path;
    function parse(text) {
      const t = String(text || "").replace(/\r\n/g, "\n"), since = (/^---\n[\s\S]*?^since:\s*(\d{4}-\d{2}-\d{2})/m.exec(t) || [])[1] || null;
      const recs = new Map();
      for (const l of t.split("\n")) {
        const m = /^- (.+?) \| (.*)$/.exec(l); if (!m) continue;
        const f = {}; m[2].split(" | ").forEach(p => { const i = p.indexOf(":"); if (i > 0) f[p.slice(0, i)] = p.slice(i + 1); });
        const step = Number(f.step);
        if (!f.path || !Number.isInteger(step) || step < 0 || step >= STEPS.length || !ISO.test(f.due || "")) continue;
        recs.set(m[1], { key: m[1], path: f.path, step, due: f.due, seen: ISO.test(f.seen || "") ? f.seen : "", shown: ISO.test(f.shown || "") ? f.shown : "" });
      }
      return { since, recs };
    }
    function serialize(state) {
      const L = [...state.recs.values()].sort((a, b) => a.path.localeCompare(b.path))
        .map(r => `- ${r.key} | path:${r.path} | step:${r.step} | due:${r.due} | seen:${r.seen || ""} | shown:${r.shown || ""}`);
      return ["---", `since: ${state.since || ""}`, "---", HEAD, "", ...L, ""].join("\n");
    }
    function freeDay(state, from, cap) {
      const per = new Map(); for (const r of state.recs.values()) if (r.due >= from) per.set(r.due, (per.get(r.due) || 0) + 1);
      let d = from; while ((per.get(d) || 0) >= cap) d = addDays(d, 1);
      return d;
    }
    function reconcile(state, notes, { today, cap = 5 }) {
      let changed = false;
      if (!state.since) { state.since = today; changed = true; }
      const keep = new Set();
      for (const n of notes) {
        keep.add(n.key);
        const r = state.recs.get(n.key);
        if (r) { if (r.path !== n.path) { r.path = n.path; changed = true; } continue; }
        const made = String(n.created || "").slice(0, 10);
        const due = ISO.test(made) && made > state.since ? addDays(made, STEPS[0]) : freeDay(state, today, Math.max(1, cap));
        state.recs.set(n.key, { key: n.key, path: n.path, step: 0, due, seen: "", shown: "" });
        changed = true;
      }
      if (!notes.partial) for (const k of [...state.recs.keys()]) if (!keep.has(k)) { state.recs.delete(k); changed = true; }
      return changed;
    }
    function todayList(state, { today, cap = 5, held = new Set() }) {
      const all = [...state.recs.values()], byDue = (a, b) => a.due.localeCompare(b.due) || a.path.localeCompare(b.path);
      const shown = all.filter(r => r.shown === today), due = all.filter(r => r.shown !== today && r.due <= today).sort(byDue);
      const list = shown.filter(r => !held.has(r.key));
      for (const r of due) { if (list.length >= cap) break; if (!held.has(r.key)) list.push(r); }
      const name = r => r.path.split("/").pop().toLowerCase();
      list.sort((a, b) => name(a).localeCompare(name(b)));
      return { list, seen: list.filter(r => r.seen === today).length, waiting: due.filter(r => !held.has(r.key) && !list.includes(r)).length,
        held: [...shown, ...due].filter(r => held.has(r.key)).length };
    }
    function see(state, key, today, { shown = false } = {}) {
      const r = state.recs.get(key); if (!r) return null;
      if (r.seen !== today) { r.step = Math.min(r.step + 1, STEPS.length - 1); r.due = addDays(today, STEPS[r.step]); r.seen = today; }
      if (shown) r.shown = today;
      return r;
    }
    function sooner(state, key, today) {
      const r = state.recs.get(key); if (!r) return null;
      r.step = Math.max(0, r.step - 1); r.due = addDays(today, STEPS[r.step]);
      return r;
    }
    async function read(app) {
      const f = app.vault.getAbstractFileByPath(PATH);
      return f && f.extension ? parse(await app.vault.cachedRead(f)) : { since: null, recs: new Map() };
    }
    async function write(app, state) {
      const text = serialize(state), f = app.vault.getAbstractFileByPath(PATH);
      if (!f) {
        const dir = PATH.slice(0, PATH.lastIndexOf("/"));
        if (!app.vault.getAbstractFileByPath(dir)) { try { await app.vault.createFolder(dir); } catch (e) {} }
        await app.vault.create(PATH, text);
        return true;
      }
      let changed = false;
      await app.vault.process(f, old => { if (old === text) return old; changed = true; return text; });
      return changed;
    }
    function notes(app) {
      let partial = false;
      const out = (app.vault.getMarkdownFiles() || []).map(f => {
        const c = app.metadataCache.getFileCache(f); if (!c) { partial = true; return null; }
        const fm = c.frontmatter || {};
        return maps.isPermanent(f, fm) ? { key: keyOf(f, fm), path: f.path, created: String(fm.created || "").slice(0, 10) } : null; }).filter(Boolean);
      out.partial = partial;
      return out;
    }
    function hearOpens(app, hear, today) {
      const day = typeof today === "function" ? today : () => today;
      hear(app.workspace, "file-open", async file => {
        if (!file || file.extension !== "md") return;
        const fm = (app.metadataCache.getFileCache(file) || {}).frontmatter || {};
        if (!maps.isPermanent(file, fm)) return;
        const state = await read(app), r = state.recs.get(keyOf(file, fm)), d = day();
        if (!r || r.due > d || r.seen === d) return;
        see(state, r.key, d, { shown: false });
        await write(app, state);
      });
    }
    return { PATH, STEPS, keyOf, parse, serialize, reconcile, todayList, see, sooner, read, write, notes, hearOpens, addDays };
  })();

  const commands = (() => {
    const WORDS = [
      ["task", "a task on today's note"], ["inbox", "a line in the inbox"],
      ["spend", "a spend on today's note — /spend 12.40 food lunch"], ["note", "a permanent note — /note a title #tag"],
      ["want", "a want"], ["weight", "the day's weight — /weight 72.4"],
    ];
    const ALIAS = { buy: "want", idea: "note" };
    const off = w => w === "spend" && !partOn("money");
    const live = () => WORDS.filter(([k]) => !off(k));
    const known = w => !off(w) && WORDS.some(([k]) => k === w);
    const named = (n = 3) => live().slice(0, n).map(([k]) => "/" + k).join(", ");
    const examples = (n = 3) => live().map(([, h]) => (/—\s*(\/\w+[^,]*)/.exec(h) || [])[1]).filter(Boolean).slice(0, n);
    const RUN = {};
    function add({ words = [], alias = {}, run = {} } = {}) {
      const taken = [];
      words.forEach(([w, help]) => { if (WORDS.some(([k]) => k === w) || ALIAS[w]) taken.push(w); else WORDS.push([w, help]); });
      Object.entries(alias).forEach(([a, w]) => { if (known(a) || ALIAS[a]) taken.push(a); else ALIAS[a] = w; });
      Object.entries(run).forEach(([w, fn]) => { if (!taken.includes(w) && !RUN[w]) RUN[w] = fn; });
      return taken;
    }
    function parse(text) {
      const m = /^\/(\w+)\s*([\s\S]*)$/.exec(String(text || "").trim()); if (!m) return null;
      const w = ALIAS[m[1].toLowerCase()] || m[1].toLowerCase();
      return { kind: known(w) ? w : null, word: m[1], rest: m[2].replace(/\s+/g, " ").trim() };
    }
    const two = n => String(n).padStart(2, "0");
    const hmOf = d => `${two(d.getHours())}:${two(d.getMinutes())}`;
    const todayPath = (app, iso) => { const dir = dailyFolder(app); return `${dir ? dir + "/" : ""}${iso}.md`; };
    async function intoToday(app, iso, edit) {
      const f = app.vault.getAbstractFileByPath(todayPath(app, iso));
      if (!f) return { why: "there is no note for today yet — open today's note and it is begun" };
      const before = await app.vault.read(f), L = before.split("\n");
      const no = edit(L); if (typeof no === "string") return { why: no };
      await app.vault.modify(f, L.join("\n"));
      return { path: f.path, before };
    }
    async function append(app, path, line) {
      let f = app.vault.getAbstractFileByPath(path), before = null;
      if (!f) { const dir = path.slice(0, path.lastIndexOf("/")); if (dir && !app.vault.getAbstractFileByPath(dir)) { try { await app.vault.createFolder(dir); } catch (e) {} } f = await app.vault.create(path, line + "\n"); return { path, before, made: false }; }
      before = await app.vault.read(f);
      await app.vault.modify(f, before + (before.endsWith("\n") || !before ? "" : "\n") + line + "\n");
      return { path, before };
    }
    async function make(app, mk0, hay) {
      const mk = maps.place(app, mk0, hay), map = mk.map, text = mk.text;
      if (app.vault.getAbstractFileByPath(mk.path)) return { why: `${mk.path.split("/").pop().replace(/\.md$/, "")} is in the vault already` };
      const dir = mk.path.slice(0, mk.path.lastIndexOf("/"));
      for (let i = 0, parts = dir.split("/"); i < parts.length; i++) { const p = parts.slice(0, i + 1).join("/"); if (p && !app.vault.getAbstractFileByPath(p)) { try { await app.vault.createFolder(p); } catch (e) {} } }
      await app.vault.create(mk.path, text);
      return { path: mk.path, made: true, map };
    }
    const handle = (words, fn) => words.forEach(w => { RUN[w] = fn; });
    handle(["task"], async ({ app, iso, intoToday, dayNote, esc }, rest) => { const r = await intoToday(app, iso, L => dayNote.addTask(L, `${rest} #task 📅 ${iso}`)); return r.why ? r : Object.assign(r, { said: `<b>${esc(rest)}</b> — today's note` }); });
    handle(["inbox"], async ({ app, iso, hm, append, kinds, esc }, rest) => Object.assign(await append(app, kinds.INBOX, `- [ ] ${hm} ${rest} ➕ ${iso}`), { said: `<b>${esc(rest)}</b> — the inbox` }));
    handle(["spend"], async ({ app, iso, hm, intoToday, dayNote, esc }, rest) => {
      const m = /^(\d+(?:\.\d+)?)\s*([a-z]+)?\s*(.*)$/i.exec(rest); if (!m) return { why: "a spend is a figure first — /spend 12.40 food lunch" };
      const cat = (m[2] || "other").toLowerCase(); if (!dayNote.SPENT.includes(cat)) return { why: `a spend is one of ${dayNote.SPENT.join(" · ")}` };
      const r = await intoToday(app, iso, L => dayNote.addMoney(L, "spent_" + cat, +m[1], hm, m[3].trim()));
      return r.why ? r : Object.assign(r, { said: `<b>${(+m[1]).toFixed(2)} ${esc(cat)}</b> — today's note` });
    });
    handle(["note"], async ({ app, iso, now, make, kinds, maps, esc, pick }, rest) => {
      const tags = (rest.match(/#[\w/-]+/g) || []).map(t => t.slice(1).toLowerCase()), title = rest.replace(/#[\w/-]+/g, "").replace(/\s+/g, " ").trim();
      if (!title) return { why: "a note wants a title" };
      const guesses = maps.guessForText(maps.index(app, iso), { tags, title });
      const choice = pick ? await pick({ title, moment: "/note", guesses }) : null;
      const h = choice ? await maps.homeFor(app, choice) : null, home = h && h.map ? h.map : null;
      const r = await make(app, kinds.permanent(title, now, home, tags));
      if (r.why && h && h.undo) await h.undo();
      return r.why ? r : Object.assign(r, { home, said: `<b>${esc(title)}</b> — a permanent note${home ? `, in ${esc(home.name)}${h.said || ""}` : `, waiting in Unfiled${h && h.why ? ` (${esc(h.why)})` : ""}`}` });
    });
    handle(["want"], async ({ app, now, make, kinds, esc }, rest) => { const r = await make(app, kinds.want(rest, now), "want"); return r.why ? r : Object.assign(r, { said: `<b>${esc(rest)}</b> — a want` }); });
    handle(["weight"], async ({ app, iso }, rest) => {
      const n = parseFloat(String(rest).replace(",", ".")); if (!(n > 0)) return { why: "a weight is a figure — /weight 72.4" };
      const f = app.vault.getAbstractFileByPath(todayPath(app, iso)); if (!f) return { why: "there is no note for today yet" };
      const before = await app.vault.read(f);
      await app.fileManager.processFrontMatter(f, fm => { fm.weight = n; });
      return { path: f.path, before, said: `<b>${n}</b> — today's weight` };
    });
    async function run(app, text, { today, now = new Date(), E = null, pick = null } = {}) {
      const p = parse(text);
      if (!p) return { why: `a command begins with a slash and a word — ${named(3)}…` };
      if (!p.kind) return { why: `/${p.word} is not a word the command line knows: ${live().map(([k]) => "/" + k).join(" ")}` };
      const iso = today || kinds.dayOf(now), rest = p.rest, hm = hmOf(now);
      if (!rest && !["weight"].includes(p.kind)) return { why: `/${p.kind} wants what — ${(WORDS.find(([k]) => k === p.kind) || [])[1]}` };
      const fn = RUN[p.kind]; if (!fn) return { why: `/${p.kind} has nothing to do it` };
      return fn({ app, iso, hm, now, E, kinds, maps, dayNote, intoToday, append, make, esc, pick }, rest, p);
    }
    return { WORDS, ALIAS, live, parse, run, add, named, examples };
  })();

  const ROOM_MARK = [[/home|hall/i, "arch"], [/daily|day/i, "sun"]];
  const roomMarks = () => [...MARKS, ...ROOM_MARK].map(([re, i]) => [re, i]);
  const roomMark = name => (roomMarks().find(([re]) => re.test(name)) || [0, "door"])[1];
  async function readRooms(app) {
    let views = null;
    try { const p = app.plugins && app.plugins.getPlugin && app.plugins.getPlugin("custom-views"); views = p && p.settings && p.settings.views; } catch (e) {}
    if (!Array.isArray(views)) {
      try { views = JSON.parse(await app.vault.adapter.read(`${app.vault.configDir}/plugins/custom-views/data.json`)).views; } catch (e) { views = []; }
    }
    const files = app.vault.getMarkdownFiles() || [];
    const tags = f => { const fm = (app.metadataCache.getFileCache(f) || {}).frontmatter || {}; return [].concat(fm.tags || []).flatMap(t => String(t).split(/[,\s]+/)).map(t => t.replace(/^#/, "")).filter(Boolean); };
    const named = rule => {
      const out = [];
      (function walk(r) {
        if (!r) return;
        if (r.type === "group") {
          (r.conditions || []).forEach(walk);
          if (r.operator === "AND") {
            const folder = (r.conditions || []).find(c => c.field === "file.folder" && c.operator === "is"), name = (r.conditions || []).find(c => c.field === "file.name" && c.operator === "is");
            if (folder && name) { const f = app.vault.getAbstractFileByPath(`${folder.value}/${name.value}`); if (f) out.push(f); }
          }
          return;
        }
        if (r.field === "file" && r.operator === "has tag") String(r.value || "").split(/,\s*/).filter(v => /dashboard$/i.test(v)).forEach(v => files.filter(f => tags(f).includes(v)).forEach(f => out.push(f)));
      })(rule);
      return [...new Set(out)];
    };
    return (views || []).map(v => { const found = named(v.rules); return found.length === 1 ? { name: v.name, path: found[0].path, mark: roomMark(v.name) } : null; }).filter(Boolean);
  }

  function dailyFolder(app, settings) {
    const clean = s => String(s || "").replace(/^\/+|\/+$/g, "");
    if (!settings) settings = vaultSettings.read(app);
    try {
      const o = app.internalPlugins && app.internalPlugins.getPluginById && (app.internalPlugins.getPluginById("daily-notes") || {}).instance;
      const set = clean(o && o.options && o.options.folder);
      if (set && app.vault.getAbstractFileByPath(set)) return set;
    } catch (e) {}
    const vs = clean(settings.daily_note_folder);
    if (vs && app.vault.getAbstractFileByPath(vs)) return vs;
    const counts = {};
    (app.vault.getMarkdownFiles() || []).forEach(f => { if (!/^\d{4}-\d{2}-\d{2}$/.test(f.basename)) return; const d = clean(f.path.slice(0, f.path.length - f.name.length)); counts[d] = (counts[d] || 0) + 1; });
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return best ? best[0] : vs || "";
  }

  async function loadModuleOf(app, name, needs = [], box = null, tag = "[NM]") {
    const tried = [], glob = name.replace(/[^A-Za-z0-9_]/g, "_").toUpperCase(), seen = new Set();
    const evaluate = (raw, where) => {
      if (box) box.raw = raw;
      if (!raw || !raw.trim()) throw new Error("read back as empty — 0 bytes on disk, or iCloud is holding it as a placeholder");
      const fenced = raw.match(/`{3}(?:js|javascript)\s*\n([\s\S]*?)`{3}/), src = fenced ? fenced[1] : raw;
      const g = new Function("DAY_SHAPE", "VAULT_MODULE", "app", "NOTE", src + `\nreturn typeof ${glob} !== "undefined" ? ${glob} : null;`)(SHAPE_IN, VAULT_MODULE, app, raw);
      if (!g && needs.length) throw new Error(`the file ran but produced no ${glob}`);
      const missing = needs.filter(k => g[k] === undefined);
      if (missing.length) throw new Error(`${name} at ${where} is older than this needs — missing ${missing.join(", ")}`);
      return g;
    };
    if (box && box.raw != null) {
      try { return evaluate(box.raw, name); } catch (e) { tried.push(`${name} — ${e.message}`); }
      const err = new Error("nothing loaded"); err.tried = tried; throw err;
    }
    try {
      const hits = (app.vault.getFiles() || []).filter(f => f.name.toLowerCase() === (name + ".md").toLowerCase());
      for (const f of hits) { seen.add(f.path); try { return evaluate(await app.vault.read(f), f.path); } catch (e) { tried.push(`${f.path} — ${e.message}`); } }
      if (!hits.length) tried.push(`vault index — nothing named ${name} is indexed`);
    } catch (e) { tried.push("vault index — " + e.message); }
    for (const p of [`99_Meta/Modules/${name}.md`, `99_Meta/${name}.md`, `${name}.md`]) {
      if (seen.has(p)) continue;
      try { return evaluate(await app.vault.adapter.read(p), p); } catch (e) { tried.push(`${p} — ${e.message}`); }
    }
    const err = new Error("nothing loaded"); err.tried = tried; throw err;
  }

  async function loadPacksOf(app, tag = "[NM]") {
    PARTS = null;
    const byPath = (a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
    const files = (app.vault.getFiles() || []).filter(f => /^99_Meta\/Packs\/[^/]+\.md$/i.test(f.path)).sort(byPath);
    const all = (app.vault.getFiles() || []).filter(f => /^99_Meta\/(Packs|Modules)\/[^/]+\.md$/i.test(f.path)).sort(byPath);
    const stamp = VERSION + "|" + all.map(f => f.path + ":" + (f.stat && f.stat.mtime)).join("|");
    const win = typeof window !== "undefined";
    const kept = win ? window.__nmPackNotes : null;
    const fail = (it, e) => {
      const t = (e && e.tried || []).find(x => !/^vault index — /.test(x)) || (e && e.tried || [])[0];
      const why = String(t ? t.replace(/^.*? — /, "") : (e && e.message) || e).split("\n")[0];
      console.warn(tag, "pack", it.id, why);
      if (!REG.list.some(p => p.id === it.id)) REG.list.push({ id: it.id, version: String(it.fm.version || "0"), ok: false, why });
    };
    const run = async (it, box) => {
      if (REG.defs[it.id]) return;
      try {
        if (!it.modName) throw new Error("the pack note names no module");
        await loadModuleOf(app, it.modName, [], box, tag);
        if (!REG.defs[it.id] && !REG.list.some(p => p.id === it.id)) throw new Error(`${it.modName} registered nothing as ${it.id}`);
      } catch (e) { fail(it, e); }
    };
    const note = async f => {
      try {
        const text = await app.vault.read(f);
        if (!text || !String(text).trim()) throw new Error("read back as empty — 0 bytes on disk, or iCloud is holding it as a placeholder");
        const fm = frontOf(text);
        if (String(fm.kind || "").trim().toLowerCase() === "edition") { PARTS = partsOf(fm); return null; }
        return { id: String(fm.id || f.basename).trim(), fm, modName: String(fm.module || "").replace(/^.*\//, "").replace(/\.md$/i, ""), raw: null };
      } catch (e) {
        const why = String((e && e.message) || e).split("\n")[0];
        console.warn(tag, "pack note", f.path, why);
        if (f.basename !== "core" && !REG.list.some(p => p.id === f.basename)) REG.list.push({ id: f.basename, version: "0", ok: false, why });
        return null;
      }
    };
    const load = async it => {
      const box = it.raw != null ? { raw: it.raw } : {};
      await run(it, box);
      if (it.raw == null && REG.defs[it.id] && box.raw) it.raw = box.raw;
    };
    if (kept && kept.stamp === stamp && Array.isArray(kept.notes)) {
      let whole = true;
      try { await kept.done; } catch (e) { whole = false; }
      if (whole) {
        for (const k of kept.notes) { if (!k.it) k.it = await note(k.f); if (k.it) await load(k.it); }
        return REG.list;
      }
    }
    const cache = { stamp, notes: files.map(f => ({ f, it: null })), done: null };
    cache.done = (async () => {
      for (const k of cache.notes) { k.it = await note(k.f); if (k.it) await load(k.it); }
    })();
    if (win) { window.__nmPackNotes = cache; cache.done.catch(() => { if (window.__nmPackNotes === cache) delete window.__nmPackNotes; }); }
    await cache.done;
    return REG.list;
  }

  function mount({ root, app, report = () => {}, tag = "[NM]", note = "", home = null,
    toast: toastOpts = null, fold: foldOpts = null, room = "" } = {}) {

    try {
      const m = String(note || "").match(/`{3}css\s*\n([\s\S]*?)`{3}/);
      if (m) {
        let st = document.getElementById("nm-view-style");
        if (!st) { st = document.createElement("style"); st.id = "nm-view-style"; }
        if (st.textContent !== m[1]) st.textContent = m[1];
        (document.head || document.body).appendChild(st);
      }
    } catch (e) {}

    function guard(name, fn) {
      try {
        const r = fn();
        if (r && typeof r.catch === "function") r.catch(e => report(name, e));
        return r;
      } catch (e) { report(name, e); }
    }

    let POP = null;
    function closePop() {
      if (!POP) return;
      const p = POP; POP = null;
      try { p.off(); } catch (e) {}
      try { p.el.remove(); } catch (e) {}
      try { p.onShut && p.onShut(); } catch (e) {}
    }
    function popAt(anchor, html, wire, onShut, opts = {}) {
      const again = !!(opts.sheet && POP && POP.sheet);
      if (opts.sheet || opts.centre) opts = Object.assign({}, opts, { sticky: true });
      closePop();
      const el = document.createElement("div");
      el.className = "vc-pop" + (opts.sheet ? " vc-pop--sheet" : "");
      if (room) el.dataset.room = room;
      el.innerHTML = html;
      Object.assign(el.style, {
        position: "fixed", zIndex: "2147483000", display: "flex",
        flexDirection: "column", gap: "11px", padding: "13px 16px 14px",
        minWidth: "300px", maxWidth: "min(520px, calc(100vw - 32px))",
        maxHeight: "min(78vh, 700px)", overflowY: "auto", overscrollBehavior: "contain",
        background: "var(--bg-2)", border: "var(--hair-w) solid color-mix(in srgb, var(--a) 20%, transparent)",
        borderRadius: "var(--r-soft)", boxShadow: "var(--sh-3)",
        color: "var(--tx)", fontFamily: "var(--f-text)",
      });
      const veil = opts.centre ? document.createElement("div") : null;
      if (veil) {
        veil.className = "vc-pop-veil";
        Object.assign(veil.style, { position: "fixed", zIndex: "2147482999", background: "color-mix(in srgb, #000 52%, transparent)", borderRadius: "var(--r-soft)" });
        document.body.appendChild(veil);
        try { veil.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180 }); el.animate([{ opacity: 0, transform: "translateY(8px) scale(.985)" }, { opacity: 1, transform: "none" }], { duration: 220, easing: "cubic-bezier(.2,.8,.2,1)" }); } catch (e) {}
      }
      document.body.appendChild(el);
      el.querySelectorAll(".vc-pop-row").forEach(b => Object.assign(b.style, {
        display: "flex", alignItems: "center", gap: "14px", width: "100%",
        height: "auto", minHeight: "0", lineHeight: "normal",
        padding: "10px 6px 11px", textAlign: "left", cursor: "pointer",
        background: "transparent", border: "0",
        borderBottom: "var(--hair-w) solid color-mix(in srgb, var(--a) 9%, transparent)",
        borderRadius: "0", boxShadow: "none", whiteSpace: "normal",
      }));
      const edge = (() => {
        try {
          const cs = getComputedStyle(el), px = k => parseFloat(cs[k]) || 0;
          return {
            v: px("paddingTop") + px("paddingBottom") + px("borderTopWidth") + px("borderBottomWidth"),
            h: px("paddingLeft") + px("paddingRight") + px("borderLeftWidth") + px("borderRightWidth"),
          };
        } catch (e) { return { v: 0, h: 0 }; }
      })();
      const place = () => {
        const vw = window.innerWidth || 1200, vh = window.innerHeight || 800;
        let v = null;
        try { v = root && root.getBoundingClientRect ? root.getBoundingClientRect() : null; } catch (e) {}
        const L = Math.max(0, v ? v.left : 0), R = Math.min(vw, v ? v.right : vw);
        const T = Math.max(0, v ? v.top : 0), B = Math.min(vh, v ? v.bottom : vh);
        const box = (R - L > 120 && B - T > 120)
          ? { left: L + 8, top: T + 8, right: R - 8, bottom: B - 8 }
          : { left: 8, top: 8, right: vw - 8, bottom: vh - 8 };
        if (opts.sheet) {
          const sw = Math.max(260, Math.min(440, box.right - box.left)), sh = Math.max(200, box.bottom - box.top);
          Object.assign(el.style, { left: `${Math.round(box.right - sw)}px`, top: `${Math.round(box.top)}px`, width: `${Math.round(sw)}px`,
            maxWidth: `${Math.round(sw)}px`, height: `${Math.round(sh)}px`, maxHeight: `${Math.round(sh)}px`, minWidth: "0",
            boxSizing: "border-box" });
          return;
        }
        if (opts.centre) {
          const cw = Math.round(Math.max(260, Math.min(opts.width || 760, box.right - box.left))), ch = Math.round(Math.max(200, Math.min(opts.height || 680, box.bottom - box.top)));
          Object.assign(el.style, { width: `${cw}px`, maxWidth: `${cw}px`, maxHeight: `${ch}px`, minWidth: "0", boxSizing: "border-box", padding: "0", gap: "0", overflowY: "hidden", borderRadius: "var(--r-item)" });
          const h = el.offsetHeight;
          el.style.left = `${Math.round(box.left + (box.right - box.left - cw) / 2)}px`;
          el.style.top = `${Math.round(box.top + Math.max(0, (box.bottom - box.top - h) / 2))}px`;
          if (veil) Object.assign(veil.style, { left: `${box.left - 8}px`, top: `${box.top - 8}px`, width: `${box.right - box.left + 16}px`, height: `${box.bottom - box.top + 16}px` });
          return;
        }
        const capW = Math.max(240, Math.min(520, box.right - box.left - edge.h));
        const capH = Math.max(160, Math.min(700, box.bottom - box.top - edge.v));
        if (el.style.maxWidth !== `${capW}px`) el.style.maxWidth = `${capW}px`;
        if (el.style.maxHeight !== `${capH}px`) el.style.maxHeight = `${capH}px`;
        const r = anchor.getBoundingClientRect();
        const w = el.offsetWidth, h = el.offsetHeight;
        const beside = !!(opts.side && r.right + 12 + w <= box.right);
        el.toggleAttribute("data-side", beside);
        if (beside) {
          el.style.left = `${Math.round(r.right + 12)}px`;
          el.style.top = `${Math.round(Math.min(Math.max(box.top, r.top), Math.max(box.top, box.bottom - h)))}px`;
          return;
        }
        const left = Math.min(Math.max(box.left, r.left), Math.max(box.left, box.right - w));
        let top = r.bottom + 8;
        if (top + h > box.bottom) top = r.top - h - 8;
        top = Math.min(Math.max(box.top, top), Math.max(box.top, box.bottom - h));
        el.style.left = `${Math.round(left)}px`;
        el.style.top = `${Math.round(top)}px`;
      };
      place();
      el.classList.add("on");
      const away = e => {
        if (opts.keep) return;
        if (e.target && e.target.isConnected === false) return;
        if (!el.contains(e.target) && !anchor.contains(e.target)) closePop();
      };
      const key = e => { if (e.key === "Escape") { e.stopPropagation(); closePop(); } };
      const go = e => {
        const t = e && e.target;
        if (t && t.nodeType && el.contains(t)) return;
        closePop();
      };
      let ro = null;
      if (opts.sheet) {
        el.insertAdjacentHTML("afterbegin", `<button class="vc-ib vc-ib--sm vc-pop-x" data-pop-x aria-label="close · Escape">${icon("close")}</button>`);
        const px = el.querySelector("[data-pop-x]"); if (px) px.addEventListener("click", e => { e.stopPropagation(); closePop(); });
        if (!again && el.animate) { try { el.animate([{ transform: "translateX(24px)", opacity: 0 }, { transform: "none", opacity: 1 }], { duration: 220, easing: "cubic-bezier(.2,.8,.2,1)" }); } catch (e) {} }
      }
      POP = { el, onShut, sheet: !!opts.sheet, off: () => {
        if (veil) { try { veil.remove(); } catch (e) {} }
        document.removeEventListener("click", away);
        document.removeEventListener("keydown", key);
        if (ro) { try { ro.disconnect(); } catch (e) {} ro = null; }
        if (!opts.sticky) {
          window.removeEventListener("scroll", go, true);
          window.removeEventListener("resize", go);
        } else window.removeEventListener("resize", place);
      } };
      requestAnimationFrame(() => {
        document.addEventListener("click", away);
        document.addEventListener("keydown", key);
        if (!opts.sticky) {
          window.addEventListener("scroll", go, true);
          window.addEventListener("resize", go);
        } else window.addEventListener("resize", place);
      });
      try { wire && wire(el); } catch (e) { report("popover", e); }
      place();
      if (typeof ResizeObserver === "function") {
        try { ro = new ResizeObserver(() => place()); ro.observe(el); }
        catch (e) { ro = null; }
      }
      return el;
    }

    function wireWhy(host) {
      const h = host || root;
      if (h.__whyWired) return;
      h.__whyWired = true;
      const place = mark => {
        try {
          const r = mark.getBoundingClientRect();
          const w = window.innerWidth || 900;
          mark.classList.toggle("vc-why--left", r.right > w - 200);
          mark.classList.toggle("vc-why--right", r.left < 200);
          mark.classList.toggle("vc-why--down", r.top < 240);
        } catch (err) {}
      };
      h.addEventListener("mouseover", e => {
        const mark = e.target.closest?.(".vc-why");
        if (mark) place(mark);
      });
      h.addEventListener("click", e => {
        const mark = e.target.closest?.(".vc-why");
        h.querySelectorAll(".vc-why.on").forEach(x => { if (x !== mark) x.classList.remove("on"); });
        if (!mark) return;
        e.preventDefault(); e.stopPropagation();
        mark.classList.toggle("on");
        place(mark);
      });
    }

    const readNote = f => (app.vault.cachedRead ? app.vault.cachedRead(f) : app.vault.read(f));
    async function loadFonts() {
      try {
        let raw = null;
        const hits = (app.vault.getFiles() || []).filter(f => /^Vault[ -]Fonts\.md$/i.test(f.name));
        for (const f of hits) { try { const t = await readNote(f); if (t && t.trim()) { raw = t; break; } } catch (e) {} }
        if (!raw) for (const p of ["99_Meta/Vault Fonts.md", "Vault Fonts.md"]) {
          try { const t = await app.vault.adapter.read(p); if (t && t.trim()) { raw = t; break; } } catch (e) {}
        }
        const fenced = raw && raw.match(/`{3}css\s*\n([\s\S]*?)`{3}/);
        if (!fenced) return false;
        let el = document.getElementById("vault-fonts-style");
        if (el && el.textContent === fenced[1]) return true;
        if (!el) { el = document.createElement("style"); el.id = "vault-fonts-style"; }
        el.textContent = fenced[1];
        const host = document.head || document.body || root;
        host.insertBefore(el, host.firstChild);
        return true;
      } catch (e) { console.warn("[NM] fonts not injected —", e.message); return false; }
    }
    async function loadChrome(opts = {}) {
      const read = async () => {
        const hits = (app.vault.getFiles() || []).filter(f =>
          /^(Vault[ -]Chrome|NM-Chrome)\.md$/i.test(f.name));
        for (const f of hits) { try { const t = await readNote(f); if (t && t.trim()) return t; } catch (e) {} }
        for (const p of ["99_Meta/Vault Chrome.md", "99_Meta/NM-Chrome.md", "Vault Chrome.md", "NM-Chrome.md"]) {
          try { const t = await app.vault.adapter.read(p); if (t && t.trim()) return t; } catch (e) {}
        }
        return null;
      };
      const reading = read().catch(() => null);
      await loadFonts();
      if (opts.theme !== false) try { await ensureTheme(); } catch (e) {}
      let have = null;
      try { have = document.getElementById && document.getElementById("vault-chrome-style"); } catch (e) {}
      const raw = await reading;
      if (!raw) return !!have;
      const fenced = raw.match(/`{3}css\s*\n([\s\S]*?)`{3}/);
      const css = fenced ? fenced[1] : raw;
      try {
        if (have && have.textContent === css) return true;
        if (have) { try { have.remove(); } catch (e) {} }
        const el = document.createElement("style");
        el.id = "vault-chrome-style";
        el.textContent = css;
        const mine = document.getElementById("nm-view-style");
        const host = document.head || document.body || root;
        if (mine && mine.parentNode === host) host.insertBefore(el, mine); else host.appendChild(el);
        return true;
      } catch (e) { console.warn("[NM] chrome not injected —", e.message); return false; }
    }

    const THEME_FILE = "vault-theme";
    const THEME_HEAD = "/* The vault's theme: the style and the palette chosen in the Home Dashboard's\n" +
      "   settings, as custom properties the Lamplit theme and every view read.\n" +
      "   Written from there and replaced whole whenever the choice changes, so\n" +
      "   anything typed here is lost. Switched on under Settings, Appearance, CSS snippets. */\n";
    const THEMES_DIR = "99_Meta/Themes";
    let THEMES = null, THEMES_STAMP = "";
    const inDir = p => { const s = String(p || ""); return s.toLowerCase().startsWith(THEMES_DIR.toLowerCase() + "/") && /\.md$/i.test(s) && s.indexOf("/", THEMES_DIR.length + 1) < 0; };
    async function themes(fresh) {
      let files = []; try { files = (app.vault.getFiles() || []).filter(f => inDir(f.path)); } catch (e) {}
      const stamp = files.length ? VERSION + "|" + files.map(f => f.path + ":" + (f.stat && f.stat.mtime)).join("|") : "";
      const kept = stamp && typeof window !== "undefined" ? window.__nmThemes : null;
      if (!THEMES && kept && kept.stamp === stamp) { THEMES = kept.reg; THEMES_STAMP = stamp; }
      if (THEMES && (!fresh || (stamp && stamp === THEMES_STAMP))) return THEMES;
      const found = [];
      try {
        for (const f of files) {
          try { const t = await readNote(f); if (t && t.trim()) found.push({ name: f.path, text: t }); } catch (e) {}
        }
      } catch (e) {}
      if (!found.length) {
        try {
          const l = await app.vault.adapter.list(THEMES_DIR);
          for (const p of (l && l.files) || []) if (inDir(p)) {
            try { const t = await app.vault.adapter.read(p); if (t && t.trim()) found.push({ name: p, text: t }); } catch (e) {}
          }
        } catch (e) {}
      }
      const fence = t => { const m = String(t).match(/`{3}css\s*\n([\s\S]*?)`{3}/); return m ? m[1] : ""; };
      THEMES = theme.parse(found.map(f => ({ name: f.name, css: fence(f.text) }))); THEMES_STAMP = stamp;
      try { if (stamp) window.__nmThemes = { stamp, reg: THEMES }; } catch (e) {}
      return THEMES;
    }
    function themeChosen() {
      try {
        const f = app.vault.getAbstractFileByPath(vaultSettings.PATH), known = !f || !!app.metadataCache.getFileCache(f);
        const fm = vaultSettings.read(app), roll = rollKept();
        let style = String(fm.style || ""), palette = String(fm.palette || "");
        if (roll && roll.style) {
          if ((roll.style === style && roll.palette === palette) || Date.now() - roll.at > 20000) roll.style = "";
          else { style = roll.style; palette = roll.palette; }
        }
        return { known, style, palette, perf: String(fm.perf || ""),
          match: Array.isArray(fm.match_colours) ? { colours: fm.match_colours.map(String) } : null };
      } catch (e) { return { known: false, style: "", palette: "", perf: "", match: null }; }
    }
    const rollKept = () => { try { return (typeof window !== "undefined" && window.__vaultThemeRoll) || null; } catch (e) { return null; } };
    async function themeRoll(reg) {
      try {
        if (typeof window === "undefined" || window.__vaultThemeRoll) return null;
        const c = themeChosen();
        if (!c.known) { ensureLater(); return null; }
        window.__vaultThemeRoll = { style: "", palette: "", at: 0 };
        if (String(vaultSettings.read(app).theme_chance || "") !== "open") return null;
        const all = ((reg && reg.styles) || []).flatMap(st => st.palettes.filter(p => !p.match).map(p => ({ style: st.id, palette: p.id, styleName: st.name, paletteName: p.name })));
        const away = all.filter(x => x.style !== c.style), from = away.length ? away : all.filter(x => x.palette !== c.palette);
        const got = from[Math.floor(Math.random() * from.length)];
        if (!got) return null;
        if (!(await vaultSettings.write(app, { style: got.style, palette: got.palette, ["theme_palette_" + got.style]: got.palette }))) return null;
        window.__vaultThemeRoll = { ...got, at: Date.now() };
        return got;
      } catch (e) { return null; }
    }
    function themePerf(mode) {
      try { const b = document.body; if (!b) return; if (mode) b.setAttribute("data-perf", mode); else b.removeAttribute("data-perf"); } catch (e) {}
    }
    const themeWorn = () => {
      try { return getComputedStyle(document.body).getPropertyValue("--vault-theme").trim().replace(/^["']|["']$/g, ""); }
      catch (e) { return ""; }
    };
    function themeLive(css) {
      let el = document.getElementById("vault-theme-live");
      if (!el) { el = document.createElement("style"); el.id = "vault-theme-live"; }
      if (el.textContent !== css) el.textContent = css;
      (document.head || document.body).appendChild(el);
    }
    const dropLive = () => { try { const el = document.getElementById("vault-theme-live"); if (el) el.remove(); } catch (e) {} };
    const snippetPath = () => (app.vault.configDir || ".obsidian") + "/snippets/" + THEME_FILE + ".css";
    function themeCarrier() {
      try {
        const cc = app.customCss, on = cc && cc.enabledSnippets;
        if (!on || !on.has(THEME_FILE) || !Array.isArray(cc.snippets) || !Array.isArray(cc.extraStyleEls)) return null;
        const el = cc.extraStyleEls[cc.snippets.filter(s => on.has(s)).indexOf(THEME_FILE)];
        return el && el.isConnected && /--vault-theme:/.test(el.textContent) ? el : null;
      } catch (e) { return null; }
    }
    function settleLive(mark, ms = 1500) {
      return new Promise(done => {
        let ref = null, t = 0;
        const check = () => { const el = themeCarrier(); if (!el || theme.marked(el.textContent) !== mark) return false; dropLive(); end(); return true; };
        const end = () => { clearTimeout(t); try { if (ref) app.workspace.offref(ref); } catch (e) {} done(); };
        if (check()) return;
        try { ref = app.workspace.on("css-change", check); } catch (e) {}
        t = setTimeout(end, ms);
      });
    }
    let themeWait = null;
    function ensureLater() {
      if (themeWait) return;
      const done = () => { (themeWait || []).forEach(r => { try { app.metadataCache.offref(r); } catch (e) {} }); themeWait = null; };
      const again = () => { if (!themeChosen().known) return; done(); ensureTheme().catch(() => {}); };
      try {
        themeWait = [app.metadataCache.on("changed", f => { if (f && f.path === vaultSettings.PATH) again(); }), app.metadataCache.on("resolved", again)];
        setTimeout(done, 60000);
      } catch (e) { done(); }
    }
    async function ensureTheme() {
      if (!themeChosen().known) { ensureLater(); return false; }
      themePerf(themeChosen().perf);
      const reg = await themes();
      if (!reg.styles.length) return false;
      const rolled = await themeRoll(reg);
      if (rolled) {
        await applyTheme(rolled.style, rolled.palette, { stale: true }); themeGuard();
        try { window.dispatchEvent(new CustomEvent("vault-theme-rolled", { detail: rolled })); } catch (e) {}
        return true;
      }
      const c = themeChosen(), css = theme.compose(reg, c.style, c.palette, c.match), mark = theme.marked(css);
      if (themeWorn() !== mark) themeLive(css);
      else if (document.getElementById("vault-theme-live")) { const el = themeCarrier(); if (el && theme.marked(el.textContent) === mark) dropLive(); }
      themeGuard();
      return true;
    }
    let guardBusy = false, guardT = 0, rescued = 0;
    function themeGuard() {
      try {
        const w = window, ws = app.workspace;
        if (w.__vaultThemeGuard && w.__vaultThemeGuard.mend === themeMend) return;
        const old = w.__vaultThemeGuard;
        if (old) { try { ws.offref(old.ref); } catch (e) {} try { w.removeEventListener("focus", old.soon); } catch (e) {} }
        const soon = () => { clearTimeout(guardT); guardT = setTimeout(themeMend, 400); };
        const ref = ws.on("css-change", soon);
        w.addEventListener("focus", soon);
        w.__vaultThemeGuard = { ref, soon, mend: themeMend };
      } catch (e) {}
    }
    async function themeMend() {
      if (guardBusy) return;
      const c = themeChosen();
      if (!c.known || !(c.style || c.palette)) return;
      guardBusy = true;
      try {
        const reg = await themes();
        if (!reg.styles.length) return;
        const css = theme.compose(reg, c.style, c.palette, c.match), mark = theme.marked(css);
        if (themeWorn() !== mark) themePaint(css, mark);
        if (Date.now() - rescued < 600000) return;
        let gone = false;
        try { gone = !(await app.vault.adapter.exists(snippetPath())); } catch (e) {}
        if (gone) { rescued = Date.now(); await snippetWrite(THEME_HEAD + css); }
      } catch (e) {} finally { guardBusy = false; }
    }
    function themePaint(css, mark) {
      const text = THEME_HEAD + css, cc = app.customCss;
      try {
        if (themeWorn() === mark) return !!themeCarrier();
        const el = themeCarrier();
        if (el) {
          el.textContent = text; dropLive();
          try { cc.csscache.set(snippetPath(), text); } catch (e) {}
          try { app.workspace.trigger("css-change"); app.workspace.trigger("resize"); } catch (e) {}
          return true;
        }
        themeLive(css);
      } catch (e) {}
      return false;
    }
    async function snippetWrite(text) {
      const path = snippetPath(), dir = path.slice(0, path.lastIndexOf("/"));
      if (!(await app.vault.adapter.exists(dir))) await app.vault.adapter.mkdir(dir);
      await app.vault.adapter.write(path, text);
    }
    let laterT = 0, laterText = "";
    function snippetLater(text) {
      laterText = text; clearTimeout(laterT);
      laterT = setTimeout(() => { const t = laterText; laterText = ""; snippetWrite(t).catch(() => {}); }, 5000);
    }
    async function applyTheme(styleId, paletteId, opts = {}) {
      const reg = await themes(true);
      const got = theme.pick(reg, styleId, paletteId);
      if (!got) return { ok: false, why: "no theme notes to read a theme from" };
      const roll = rollKept(); if (roll && roll.style && (roll.style !== got.st.id || roll.palette !== got.pal.id)) roll.style = "";
      const match = opts.match !== undefined ? opts.match : themeChosen().match;
      const css = theme.compose(reg, got.st.id, got.pal.id, match), text = THEME_HEAD + css, mark = theme.marked(css), path = snippetPath();
      const out = { ok: true, style: got.st.id, palette: got.pal.id, styleName: got.st.name, paletteName: got.pal.name, wrote: false, on: false };
      const cc = app.customCss;
      const carried = themePaint(css, mark);
      try {
        let had = null;
        if (opts.stale) { try { if (await app.vault.adapter.exists(path)) had = await app.vault.adapter.read(path); } catch (e) {} }
        if (had === text) { out.same = true; clearTimeout(laterT); laterText = ""; }
        else if (carried && !opts.stale) snippetLater(text);
        else { clearTimeout(laterT); laterText = ""; await snippetWrite(text); }
        out.wrote = true;
        if (cc) {
          if (!carried) {
            try { if (cc.readSnippets) await cc.readSnippets(); } catch (e) {}
            try { if (cc.setCssEnabledStatus && !(cc.enabledSnippets && cc.enabledSnippets.has(THEME_FILE))) cc.setCssEnabledStatus(THEME_FILE, true); } catch (e) {}
            try { if (cc.requestLoadSnippets) cc.requestLoadSnippets(); } catch (e) {}
            if (document.getElementById("vault-theme-live")) { const s = settleLive(mark); if (opts.settle) await s; }
          }
          out.on = !!(cc.enabledSnippets && cc.enabledSnippets.has(THEME_FILE));
        }
      } catch (e) { out.why = (e && e.message) || String(e); }
      return out;
    }
    function veil(label) {
      try { document.querySelectorAll(".vc-veil").forEach(v => v.remove()); } catch (e) {}
      const el = document.createElement("div"), t = document.createElement("span"), bar = document.createElement("i");
      el.className = "vc-host vc-veil"; el.setAttribute("role", "status"); t.className = "vc-veil-t"; bar.className = "vc-veil-bar";
      t.textContent = String(label || ""); t.appendChild(bar); el.appendChild(t); document.body.appendChild(el);
      const raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : f => setTimeout(f, 16);
      raf(() => el.classList.add("on"));
      let still = document.body.getAttribute("data-perf") === "light";
      try { still = still || matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
      if (!still && bar.animate) bar.animate([{ transform: "translateX(-100%)" }, { transform: "translateX(260%)" }], { duration: 900, iterations: Infinity, easing: "ease-in-out" });
      let open = true;
      const key = e => { if (e.key === "Escape") close(); };
      const cap = setTimeout(() => close(), 6000);
      function close() {
        if (!open) return; open = false;
        clearTimeout(cap); document.removeEventListener("keydown", key, true);
        el.classList.remove("on"); el.classList.add("off");
        setTimeout(() => el.remove(), still ? 0 : 240);
      }
      document.addEventListener("keydown", key, true);
      const frame = () => new Promise(r => raf(() => r()));
      return {
        close,
        async done() {
          try { await Promise.race([document.fonts ? document.fonts.ready : null, new Promise(r => setTimeout(r, 1500))]); } catch (e) {}
          await frame(); await frame();
          close();
        } };
    }

    const loadModule = (name, needs, box) => loadModuleOf(app, name, needs, box, tag);

    const MOUNTED = Object.create(null);
    let settled = false;
    function pack(id) {
      if (id in MOUNTED) return MOUNTED[id];
      const def = packDef(id); if (!def || typeof def.mount !== "function") return settled ? (MOUNTED[id] = null) : null;
      try {
        MOUNTED[id] = def.mount({ app, root, report, toast, net, dailyFolder: () => dailyFolder(app), settingsRead: () => vaultSettings.read(app),
          loadModule, icon, iconify, popAt, closePop, modal, ask, askConfirm, working, hideToast, lastPress, wireWhy, veil, esc, vaultKeys }) || null;
        if (def.css && typeof document !== "undefined") {
          let st = document.getElementById("vault-kit-" + id);
          if (!st) { st = document.createElement("style"); st.id = "vault-kit-" + id; (document.head || document.body).appendChild(st); }
          if (st.textContent !== def.css) st.textContent = def.css;
        }
        return MOUNTED[id];
      } catch (e) { const p = REG.list.find(p => p.id === id); if (p) { p.ok = false; p.why = String(e.message || e).split("\n")[0]; } return (MOUNTED[id] = null); }
    }
    const loadPacks = () => loadPacksOf(app, tag);
    const ready = loadPacks().catch(() => REG.list).then(r => { settled = true; return r; });

    if (typeof document !== "undefined" && !document.__nmPress) {
      document.__nmPress = 1;
      const mark = e => {
        const t = e.target;
        const b = t && t.closest && t.closest('button, [role="button"], .fv-ing');
        if (b) document.__nmLast = b;
      };
      document.addEventListener("mousedown", mark, true);
      document.addEventListener("click", mark, true);
    }
    function lastPress() {
      try { const b = document.__nmLast; return b && b.isConnected !== false ? b : null; }
      catch (e) { return null; }
    }

    function modal({ title, body = "", fields = [], confirmText = "ok", danger = false, at = null, wire = null, side = false }) {
      return new Promise(resolve => {
        let fallback = null;
        try { fallback = home ? home() : null; } catch (e) {}
        const anchor = at || lastPress() || fallback || root;
        const seg = {};
        let done = false;
        const fieldHtml = (f, i) => {
          if (f.type === "segment") {
            seg[i] = String(f.value ?? (f.options?.[0]?.value ?? ""));
            return `<span class="vc-pf-seg" data-seg="${i}">` + (f.options || []).map(o =>
              `<button class="vc-pf-btn${String(o.value ?? o) === seg[i] ? " on" : ""}" ` +
              `data-segv="${esc(o.value ?? o)}">${esc(o.label ?? o)}</button>`).join("") + `</span>`;
          }
          if (f.type === "select") {
            return `<select class="vc-pf-i" data-f="${i}">` + (f.options || []).map(o =>
              `<option value="${esc(o.value ?? o)}" ${String(f.value) === String(o.value ?? o) ? "selected" : ""}>` +
              `${esc(o.label ?? o)}</option>`).join("") + `</select>`;
          }
          if (f.type === "area") {
            return `<textarea class="vc-pf-i vc-pf-area" data-f="${i}" rows="${f.rows || 9}" ` +
              `placeholder="${esc(f.placeholder || "")}">${esc(f.value ?? "")}</textarea>`;
          }
          return `<input class="vc-pf-i" data-f="${i}" value="${esc(f.value ?? "")}" ` +
            `placeholder="${esc(f.placeholder || "")}" ${f.numeric ? 'inputmode="decimal"' : ""}>`;
        };
        const html =
          `<div class="vc-pop-h">${esc(title)}</div>` +
          (body ? `<div class="vc-pf-b">${body}</div>` : "") +
          (fields.length
            ? `<div class="vc-pf">` + fields.map((f, i) =>
                `<div class="vc-pf-r">` +
                (f.label ? `<span class="vc-pf-k">${esc(f.label)}</span>` : "") +
                fieldHtml(f, i) +
                (f.hint ? `<small class="vc-pf-h">${esc(f.hint)}</small>` : "") + `</div>`).join("") +
              `</div>`
            : "") +
          `<div class="vc-pf-a">` +
          `<button class="vc-pf-btn" data-m="cancel">cancel</button>` +
          `<button class="vc-pf-btn ${danger ? "vc-pf-btn--warn" : "vc-pf-btn--go"}" ` +
          `data-m="ok">${esc(confirmText)}</button></div>`;
        popAt(anchor, html, pop => {
          const read = () => fields.map((f, i) =>
            f.type === "segment" ? seg[i]
              : (pop.querySelector(`[data-f="${i}"]`) || {}).value ?? "");
          const finish = val => { if (done) return; done = true; closePop(); resolve(val); };
          const submit = () => finish(fields.length ? read() : true);
          pop.querySelectorAll("[data-seg]").forEach(g =>
            g.querySelectorAll("[data-segv]").forEach(b => b.addEventListener("click", () => {
              seg[g.dataset.seg] = b.dataset.segv;
              g.querySelectorAll("[data-segv]").forEach(x => x.classList.toggle("on", x === b));
            })));
          pop.querySelector('[data-m="ok"]').addEventListener("click", submit);
          pop.querySelector('[data-m="cancel"]').addEventListener("click", () => finish(null));
          pop.addEventListener("keydown", e => {
            if (e.key === "Enter" && e.target?.tagName === "TEXTAREA") return;
            if (e.key === "Enter") { e.preventDefault(); submit(); }
          });
          try { wire && wire(pop); } catch (e) { report("dialogue", e); }
          setTimeout(() => {
            const first = pop.querySelector("input.vc-pf-i, textarea.vc-pf-i, select.vc-pf-i");
            first?.focus(); first?.select?.();
          }, 30);
        }, () => { if (!done) { done = true; resolve(null); } }, { sticky: true, keep: true, side });
      });
    }
    const ask = async (title, value = "", opts = {}) => {
      const r = await modal({ title, fields: [{ value, ...opts }], confirmText: opts.confirmText || "save" });
      return r ? r[0] : null;
    };
    const askConfirm = (title, body = "", danger = false) =>
      modal({ title, body, confirmText: danger ? "delete" : "yes", danger }).then(r => !!r);

    const TO = Object.assign({ box: () => null, x: "vc-toast-x", u: "vc-toast-u", bar: "vc-toast-bar",
      undo: null }, toastOpts || {});
    let tTimer = null, tRaf = null, tTick = null, tUndo = null;
    const tBox = () => { try { return TO.box(); } catch (e) { return null; } };
    function hideToast() { const b = tBox(); if (b) b.classList.remove("on"); }
    function toast(label, undo, more = {}) {
      const box = tBox();
      if (!box) return;
      if (tTimer) clearTimeout(tTimer);
      if (tRaf) cancelAnimationFrame(tRaf);
      if (tTick) { clearInterval(tTick); tTick = null; }
      tUndo = undo || null;
      const lines = (more && more.lines) || [], open = more && more.open;
      box.innerHTML = `<span class="${TO.x}">${label}</span>` +
        (lines.length ? `<span class="vc-toast-l">${lines.map(l => `<code>${esc(l)}</code>`).join("")}</span>` : "") +
        (open ? `<button class="${TO.u}" data-toast-open aria-label="open ${esc(noteName(open))}">open</button>` : "") +
        (tUndo ? `<button class="${TO.u}" data-toast-undo>undo</button>` : "") +
        `<span class="${TO.bar}" data-toast-bar></span>`;
      box.classList.add("on");
      const o = box.querySelector("[data-toast-open]");
      if (o) o.addEventListener("click", () => {
        hideToast();
        try { app.workspace.openLinkText(String(open).replace(/\.md$/, ""), "", false); } catch (e) { report("opening the note", e); }
      });
      const u = box.querySelector("[data-toast-undo]");
      if (u) u.addEventListener("click", async () => {
        const token = tUndo;
        tUndo = null;
        if (!token) return;
        hideToast();
        try {
          if (token.receipt) await unwrite(token);
          else if (typeof token === "function") await token();
          else if (TO.undo) await TO.undo(token);
        } catch (e) { report("undo", e); }
      });
      const LIFE = 7000, t0 = performance.now(), bar = box.querySelector("[data-toast-bar]");
      const step = ts => {
        if (!root.isConnected) return;
        const p = Math.min(1, (ts - t0) / LIFE);
        if (bar) bar.style.width = ((1 - p) * 100) + "%";
        if (p < 1) tRaf = requestAnimationFrame(step);
      };
      tRaf = requestAnimationFrame(step);
      tTimer = setTimeout(hideToast, LIFE);
    }
    const noteName = p => String(p || "").split("/").pop().replace(/\.md$/, "");
    async function unwrite(t) {
      const f = app.vault.getAbstractFileByPath(t.path);
      let now = null; try { now = f ? await app.vault.read(f) : null; } catch (e) {}
      if (now == null || now !== t.after) { toast(`<b>${esc(noteName(t.path))}</b> has changed since — nothing taken back`, null, { open: t.path }); return; }
      await app.vault.modify(f, t.before);
      toast(`taken back from <b>${esc(noteName(t.path))}</b>`, null, { open: t.path });
      if (typeof t.then === "function") { try { t.then(); } catch (e) { report("after undo", e); } }
    }
    async function receipt(label, path, before, more = {}) {
      let after = null;
      try { const f = app.vault.getAbstractFileByPath(path); after = f ? await app.vault.read(f) : null; } catch (e) {}
      const undo = before != null && after != null && after !== before ? { receipt: true, path, before, after, then: more.then } : null;
      toast(label, undo, { open: path, lines: more.lines });
    }

    let roomsList = null;
    const isoNow = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
    const hereOf = () => {
      try {
        const l = app.workspace.getLeavesOfType("markdown").find(x => x.view && x.view.containerEl && x.view.containerEl.contains(root));
        const f = (l && l.view.file) || (!l && app.workspace.getActiveFile && app.workspace.getActiveFile());
        return (f && f.path) || "";
      } catch (e) { return ""; }
    };
    const todayPath = () => { const dir = dailyFolder(app); return `${dir ? dir + "/" : ""}${isoNow()}.md`; };
    function openRoom(r) {
      if (r.path !== "@daily") { app.workspace.openLinkText(r.path.replace(/\.md$/, ""), "", false); return; }
      const f = app.vault.getAbstractFileByPath(todayPath());
      if (f) app.workspace.openLinkText(f.path.replace(/\.md$/, ""), "", false);
      else { try { app.commands.executeCommandById("daily-notes"); } catch (e) { report("opening today's note", e); } }
    }
    function dayWord() {
      const f = app.vault.getAbstractFileByPath(todayPath());
      if (!f) return "";
      const t = String(((app.metadataCache.getFileCache(f) || {}).frontmatter || {}).training || "").trim().toLowerCase();
      return t && t !== "rest" ? t + " day" : "rest day";
    }
    async function runCommand(text, opts = {}) {
      let r;
      if (!opts.pick && !opts.quiet) opts = Object.assign({}, opts, { pick: o => homePicker(Object.assign({ mode: "file" }, o)) });
      try { r = await commands.run(app, text, opts); } catch (e) { report("the command line", e); return { why: String((e && e.message) || e) }; }
      if (opts.quiet) return r;
      if (r.why) { toast(esc(r.why)); return r; }
      if (r.made) toast(r.said, async () => {
        const f = app.vault.getAbstractFileByPath(r.path);
        if (f) { await app.vault.trash(f, true); toast(`<b>${esc(noteName(r.path))}</b> — to the bin`); }
      }, { open: r.path });
      else receipt(r.said, r.path, r.before);
      return r;
    }
    function newPop(anchor, opts = {}) {
      const words = commands.live();
      popAt(anchor, `<span class="vc-new-k">new</span>
        <label class="vc-new-line">${icon("add")}<input class="vc-new-i" data-new-i placeholder="${esc(commands.examples(3).join(" · "))}" aria-label="a command — a slash, a word, and what it is" autocomplete="off"></label>
        <div class="vc-new-words">${words.map(([w, said]) => `<button class="vc-new-w" data-new-w="${w}" aria-label="${esc(said)}">/${w}</button>`).join("")}</div>
        <p class="vc-new-said" data-new-said aria-live="polite">${esc(words[0][1])}</p>`, el => {
        const i = el.querySelector("[data-new-i]"), said = el.querySelector("[data-new-said]");
        const tell = () => { const p = commands.parse(i.value); const w = p && p.kind && words.find(([k]) => k === p.kind); said.textContent = w ? w[1] : p && !p.kind ? `/${p.word} is not a word the command line knows` : "a slash, a word, and what it is"; };
        el.querySelectorAll("[data-new-w]").forEach(b => b.addEventListener("click", e => { e.preventDefault(); i.value = `/${b.dataset.newW} `; tell(); i.focus(); }));
        i.addEventListener("input", tell);
        i.addEventListener("keydown", async e => {
          if (e.key !== "Enter") return;
          e.preventDefault();
          const r = await runCommand(i.value, { E: opts.E ? opts.E() : null });
          if (!r.why) { closePop(); if (typeof opts.after === "function") opts.after(r); }
        });
        setTimeout(() => i.focus({ preventScroll: true }), 30);
      }, null, { sticky: true });
    }
    async function giveHome(file, { title = "", then = null } = {}) {
      if (!file) return null;
      const target = await homePicker({ title: title || file.basename, mode: "home" });
      if (!target) return null;
      const r = await maps.setHome(app, [file], target);
      if (r.why) { toast(esc(r.why)); return null; }
      const after = () => { try { if (then) then(); } catch (e) {} };
      toast(r.said, r.undo ? async () => { await r.undo(); after(); } : null);
      after();
      return r.map;
    }
    const homeName = file => { try { return maps.upOf(((file && app.metadataCache.getFileCache(file)) || {}).frontmatter) || ""; } catch (e) { return ""; } };
    const LATELY = "maps-lately";
    const lately = () => { try { const v = JSON.parse(localStorage.getItem(LATELY) || "[]"); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
    const remember = p => { try { localStorage.setItem(LATELY, JSON.stringify([p, ...lately().filter(x => x !== p)].slice(0, 5))); } catch (e) {} };
    let HP = null;
    function homePicker({ title = "", moment = "", guesses = [], mode = "file", count = 1, from = null, moving = null } = {}) {
      if (HP) HP(null);
      try { maps.watch(app, hear); } catch (e) {}
      const I = maps.index(app, isoNow()), move = mode === "move";
      return new Promise(resolve => {
        const st = { q: "", cur: 0, parentAt: 0, archived: false };
        const veil = document.createElement("div");
        let narrow = (window.innerWidth || 1200) < 560;
        try { const r = root.getBoundingClientRect(); if (r.width > 0 && r.width < 560) narrow = true; } catch (e) {}
        veil.className = "vc-hp-veil" + (narrow ? " vc-hp--sheet" : "");
        const escSays = mode === "file" ? "makes it with no home; it waits in Unfiled" : "changes nothing";
        const who = move && count > 1 ? `${count} notes` : title;
        veil.innerHTML = `<div class="vc-hp" role="dialog" aria-label="${move ? "move" : "a home for"} ${esc(who)}">
          <div class="vc-hp-h">${move ? "move" : "a home for"} <b>${esc(who)}</b>${moment ? `<span class="vc-hp-ctx">${esc(moment)}</span>` : ""}</div>
          <label class="vc-hp-in">${icon("search")}<input class="vc-hp-i" data-hp-i placeholder="a map or topic, or a new name" aria-label="find a home" autocomplete="off" spellcheck="false"></label>
          <div class="vc-hp-list" role="listbox" data-hp-list></div>
          <div class="vc-hp-f" data-hp-f></div>
          <div class="vc-hp-acts"><button class="vc-hp-btn" data-hp-no>${move ? "cancel" : mode === "file" ? "no home yet" : "not now"}</button><button class="vc-hp-btn vc-hp-btn--go" data-hp-go>${move ? "move here" : "file here"}</button></div>
        </div>`;
        document.body.appendChild(veil);
        const input = veil.querySelector("[data-hp-i]"), list = veil.querySelector("[data-hp-list]"), foot = veil.querySelector("[data-hp-f]");
        let done = false, live = [];
        const WIN = (veil.ownerDocument && veil.ownerDocument.defaultView) || window;
        const onEsc = e => { if (e.key === "Escape" && !done) { e.preventDefault(); e.stopPropagation(); finish(null); } };
        const finish = v => {
          if (done) return; done = true; HP = null;
          try { WIN.removeEventListener("keydown", onEsc, true); } catch (e) {}
          try { veil.remove(); } catch (e) {}
          if (v && v.map) remember(v.map.path);
          resolve(v);
        };
        HP = finish;
        const rowsNow = () => {
          let rows = maps.pickerRows({ query: st.q, guesses, lately: lately(), index: I, from, moving, parentAt: st.parentAt });
          if (st.archived) rows = rows.flatMap(r => r.kind === "archived-fold" ? I.maps.filter(m => m.archived && m.path !== from).map(m => ({ kind: "map", map: m, group: "archived", why: "" })) : [r]);
          return rows;
        };
        const mark = m => m.mark ? `<span class="vc-hp-m">${esc(m.mark)}</span>` : `<span class="vc-hp-m">${icon("leaf")}</span>`;
        const lit = (s, q) => { const i = q ? s.toLowerCase().indexOf(q.toLowerCase()) : -1; return i < 0 ? esc(s) : esc(s.slice(0, i)) + `<mark>${esc(s.slice(i, i + q.length))}</mark>` + esc(s.slice(i + q.length)); };
        const groupOf = r => r.kind === "map" ? r.group : r.kind === "archived-fold" ? "archived" : "make it";
        function draw() {
          const rows = rowsNow(); live = rows.filter(r => r.kind !== "archived-fold");
          st.cur = Math.max(0, Math.min(st.cur, live.length - 1));
          let i = -1, last = "";
          list.innerHTML = rows.map(r => {
            const g = groupOf(r), head = g !== last ? `<div class="vc-hp-g">${esc(g)}</div>` : ""; last = g;
            if (r.kind === "archived-fold") return head + `<button class="vc-hp-row vc-hp-fold" data-hp-fold><span class="vc-hp-m">${icon("inbox")}</span><span class="vc-hp-t">${r.n} archived ${r.n === 1 ? "map" : "maps"}<small>type a name to find one; filing into one brings it back</small></span></button>`;
            i++;
            const cur = i === st.cur ? " is-cur" : "", aria = `role="option" aria-selected="${i === st.cur}"`;
            if (r.kind === "new-map") return head + `<button class="vc-hp-row${cur}" data-hp-row="${i}" data-kind="new-map" ${aria}><span class="vc-hp-m">${icon("add")}</span><span class="vc-hp-t">new map <b>${esc(r.name)}</b><small>a map of its own, made now, and ${move && count > 1 ? "these notes" : "this note"} filed in it</small></span></button>`;
            if (r.kind === "new-topic") return head + `<button class="vc-hp-row${cur}" data-hp-row="${i}" data-kind="new-topic" ${aria}><span class="vc-hp-m">${icon("add")}</span><span class="vc-hp-t">new topic <b>${esc(r.name)}</b> under <span class="vc-hp-par" data-hp-par>${esc(r.parent.mark ? r.parent.mark + " " : "")}${esc(r.parent.name)}</span><small>${narrow ? "press the map" : "Tab"} to put it under another map</small></span></button>`;
            const m = r.map, t = I.trail(m.path), rest = I.restingUntil(m.path);
            const tag = m.archived ? `<span class="vc-hp-tag">archived · brings it back</span>` : rest ? `<span class="vc-hp-tag">resting until ${esc(maps.dayName(rest))}</span>` : "";
            return head + `<button class="vc-hp-row${cur}" data-hp-row="${i}" data-kind="map" ${aria}>${mark(m)}<span class="vc-hp-t">${t.slice(0, -1).map(x => esc(x.name) + " › ").join("")}<b>${lit(m.name, st.q)}</b>${r.why ? `<small>${esc(r.why)}</small>` : ""}</span><span class="vc-hp-r">${tag}<span class="vc-hp-n">${I.count(m.path).notes}</span></span></button>`;
          }).join("") || `<p class="vc-hp-none">No maps yet. Type a name to make one.</p>`;
          foot.innerHTML = `<span><kbd>↑</kbd><kbd>↓</kbd> choose</span><span><kbd>↵</kbd> ${move ? "move" : "file"}</span>${live.some(r => r.kind === "new-topic") ? `<span><kbd>Tab</kbd> another map</span>` : ""}<span class="vc-hp-esc"><kbd>Esc</kbd> ${escSays}</span>`;
          const c = list.querySelector(".is-cur"); if (c && c.scrollIntoView) { try { c.scrollIntoView({ block: "nearest" }); } catch (e) {} }
        }
        const choose = r => {
          if (!r) return;
          if (r.kind === "map") finish({ map: r.map });
          else if (r.kind === "new-map") finish({ make: "map", name: r.name });
          else if (r.kind === "new-topic") finish({ make: "topic", name: r.name, parent: r.parent });
        };
        const cycle = d => { st.parentAt += d; draw(); };
        input.addEventListener("input", () => { st.q = input.value; st.cur = 0; st.parentAt = 0; draw(); });
        veil.addEventListener("keydown", e => {
          if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); st.cur += e.key === "ArrowDown" ? 1 : -1; draw(); }
          else if (e.key === "Enter") { e.preventDefault(); choose(live[st.cur]); }
          else if (e.key === "Tab" && live.some(r => r.kind === "new-topic")) { e.preventDefault(); cycle(e.shiftKey ? -1 : 1); }
        });
        WIN.addEventListener("keydown", onEsc, true);
        list.addEventListener("click", e => {
          const par = e.target.closest && e.target.closest("[data-hp-par]");
          if (par) { e.preventDefault(); e.stopPropagation(); cycle(1); return; }
          if (e.target.closest && e.target.closest("[data-hp-fold]")) { st.archived = true; draw(); input.focus(); return; }
          const b = e.target.closest && e.target.closest("[data-hp-row]");
          if (b) choose(live[+b.dataset.hpRow]);
        });
        veil.querySelector("[data-hp-no]").addEventListener("click", () => finish(null));
        veil.querySelector("[data-hp-go]").addEventListener("click", () => choose(live[st.cur]));
        veil.addEventListener("mousedown", e => { if (e.target === veil) finish(null); });
        draw();
        setTimeout(() => { if (!narrow) input.focus({ preventScroll: true }); }, 30);
      });
    }
    let roomsNav = null, roomsTick = null;
    const roomsHidden = () => new Set([].concat(vaultSettings.read(app).rooms_hidden || []).flatMap(x => String(x).split(","))
      .map(x => x.trim().toLowerCase()).filter(Boolean));
    function phoneTop(viewRoot) {
      if (!viewRoot || !viewRoot.isConnected || !document.body.classList.contains("is-mobile")) return 0;
      const scroller = viewRoot.closest(".markdown-preview-view, .view-content");
      let gap = [...viewRoot.children].find(c => c.classList.contains("vc-phonetop"));
      const moved = scroller ? scroller.scrollTop : 0;
      if (gap && moved > 8) return parseFloat(gap.style.height) || 0;
      const top = viewRoot.getBoundingClientRect().top + moved, leaf = viewRoot.closest(".workspace-leaf-content");
      const PRESS = "button, .clickable-icon, [role=button], .view-action";
      const seen = el => { const cs = getComputedStyle(el); return el.getClientRects().length && cs.visibility !== "hidden" && cs.display !== "none" && +cs.opacity > 0; };
      let foot = 0;
      try {
        for (const el of leaf ? leaf.querySelectorAll(".view-header :is(" + PRESS + ")") : []) {
          if (viewRoot.contains(el) || !seen(el)) continue;
          const r = el.getBoundingClientRect();
          if (r.height && r.width && r.bottom > top && r.top < top + 120) foot = Math.max(foot, r.bottom - top);
        }
      } catch (e) {}
      if (moved <= 8) try {
        const w = viewRoot.getBoundingClientRect(), xs =[24, w.width * .25, w.width / 2, w.width * .75, w.width - 24].map(x => Math.round(w.left + x));
        for (let y = Math.max(0, Math.round(top)); y < top + 120; y += 4) for (const x of xs) {
          const el = document.elementFromPoint(x, y);
          if (el && !viewRoot.contains(el) && !el.contains(viewRoot) && el.closest(PRESS)) foot = Math.max(foot, y + 4 - top);
        }
      } catch (e) {}
      if (!foot && top < 4) try { const s = document.createElement("div"); s.style.cssText = "position:fixed;top:0;left:0;width:1px;height:env(safe-area-inset-top, 0px);visibility:hidden;pointer-events:none"; document.body.appendChild(s); foot = s.getBoundingClientRect().height || 0; s.remove(); } catch (e) {}
      const h = foot > 0 ? Math.round(foot + 4) : 0;
      if (!h) { if (gap) gap.remove(); return 0; }
      if (!gap) { gap = document.createElement("div"); gap.className = "vc-phonetop"; gap.setAttribute("aria-hidden", "true"); }
      const row = [...viewRoot.children].find(c => c.classList.contains("vc-rooms"));
      if (row ? gap.nextElementSibling !== row : viewRoot.firstElementChild !== gap) viewRoot.insertBefore(gap, row || viewRoot.firstChild);
      gap.style.height = h + "px";
      return h;
    }
    const roomGroupOpen = id => { try { return localStorage.getItem("vc-rooms-grp:" + id) === "open"; } catch (_) { return false; } };
    function roomsBar(anchor, { now = true, E = null, hidden = null } = {}) {
      if (!anchor || !anchor.parentNode) return null;
      if (typeof hidden === "boolean" ? hidden : String((vaultSettings.read(app) || {}).rooms_row || "").trim().toLowerCase() === "hidden") {
        const root = anchor.closest(".nm, .dn, .hd, .gy, .lt, .md, .sd, .sv, .mv, .fv, .mp") || anchor.parentNode;
        [...root.children].filter(c => c.classList && c.classList.contains("vc-rooms")).forEach(x => x.remove());
        if (roomsNav) roomsNav.remove();
        roomsNav = null;
        return null;
      }
      let nav = roomsNav && roomsNav.isConnected ? roomsNav : null;
      const viewRoot = anchor.closest(".nm, .dn, .hd, .gy, .lt, .md, .sd, .sv, .mv, .fv, .mp") || anchor.parentNode;
      if (!nav) {
        const had = [...viewRoot.children].filter(c => c.classList && c.classList.contains("vc-rooms"));
        had.slice(1).forEach(x => x.remove());
        if (had[0]) nav = roomsNav = had[0];
      }
      if (!nav) {
        nav = roomsNav = document.createElement("nav"); nav.className = "vc-rooms"; nav.setAttribute("aria-label", "the vault's rooms");
        viewRoot.insertBefore(nav, viewRoot.firstChild);
      }
      if (!nav.__aligned) {
        nav.__aligned = true;
        const row = nav;
        const align = () => {
          try {
            const cs = getComputedStyle(viewRoot), px = k => parseFloat(cs[k]) || 0;
            row.style.marginLeft = -px("paddingLeft") + "px"; row.style.marginRight = -px("paddingRight") + "px";
            row.style.marginTop = -px("paddingTop") + "px";
          } catch (e) {}
        };
        align();
        if (typeof ResizeObserver === "function") {
          try { const ro = new ResizeObserver(() => { if (!row.isConnected) { ro.disconnect(); return; } align(); }); ro.observe(viewRoot); } catch (e) {}
        }
      }
      if (document.body.classList.contains("is-mobile")) [50, 450, 1300, 3500].forEach(ms => setTimeout(() => phoneTop(viewRoot), ms));
      roomsList = roomsList || readRooms(app).catch(() => []);
      const paintNow = () => {
        const el = roomsNav && roomsNav.querySelector(".vc-rooms-now"); if (!el) return;
        const d = new Date(), word = dayWord();
        el.innerHTML = `<b>${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}</b>${word ? `<span>${esc(word)}</span>` : ""}`;
      };
      Promise.all([roomsList, Promise.resolve(ready).catch(() => null)]).then(([list]) => {
        const here = hereOf(), dir = dailyFolder(app);
        const onDay = /^\d{4}-\d{2}-\d{2}\.md$/.test(here.split("/").pop()) && here.startsWith(dir ? dir + "/" : "");
        const hidden = roomsHidden();
        const all = [{ name: "Daily note", path: "@daily", mark: "sun" }, ...list].filter(r => r.path === here || !hidden.has(r.name.toLowerCase()));
        const isOn = r => r.path === "@daily" ? onDay : r.path === here;
        const go = i => { const r = all[i], on = isOn(r);
          return `<button class="vc-ib vc-ib--word" data-room-go="${i}" aria-label="${esc(r.name)}"${on ? ` aria-current="page"` : ""}>${icon(r.mark)}<span class="vc-word">${esc(r.name)}</span></button>`; };
        const groups = roomGroups().map(g => ({ ...g, at: [] })), loose = [];
        all.forEach((r, i) => { const g = r.path !== "@daily" && groups.find(x => x.match.test(r.name)); (g ? g.at : loose).push(i); });
        const grp = g => {
          const open = roomGroupOpen(g.id), inside = g.at.find(i => isOn(all[i]));
          const say = `${g.word}: ${g.at.map(i => all[i].name).join(", ")}${inside != null ? ` — you are in ${all[inside].name}` : ""}`;
          return `<span class="vc-rooms-grp${open ? " is-open" : ""}" data-room-grp="${esc(g.id)}"><span class="vc-rooms-gin"${open ? "" : " hidden"}>${g.at.map(go).join("")}</span>` +
            `<button class="vc-ib vc-ib--word vc-rooms-gp${inside != null ? " is-here" : ""}" aria-expanded="${open}" aria-label="${esc(say)}">${icon(g.mark)}<span class="vc-word">${esc(g.word)}</span>${icon(open ? "next" : "prev")}</button></span>`;
        };
        nav.innerHTML = `<button class="vc-ib vc-ib--word vc-rooms-new" data-room-new aria-label="new — ${esc(commands.named(4))}…: the command line">${icon("add")}<span class="vc-word">new</span></button>` +
          loose.map(go).join("") + groups.filter(g => g.at.length).map(grp).join("") +
          (now ? `<span class="vc-rooms-now" aria-label="the hour, and today's kind of day"></span>` : "");
        nav.querySelectorAll("[data-room-grp]").forEach(w => w.querySelector(".vc-rooms-gp").addEventListener("click", e => {
          e.preventDefault();
          const id = w.dataset.roomGrp, open = !w.classList.contains("is-open"), inn = w.querySelector(".vc-rooms-gin"), b = e.currentTarget;
          try { localStorage.setItem("vc-rooms-grp:" + id, open ? "open" : ""); } catch (_) {}
          w.classList.toggle("is-open", open); inn.hidden = !open; b.setAttribute("aria-expanded", String(open));
          const mk = b.querySelector(".vc-ic:last-child"); if (mk) mk.outerHTML = icon(open ? "next" : "prev");
          if (open && inn.animate) try { inn.animate([{ opacity: 0, transform: "translateX(12px)" }, { opacity: 1, transform: "none" }], { duration: 200, easing: "cubic-bezier(.2,.8,.2,1)" }); } catch (_) {}
        }));
        nav.querySelector("[data-room-new]")?.addEventListener("click", e => { e.preventDefault(); newPop(e.currentTarget, { E }); });
        nav.querySelectorAll("[data-room-go]").forEach(b => b.addEventListener("click", e => {
          e.preventDefault(); const r = all[+b.dataset.roomGo];
          if (r && !b.getAttribute("aria-current")) openRoom(r);
        }));
        if (now) {
          paintNow();
          if (!roomsTick) {
            roomsTick = every(paintNow, 30000);
            try { hear(app.metadataCache, "changed", f => { if (f && f.path === todayPath()) paintNow(); }); } catch (e) {}
          }
        }
      });
      return nav;
    }

    function dock(nav, { host = root, watch = null, narrow = null } = {}) {
      const bar = typeof nav === "function" ? nav : () => nav;
      const isNarrow = narrow || (() => host.dataset && host.dataset.cols ? host.dataset.cols === "narrow" : (host.getBoundingClientRect().width || 9999) < 720);
      const d = document.createElement("nav");
      d.className = "vc-host vc-dock"; d.setAttribute("aria-label", "the pages, at the foot of the pane");
      if (room) d.dataset.room = room;
      document.body.appendChild(d);
      let sig = null, obs = [], tick = 0;
      const copy = () => {
        const b = bar(); if (!b) return;
        const tabs = [...b.querySelectorAll(".vc-tab")], s = tabs.map(t => t.outerHTML).join("");
        if (s === sig) return; sig = s;
        d.innerHTML = "";
        tabs.forEach(t => {
          const c = t.cloneNode(true);
          c.removeAttribute("id"); c.querySelectorAll("[id]").forEach(x => x.removeAttribute("id"));
          c.addEventListener("click", e => { e.preventDefault(); t.click(); });
          d.appendChild(c);
        });
      };
      const pane = () => { try { return host.closest(".workspace-leaf-content") || host.closest(".view-content"); } catch (e) { return null; } };
      function teardown() { clearInterval(tick); obs.forEach(o => { try { o.disconnect(); } catch (e) {} }); d.remove(); }
      const place = () => {
        if (gone()) { teardown(); return; }
        copy();
        let on = false;
        try { on = !!isNarrow(); } catch (e) {}
        const vw = window.innerWidth || 0, vh = window.innerHeight || 0, v = host.getBoundingClientRect(), p = pane(), pr = p ? p.getBoundingClientRect() : null;
        const L = Math.max(0, v.left, pr ? pr.left : 0), R = Math.min(vw, v.right, pr ? pr.right : vw), B = Math.min(vh, pr ? pr.bottom : vh);
        on = on && R - L > 120 && v.top < vh && v.bottom > 0;
        d.classList.toggle("on", on);
        const b = bar(); if (b) b.classList.toggle("vc-tabs--docked", on);
        host.classList.toggle("vc-docked", on);
        if (!on) { host.style.removeProperty("--vc-dock-clear"); return; }
        const nb = document.querySelector(".mobile-navbar"), nr = nb && nb.getClientRects().length ? nb.getBoundingClientRect() : null;
        const foot = nr && nr.height && nr.top < B ? nr.top : B;
        d.style.left = `${Math.round((L + R) / 2)}px`; d.style.bottom = `${Math.max(8, Math.round(vh - foot + 12))}px`; d.style.maxWidth = `${Math.max(160, Math.round(R - L - 24))}px`;
        if (foot < B) host.style.setProperty("--vc-dock-clear", `${Math.round(B - foot + 12 + (d.offsetHeight || 52) + 16)}px`);
        else host.style.removeProperty("--vc-dock-clear");
      };
      try { const mo = new MutationObserver(() => requestAnimationFrame(place)); mo.observe(watch || bar() || host, { subtree: true, childList: true, attributes: true, attributeFilter: ["class", "aria-current", "aria-selected"] }); obs.push(mo); } catch (e) {}
      try { const mc = new MutationObserver(place); mc.observe(host, { attributes: true, attributeFilter: ["data-cols"] }); obs.push(mc); } catch (e) {}
      try { const ro = new ResizeObserver(() => place()); ro.observe(host); obs.push(ro); } catch (e) {}
      tick = setInterval(place, 1500);
      place();
      return d;
    }
    function working(label) {
      const box = tBox();
      if (!box) return { stop() {} };
      if (tTimer) clearTimeout(tTimer);
      if (tRaf) cancelAnimationFrame(tRaf);
      if (tTick) clearInterval(tTick);
      tUndo = null;
      const t0 = Date.now();
      const paint = () => {
        const s = Math.round((Date.now() - t0) / 1000);
        box.innerHTML = `<span class="${TO.x}">${label} — <b>${s}s</b>` +
          (s > 45 ? " · longer than usual" : "") + `</span>`;
        box.classList.add("on");
      };
      paint();
      tTick = setInterval(paint, 1000);
      return { stop() { if (tTick) clearInterval(tTick); tTick = null; hideToast(); } };
    }

    let LOOP_IO = null;
    const LOOPS = new Map();
    function loop(el, keyframes, opts = {}) {
      if (!el || !el.animate) return null;
      let a = null;
      try { a = el.animate(keyframes, opts); } catch (e) { return null; }
      if (typeof IntersectionObserver === "undefined") return a;
      if (!LOOP_IO) LOOP_IO = new IntersectionObserver(es => es.forEach(e => {
        const list = LOOPS.get(e.target); if (!list) return;
        list.forEach(x => { if (x.playState === "finished" || x.playState === "idle") return; if (e.isIntersecting) x.play(); else x.pause(); });
      }));
      LOOPS.forEach((list, t) => { if (!t.isConnected || !list.length) { LOOP_IO.unobserve(t); list.forEach(x => { try { x.cancel(); } catch (e) {} }); LOOPS.delete(t); } });
      const list = LOOPS.get(el) || [];
      list.push(a); LOOPS.set(el, list);
      a.addEventListener("cancel", () => { const l = LOOPS.get(el); if (l) l.splice(l.indexOf(a) >>> 0, 1); });
      a.pause();
      LOOP_IO.unobserve(el); LOOP_IO.observe(el);
      return a;
    }

    const gone = () => !root || !root.isConnected;
    function hold(target, type, fn, opts) {
      const h = e => { if (gone()) { target.removeEventListener(type, h, opts); return; } return fn(e); };
      target.addEventListener(type, h, opts);
      return h;
    }
    function hear(source, name, fn) {
      let ref = null;
      ref = source.on(name, (...a) => { if (gone()) { try { source.offref(ref); } catch (e) {} return; } return fn(...a); });
      return ref;
    }
    function every(fn, ms) {
      const id = setInterval(() => { if (gone()) { clearInterval(id); return; } fn(); }, ms);
      return id;
    }

    const FO = Object.assign({ classes: ["vc-label--closed"], isClosed: () => undefined, setClosed: () => {} },
      foldOpts || {});
    const FOLD_WIRED = new WeakSet();
    function wireCollapse(scope) {
      const host = scope;
      if (!host) return;
      if (!FOLD_WIRED.has(host)) {
        FOLD_WIRED.add(host);
        host.addEventListener("click", e => {
          const h = e.target.closest?.("[data-coll]");
          if (!h || !host.contains?.(h)) return;
          if (e.target.closest("button, input, select, a")) return;
          if (e.__nmColl) return;
          e.__nmColl = true;
          const key = h.dataset.coll;
          const was = FO.isClosed(key);
          const next = !(was !== undefined ? !!was : h.classList.contains(FO.classes[0]));
          FO.setClosed(key, next);
          FO.classes.forEach(c => h.classList.toggle(c, next));
        });
      }
      host.querySelectorAll?.("[data-coll]").forEach(h => {
        const v = FO.isClosed(h.dataset.coll);
        if (v !== undefined) FO.classes.forEach(c => h.classList.toggle(c, !!v));
      });
    }

    const TINT_READ = new Map();
    function tintColours(ref) {
      const s = String(ref || "").trim();
      if (!s) return Promise.resolve(null);
      if (!TINT_READ.has(s)) TINT_READ.set(s, (async () => {
        let bytes = null;
        if (/^https?:\/\//i.test(s)) {
          let req = null;
          try { const o = require("obsidian"); if (o && o.requestUrl) req = o.requestUrl; } catch (e) {}
          try { if (!req && window.requestUrl) req = window.requestUrl; } catch (e) {}
          if (!req) return null;
          const r = await req({ url: s, method: "GET", throw: false });
          if (!r || r.status < 200 || r.status >= 300) return null;
          bytes = r.arrayBuffer;
        } else {
          let f = null;
          try { f = app.metadataCache.getFirstLinkpathDest(s.replace(/^!?\[\[|\]\]$/g, "").split("|")[0].trim(), "") || app.vault.getAbstractFileByPath(s); } catch (e) {}
          if (!f || !f.extension || typeof app.vault.readBinary !== "function") return null;
          bytes = await app.vault.readBinary(f);
        }
        if (!bytes || !bytes.byteLength) return null;
        const url = URL.createObjectURL(new Blob([bytes]));
        try {
          const im = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error("not a picture")); i.src = url; });
          const w = 64, h = Math.max(8, Math.min(128, Math.round(64 * (im.naturalHeight || 1) / (im.naturalWidth || 1))));
          const c = document.createElement("canvas"); c.width = w; c.height = h;
          const x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(im, 0, 0, w, h);
          return theme.pictureColours(x.getImageData(0, 0, w, h).data) || null;
        } finally { URL.revokeObjectURL(url); }
      })().catch(() => null).then(c => { if (!c) TINT_READ.delete(s); return c; }));
      return TINT_READ.get(s);
    }
    async function tint(host, ref) {
      if (!host || !host.style) return false;
      const me = host.__tintAsk = {};
      const colours = ref ? await tintColours(ref) : null;
      let lines = [];
      if (colours && host.__tintAsk === me) {
        const c = themeChosen();
        try { lines = theme.tinted(await themes(), c.style, c.palette, colours); } catch (e) { lines = []; }
      }
      if (host.__tintAsk !== me) return false;
      const keep = new Set();
      lines.forEach(([k, v]) => {
        if (!/^--lp-/.test(k) || /^--lp-(fl-|weather$|art-|pv-|f-)/.test(k) || String(v).length > 6000) return;
        keep.add(k); try { host.style.setProperty(k, v); } catch (e) {}
      });
      (host.__tintKeys || []).forEach(k => { if (!keep.has(k)) host.style.removeProperty(k); });
      host.__tintKeys = [...keep];
      host.toggleAttribute("data-tinted", keep.size > 0);
      return keep.size > 0;
    }

    function pictureUrl(ref) {
      const s = String(ref || "").trim();
      if (!s) return "";
      if (/^https?:\/\//i.test(s)) return s;
      try {
        const f = app.metadataCache.getFirstLinkpathDest(
          s.replace(/^!?\[\[|\]\]$/g, "").split("|")[0].trim(), "");
        return f ? app.vault.getResourcePath(f) : "";
      } catch (e) { return ""; }
    }

    return { addDayTask: dayNote.addTask, addDayMoney: dayNote.addMoney, spentKinds: () => dayNote.SPENT.slice(), applyTheme, ask, askConfirm, banner, closePop, guard, hideToast, icon, iconify, lastPress, loadChrome, net,
      pack, packs, sockets, ready, loadModule, dayShape: SHAPE_IN, part: partOn,
      modal, moonMark, moonNow, pictureUrl, popAt, themeChosen, themeRoll, themePerf, themePick: theme.pick, themeVars: theme.vars, themeColours: theme.pictureColours, themes, tint,
      every, hear, hold, loop, toast, vaultKeys, veil, wireCollapse, wireWhy, working,
      dailyFolder: settings => dailyFolder(app, settings),
      pdfjs: loadPdf,
      dayAsk,
      moneyCount: () => money,
      settingsRead: () => vaultSettings.read(app), settingsWrite: patch => vaultSettings.write(app, patch), settingsPath: () => vaultSettings.PATH,
      roomsRead: () => (roomsList = roomsList || readRooms(app).catch(() => [])), roomsBar, phoneTop, receipt, dock,
      tasksRead: () => tasks, taskTick: (p, at, raw, on, iso) => tasks.tickAt(app, p, at, raw, on, iso),
      tasksCarried: (iso, opts) => tasks.carried(app, dailyFolder(app), iso, opts),
      habitsRead: () => habits, habitRecords: (isos, list, opts) => habits.records(app, isos, list, opts),
      kindsRead: () => kinds, mapsRead: () => maps, commandsRead: () => commands, command: runCommand, newPop,
      homePicker, giveHome, homeName, backRead: () => back };
  }

  async function askHome(app, opts = {}, note = "") {
    const NV = mount({ root: document.body, app, note, tag: "[home]" });
    try { await NV.loadChrome({ theme: false }); } catch (e) {}
    return NV.homePicker(Object.assign({ mode: "file" }, opts));
  }

  const DAY_ASK = "vc-dayask";
  const dayAsk = {
    event: DAY_ASK,
    put(iso, what) { try { localStorage.setItem(DAY_ASK, JSON.stringify(Object.assign({}, what, { day: iso, t: Date.now() }))); window.dispatchEvent(new CustomEvent(DAY_ASK)); } catch (e) {} },
    take(iso) {
      try {
        const j = JSON.parse(localStorage.getItem(DAY_ASK) || "null");
        if (!j || j.day !== iso) return null;
        localStorage.removeItem(DAY_ASK);
        return Date.now() - j.t > 120000 ? null : j;
      } catch (e) { return null; }
    },
  };
  return { VERSION, register, packs, dayAsk, askHome, sockets, parts: () => PARTS, pack: packDef, loadPacks: app => loadPacksOf(app), meets, dayShape: SHAPE_IN, mount, dayNote, money, settings: vaultSettings, readRooms, roomMarks, tasks, habits, kinds, maps, back, commands, dailyFolder, icon, moonMark, moonNow, theme, vaultKeys, ICON_NAMES: Object.keys(ICONS),
    esc, banner, netKept: url => NETC.has(url), pdfjs: loadPdf };
})();
```

```css
.vc-pop[data-room="kitchen"] {
  background: var(--bg-2) !important; border-color: color-mix(in srgb, var(--a) 22%, transparent) !important;
  border-radius:var(--r-item) !important;
}
.vc-pop[data-room="kitchen"] .vc-pf-i:focus { border-color: color-mix(in srgb, var(--a) 55%, transparent) !important; }
.vc-pop .fv-toolgrid { display: flex; flex-wrap: wrap; gap: 8px; margin: 14px 0 4px; }
.vc-pop .fv-tool { font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); text-transform:var(--label-case);
  color: var(--fnt); border: var(--hair-w) solid var(--hair); border-radius:var(--r-pill); padding: 4px 10px 5px; cursor: pointer;
  transition: color .22s ease, border-color .22s ease, background .22s ease; }
.vc-pop .fv-tool:hover { color: var(--dim); border-color: var(--border); }
.vc-pop .fv-tool.on { color: var(--bright); background: color-mix(in srgb, var(--light) 9%, transparent); border-color: color-mix(in srgb, var(--bright) 30%, transparent); }
.vc-pop .fv-tagsug { margin-bottom: 16px; padding-bottom: 14px; border-bottom: var(--hair-w) solid var(--hair);
  font-family: var(--f-text); font-size: 14px; font-style: italic; line-height: 2.2; color: var(--dim); }
.vc-pop .fv-tagsug .fv-tool { margin: 0 4px; }
.vc-pop .fv-tagall { font-family: var(--f-text); font-size: 14px; font-style: italic; color: var(--fnt); }

.vc-pop .vc-pf-b {
  font-family: var(--f-text); font-size: 14px; line-height: 1.6; color: var(--dim);
  padding-bottom: 11px; border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 9%, transparent);
}
.vc-pop .vc-pf-b .vc-pf-pic {
  display: block; width: 100%; max-height: 300px; object-fit: contain;
  border-radius: var(--r); border: var(--hair-w) solid var(--hair);
  background: rgba(0,0,0,.28); margin-bottom: 8px;
}
.vc-pop .vc-pf-b .vc-pf-aud { display: block; width: 100%; margin-bottom: 8px; }
.vc-pop .vc-pf { display: flex; flex-direction: column; gap: 12px; }
.vc-pop .vc-pf-r { display: flex; flex-direction: column; gap: 5px; }
.vc-pop .vc-pf-k {
  font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label);
  text-transform:var(--label-case); color: var(--dim);
}
.vc-pop .vc-pf-k i { font-style: normal; opacity: .75; }
.vc-pop .vc-pf-h { font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--dim); }
.vc-pop .vc-pf-i {
  width: 100% !important; box-sizing: border-box; height: auto !important;
  min-height: 0 !important; line-height: normal !important;
  background: rgba(0,0,0,.28) !important; border: var(--hair-w) solid color-mix(in srgb, var(--a) 18%, transparent) !important;
  border-radius:var(--r) !important; padding: 8px 10px !important; outline: none !important;
  box-shadow: inset 0 1px 2px rgba(0,0,0,.35) !important;
  color: var(--tx) !important; font-family: var(--f-text); font-size: 15px;
}
.vc-pop .vc-pf-i:focus { border-color: color-mix(in srgb, var(--a) 55%, transparent) !important; }
.vc-pop .vc-pf-i.vc-pf-area {
  min-height: 150px !important; resize: vertical; white-space: pre-wrap;
  font-family: var(--f-label); font-size: 13px; line-height: 1.55 !important;
}
.vc-pop .vc-pf-seg { display: flex; flex-wrap: wrap; gap: 5px; }
.vc-pop .vc-pf-b + .vc-pf-a { border-top: 0; padding-top: 2px; }
.vc-pop .vc-pf-a {
  display: flex; gap: 8px; justify-content: flex-end;
  position: sticky; bottom: -14px; background: var(--bg-2);
  margin: 2px 0 -14px; padding: 9px 0 14px;
  border-top: var(--hair-w) solid color-mix(in srgb, var(--a) 10%, transparent);
}
.vc-pop .vc-pf-btn {
  height: auto !important; min-height: 0 !important; line-height: normal !important;
  padding: 6px 14px 7px !important; border: var(--hair-w) solid color-mix(in srgb, var(--a) 22%, transparent) !important;
  border-radius:var(--r) !important; background: transparent !important; box-shadow: none !important;
  font-family: var(--f-label); font-size: 12px; font-weight: bold; letter-spacing: var(--trk-label);
  text-transform:var(--label-case); color: var(--dim); cursor: pointer; white-space: nowrap;
  transition: color 180ms, border-color 180ms;
}
.vc-pop .vc-pf-btn:hover { color: var(--tx); }
.vc-pop .vc-pf-btn.vc-pf-btn--go { color: var(--a); border-color: color-mix(in srgb, var(--a) 50%, transparent) !important; }
.vc-pop .vc-pf-btn.vc-pf-btn--warn { color: var(--over); border-color: color-mix(in srgb, var(--over) 50%, transparent) !important; }
.vc-pop .vc-pf-btn.on { color: var(--on-a); background: var(--a) !important; border-color: var(--a) !important; }

.vc-veil { position: fixed; inset: 0; z-index: 2147483002; display: flex; align-items: center; justify-content: center;
  background: color-mix(in srgb, var(--ink) 42%, transparent); cursor: progress; opacity: 0; transition: opacity .14s ease .05s; }
.vc-veil.on { opacity: 1; }
.vc-veil.off { opacity: 0; pointer-events: none; transition: opacity .2s ease; }
.vc-veil-t { position: relative; overflow: hidden; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); text-transform: var(--label-case);
  color: var(--bright); padding: 10px 18px 12px; background: var(--bg-2); border: var(--hair-w) solid var(--hair); border-radius: var(--r-pill); box-shadow: var(--sh-2); }
.vc-veil-bar { position: absolute; left: 0; bottom: 0; width: 40%; height: 2px; background: var(--a); }
.nv-banner { position: relative; height: clamp(150px, 30cqi, 220px); overflow: hidden;
  background: radial-gradient(70% 90% at 22% 18%, color-mix(in srgb, var(--tint) 26%, transparent), transparent 70%),
    radial-gradient(50% 70% at 78% 60%, color-mix(in srgb, var(--tint) 12%, transparent), transparent 72%),
    linear-gradient(170deg, var(--bg-3), var(--bg-1));
  -webkit-mask-image: linear-gradient(180deg, #000 45%, transparent); mask-image: linear-gradient(180deg, #000 45%, transparent); }
.nv-banner-still { position: absolute; right: 7%; top: 52%; width: clamp(140px, 28cqi, 220px); aspect-ratio: 1; transform: translateY(-50%); }
.nv-banner-pool { position: absolute; left: -35%; right: -35%; top: 38%; height: 70%; border-radius: 50%;
  background: radial-gradient(closest-side, color-mix(in srgb, var(--tint) 30%, transparent), color-mix(in srgb, var(--tint) 8%, transparent) 60%, transparent); }
.nv-banner .nv-banner-mark { position: absolute; inset: 0; width: 100%; height: 100%; transform: rotate(-5deg);
  color: color-mix(in srgb, var(--tint) 72%, var(--light) 22%); opacity: .6;
  filter: drop-shadow(0 0 12px color-mix(in srgb, var(--tint) 75%, transparent)); }
.nv-banner .nv-banner-mark * { vector-effect: non-scaling-stroke; stroke-width: 1.6px; }

.vc-rooms { display: flex; align-items: center; flex-wrap: wrap; gap: 2px; min-height: 32px; margin: 0 0 8px; position: relative; z-index: 3;
  box-sizing: border-box; padding: 12px clamp(16px, 3.2vw, 44px) 0; }
.vc-phonetop { display: block; flex: none; pointer-events: none; }
.vc-rooms .vc-ib { color: var(--fnt); }
.vc-rooms .vc-ib:hover, .vc-rooms .vc-ib:focus-visible { color: var(--tx); }
.vc-rooms .vc-ib[aria-current="page"] { color: var(--a); background: color-mix(in srgb, var(--a) 12%, transparent) !important; padding: 0 12px 0 7px !important; cursor: default; }
.vc-rooms-now { margin-left: auto; display: inline-flex; align-items: baseline; gap: 10px; padding-right: 4px;
  font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); text-transform: var(--label-case); color: var(--dim); }
.vc-rooms-now b { font-weight: inherit; color: var(--tx); font-variant-numeric: tabular-nums; }

.vc-dock { position: fixed; z-index: 2147482990; display: none; align-items: center; gap: 2px; width: max-content; transform: translateX(-50%);
  padding: 4px 6px; overflow-x: auto; scrollbar-width: none; border: var(--hair-w) solid var(--hair); border-radius: var(--r-pill);
  background: color-mix(in srgb, var(--bg-2) 92%, transparent); box-shadow: var(--sh-3); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); }
.vc-dock.on { display: flex; }
.vc-dock::-webkit-scrollbar { display: none; }
.vc-dock .vc-tab { height: 44px !important; padding: 0 12px !important; border-radius: var(--r-pill) !important; }
.vc-dock .vc-tab::after { inset: auto 14px 5px !important; height: 1px !important; }
.vc-dock .vc-tab-n { margin-top: 9px; }
.vc-tabs--docked > .vc-tab { display: none !important; }
.vc-tabs--docked:not(:has(.vc-tabs-r:not(:empty))) { display: none !important; }
.vc-docked { padding-bottom: var(--vc-dock-clear, calc(80px + env(safe-area-inset-bottom, 0px))) !important; }
.vc-docked :is(.vc-toast, .nm-toast, .fv-toast) { bottom: calc(var(--vc-dock-clear, calc(80px + env(safe-area-inset-bottom, 0px))) - 4px) !important; }

.vc-pop.vc-pop--sheet { padding: 22px 22px 18px !important; gap: 14px !important; border-radius: var(--r-soft) 0 0 var(--r-soft) !important;
  border-right: 0 !important; box-shadow: var(--sh-3), -24px 0 48px -24px color-mix(in srgb, var(--bg) 70%, transparent) !important; }
.vc-pop .vc-pop-x { position: absolute; top: 12px; right: 12px; color: var(--fnt); }
.vc-pop .vc-pop-x:hover { color: var(--tx); }
.vc-pop .vc-sheet-k { font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-head); text-transform: var(--label-case); color: var(--a); padding-right: 36px; }
.vc-pop .vc-sheet-sec { padding: 10px 0 12px; border-bottom: var(--hair-w) solid var(--hair); display: flex; flex-direction: column; gap: 8px; }
.vc-pop .vc-sheet-sec:last-of-type { border-bottom: 0; }
.vc-pop .vc-sheet-sec h3 { margin: 0; font-family: var(--f-display); font-size: 20px; font-weight: 400; font-variant-caps: all-small-caps; letter-spacing: .08em; color: var(--a); }
.vc-pop .vc-sheet-note { font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); text-transform: var(--label-case); color: var(--fnt); line-height: 1.6; }
.vc-pop .vc-sheet-field { width: 100% !important; height: auto !important; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--tx);
  background: var(--bg-2) !important; border: var(--hair-w) solid var(--hair) !important; border-radius: var(--r) !important; padding: 8px 12px 9px !important; box-shadow: none !important; }
.vc-pop .vc-sheet-field:focus { border-color: var(--border) !important; }
.vc-pop .vc-sheet-foot { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 14px; padding-top: 10px; border-top: var(--hair-w) solid var(--hair); margin-top: auto; }

.vc-pop .vc-qbox { display: flex; flex-direction: column; gap: 6px; }
.vc-pop .vc-qform { display: flex; flex-direction: column; gap: 8px; padding-bottom: 12px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-pop .vc-qform .vc-sheet-field { box-sizing: border-box; }
.vc-pop .vc-qwords { min-height: 72px; resize: vertical; text-align: start !important; font-family: var(--f-display) !important; font-style: italic; font-size: 15px !important; letter-spacing: 0 !important; line-height: 1.5 !important; }
.vc-pop .vc-qrow { display: flex; align-items: center; gap: 8px; }
.vc-pop .vc-qrow .vc-qwho { flex: 1 1 auto; width: auto !important; min-width: 0; text-align: start !important; }
.vc-pop .vc-qlist { display: flex; flex-direction: column; }
.vc-pop .vc-qline { display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: baseline; gap: 2px 10px; padding: 10px 4px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-pop .vc-qline .vc-q { font-family: var(--f-display); font-style: italic; font-size: 14px; line-height: 1.45; color: var(--tx); }
.vc-pop .vc-qline small { grid-column: 1; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--fnt); }
.vc-pop .vc-qline .vc-qacts { grid-column: 2; grid-row: 1 / span 2; align-self: center; display: inline-flex; gap: 2px; opacity: .55; transition: opacity var(--t); }
.vc-pop .vc-qline:hover .vc-qacts, .vc-pop .vc-qline .vc-qacts:focus-within { opacity: 1; }
.vc-pop .vc-qline.is-on small { color: var(--a); }
.vc-pop .vc-qline.is-editing { background: color-mix(in srgb, var(--a) 7%, transparent); border-radius: var(--r); }

.vc-rooms .vc-rooms-new { color: var(--a); margin-right: 6px; }
.vc-rooms .vc-rooms-new .vc-word { max-width: 14em; opacity: 1; margin-inline-start: .4em; }
.vc-pop .vc-new-k { font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-head); text-transform: var(--label-case); color: var(--a); }
.vc-pop .vc-new-line { display: flex; align-items: center; gap: 10px; border-bottom: var(--hair-w) solid var(--hair); padding: 2px 0 8px; color: var(--fnt); }
.vc-pop .vc-new-line .vc-ic { width: 16px; height: 16px; flex: none; }
.vc-pop .vc-new-i { flex: 1 1 auto; min-width: 0; width: 100% !important; height: auto !important; background: transparent !important; border: 0 !important;
  box-shadow: none !important; outline: 0; padding: 4px 0 !important; font-family: var(--f-text); font-style: italic; font-size: 16px; color: var(--bright); }
.vc-pop .vc-new-i::placeholder { color: var(--fnt); }
.vc-pop .vc-new-words { display: flex; flex-wrap: wrap; gap: 5px; max-width: 420px; }
.vc-pop .vc-new-w { height: auto !important; padding: 3px 9px 4px !important; border: var(--hair-w) solid var(--hair) !important; border-radius: var(--r-pill) !important;
  background: transparent !important; box-shadow: none !important; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--dim); cursor: pointer; }
.vc-pop .vc-new-w:hover, .vc-pop .vc-new-w:focus-visible { color: var(--bright); border-color: var(--border) !important; }
.vc-pop .vc-new-said { margin: 2px 0 0; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--dim); }

.vc-hp-veil { position: fixed; inset: 0; z-index: 2147483000; display: grid; place-items: start center; padding: 12vh 14px 14px;
  background: color-mix(in srgb, var(--ink, #000) 40%, transparent); }
.vc-hp { width: min(600px, 100%); max-height: min(76vh, 640px); display: flex; flex-direction: column; overflow: hidden;
  border-radius: var(--r-focal); background: var(--bg-2); box-shadow: var(--sh-3), var(--lit, none);
  border: var(--hair-w) solid color-mix(in srgb, var(--a) 18%, transparent); color: var(--tx); font-family: var(--f-text); }
.vc-hp-h { display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap; padding: 14px 16px 4px; font-size: 14px; color: var(--dim); }
.vc-hp-h b { color: var(--bright); font-weight: 600; }
.vc-hp-ctx { margin-left: auto; font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); text-transform: var(--label-case); color: var(--fnt); }
.vc-hp-in { display: flex; align-items: center; gap: 10px; margin: 6px 16px 4px; padding: 0 0 8px; border-bottom: var(--hair-w) solid var(--hair); color: var(--fnt); }
.vc-hp-in .vc-ic { width: 16px; height: 16px; flex: none; }
.vc-hp-i { flex: 1 1 auto; min-width: 0; width: 100% !important; height: auto !important; padding: 6px 0 !important; border: 0 !important;
  background: transparent !important; box-shadow: none !important; outline: 0; font-family: var(--f-text); font-size: 16px; color: var(--bright); }
.vc-hp-i::placeholder { color: var(--fnt); font-style: italic; }
.vc-hp-list { flex: 1 1 auto; overflow-y: auto; overscroll-behavior: contain; padding: 4px 8px 8px; }
.vc-hp-g { padding: 10px 8px 4px; font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-head); text-transform: var(--label-case); color: var(--fnt); }
.vc-hp-row { display: grid !important; grid-template-columns: 28px minmax(0, 1fr) auto; align-items: center; gap: 10px; width: 100% !important;
  height: auto !important; min-height: 44px; padding: 6px 10px !important; border: 0 !important; border-radius: var(--r-item, 10px) !important;
  background: transparent !important; box-shadow: none !important; text-align: left; white-space: normal; color: var(--tx); font-size: 14px; cursor: pointer; }
.vc-hp-row:hover { background: color-mix(in srgb, var(--light) 5%, transparent) !important; }
.vc-hp-row.is-cur { background: color-mix(in srgb, var(--a) 12%, transparent) !important; box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--a) 30%, transparent) !important; }
.vc-hp-m { display: grid; place-items: center; font-size: 16px; color: var(--dim); }
.vc-hp-m .vc-ic { width: 16px; height: 16px; }
.vc-hp-t { min-width: 0; color: var(--dim); }
.vc-hp-t b { color: var(--bright); font-weight: 600; }
.vc-hp-t mark { background: transparent; color: var(--a); }
.vc-hp-t small { display: block; margin-top: 2px; font-size: 12px; color: var(--fnt); }
.vc-hp-par { color: var(--a); border-bottom: var(--hair-w) dashed color-mix(in srgb, var(--a) 50%, transparent); cursor: pointer; }
.vc-hp-r { display: flex; align-items: center; gap: 10px; font-size: 12px; color: var(--fnt); font-variant-numeric: tabular-nums; }
.vc-hp-tag { padding: 2px 8px; border-radius: var(--r-pill); border: var(--hair-w) solid var(--hair); font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); color: var(--dim); }
.vc-hp-none { margin: 14px 10px; font-size: 14px; color: var(--fnt); }
.vc-hp-f { display: flex; flex-wrap: wrap; gap: 6px 16px; padding: 10px 16px 12px; border-top: var(--hair-w) solid var(--hair); font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--fnt); }
.vc-hp-f kbd { display: inline-block; min-width: 1.6em; margin-right: 3px; padding: 0 4px; border-radius: 5px; border: var(--hair-w) solid var(--hair); font-family: var(--f-label); font-size: 11px; text-align: center; color: var(--dim); }
.vc-hp-esc { margin-left: auto; }
.vc-hp-acts { display: none; gap: 10px; padding: 0 16px 16px; }
.vc-hp-btn { flex: 1 1 0; height: auto !important; min-height: 44px; padding: 10px 14px !important; border-radius: var(--r-pill) !important;
  border: var(--hair-w) solid var(--hair) !important; background: transparent !important; box-shadow: none !important; font-size: 14px; color: var(--tx); cursor: pointer; }
.vc-hp-btn--go { background: var(--a) !important; border-color: var(--a) !important; color: var(--on-a); }
.vc-hp--sheet { place-items: end stretch; padding: 0; }
.vc-hp--sheet .vc-hp { width: 100%; max-height: 82vh; border-radius: var(--r-focal) var(--r-focal) 0 0; }
.vc-hp--sheet .vc-hp-f { display: none; }
.vc-hp--sheet .vc-hp-acts { display: flex; }

.vc-rd-veil { position: fixed; inset: 0; z-index: 2147483000; display: grid; place-items: center; padding: 24px;
  background: color-mix(in srgb, var(--ink, #000) 72%, transparent); -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
.vc-rd { position: relative; width: min(720px, 100%); max-height: calc(100vh - 48px); overflow-y: auto; display: grid; gap: 16px; padding: 28px 32px 22px; outline: 0;
  border-radius: var(--r-focal); color: var(--tx); font-family: var(--f-text);
  background: linear-gradient(165deg, color-mix(in srgb, var(--tint) 7%, var(--bg-2)), var(--bg-1));
  box-shadow: var(--sh-3), var(--lit, none), inset 0 0 0 var(--hair-w) var(--hair), 0 0 90px -30px color-mix(in srgb, var(--tint) 50%, transparent); }
.vc-rd-head { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; font-size: 12.5px; color: var(--fnt); }
.vc-rd-dots { display: inline-flex; gap: 4px; }
.vc-rd-dots i { width: 7px; height: 7px; border-radius: 50%; background: color-mix(in srgb, var(--light) 14%, transparent); }
.vc-rd-dots i.is-on { background: var(--a); }
.vc-rd-dots i.is-done { background: color-mix(in srgb, var(--a) 45%, transparent); }
.vc-rd-trail { margin-left: auto; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; }
.vc-rd-x, .vc-rd-b { height: 30px !important; min-height: 0 !important; padding: 0 12px !important; border: 0 !important; border-radius: var(--r-pill) !important;
  background: transparent !important; box-shadow: inset 0 0 0 var(--hair-w) var(--border) !important; font: 12.5px var(--f-text); color: var(--dim); cursor: pointer; }
.vc-rd-x { width: 30px !important; padding: 0 !important; box-shadow: none !important; }
.vc-rd-x:hover, .vc-rd-b:hover { color: var(--bright); background: color-mix(in srgb, var(--light) 6%, transparent) !important; }
.vc-rd-go { color: var(--bright); box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 55%, transparent) !important; }
.vc-rd-t, .vc-rd-finish h2 { margin: 0; font: italic 400 34px/1.15 var(--f-display); color: var(--bright); overflow-wrap: anywhere; }
.vc-rd-text { font-size: 16px; line-height: 1.7; color: var(--tx); max-width: 62ch; }
.vc-rd-text p { margin: 0 0 10px; }
.vc-rd-foot { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 10px; padding-top: 12px; border-top: var(--hair-w) solid var(--hair); font-size: 12px; color: var(--fnt); }
.vc-rd-nav { margin-left: auto; display: flex; flex-wrap: wrap; gap: 6px; }
.vc-rd-finish { display: grid; justify-items: center; gap: 10px; padding: 26px 0 10px; text-align: center; }
.vc-rd-finish h2 { font-size: 28px; }
.vc-rd-finish p { margin: 0; color: var(--dim); }

.vc-sib-f { width: 100% !important; height: 34px !important; padding: 0 12px !important; border: 0 !important; border-radius: var(--r-soft) !important; outline: 0;
  background: color-mix(in srgb, var(--bg-1) 80%, transparent) !important; box-shadow: inset 0 0 0 var(--hair-w) var(--border) !important; color: var(--bright); font: 14px var(--f-text); }
.vc-sib-list { display: grid; }
.vc-sib-list .vc-pop-row small { margin-left: auto; font-size: 12px; color: var(--fnt); white-space: nowrap; }
.vc-sib-list .vc-pop-row.is-here .vc-sib-n { color: var(--bright); font-weight: 600; }
.vc-keys { display: grid; grid-template-columns: auto 1fr; gap: 6px 14px; padding: 6px 4px; font-size: 13px; color: var(--dim); }
.vc-keys kbd { justify-self: start; font: 12px var(--f-text); color: var(--tx); padding: 1px 7px; border-radius: 5px; box-shadow: inset 0 0 0 var(--hair-w) var(--border); }

.vc-tm { display: grid; }
.vc-tm .vc-pop-row .vc-ic { width: 15px; height: 15px; color: var(--fnt); flex: none; }
.vc-tm-rest { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; padding: 10px 6px 11px; border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 9%, transparent); font-size: 13px; color: var(--dim); }
.vc-tm-rest > span { flex: 1 0 100%; }
.vc-tm-b { height: 28px !important; min-height: 0 !important; padding: 0 11px !important; border: 0 !important; border-radius: var(--r-pill) !important; background: transparent !important;
  box-shadow: inset 0 0 0 var(--hair-w) var(--border) !important; font: 12.5px var(--f-text); color: var(--dim); cursor: pointer; }
.vc-tm-b:hover { color: var(--bright); background: color-mix(in srgb, var(--light) 6%, transparent) !important; }
.vc-tm-day { height: 28px !important; padding: 0 8px !important; border: 0 !important; border-radius: var(--r-pill) !important; background: transparent !important;
  box-shadow: inset 0 0 0 var(--hair-w) var(--border) !important; font: 12.5px var(--f-text); color: var(--dim); color-scheme: dark; }
.vc-tm-ask { display: grid; gap: 6px; font-size: 13px; color: var(--dim); }
.vc-tm-hint { margin: 0; font-size: 12px; color: var(--fnt); }

.vc-src { display: grid; gap: 6px; min-width: 300px; }
.vc-src-list { display: grid; max-height: 320px; overflow: auto; }
.vc-src-list .vc-pop-row { justify-content: space-between; gap: 12px; }
.vc-src-list .vc-pop-row small { font-size: 12px; color: var(--fnt); }
.vc-src-none { margin: 6px; font-size: 13px; color: var(--dim); }

.vc-sp-veil { position: fixed; inset: 0; z-index: 2147483000; display: grid; place-items: center; padding: 24px; outline: 0;
  background: color-mix(in srgb, var(--ink, #000) 55%, transparent); }
.vc-sp { width: min(980px, 100%); height: min(820px, calc(100vh - 48px)); display: flex; flex-direction: column; overflow: hidden;
  border-radius: var(--r-focal); background: var(--bg-2); box-shadow: var(--sh-3), var(--lit, none);
  border: var(--hair-w) solid color-mix(in srgb, var(--a) 18%, transparent); color: var(--tx); font-family: var(--f-text); }
.vc-sp-h { display: flex; align-items: baseline; flex-wrap: wrap; gap: 6px 14px; padding: 18px 22px 12px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-sp-h h3 { margin: 0; font-family: var(--f-display, var(--f-text)); font-size: 22px; font-weight: 600; color: var(--bright); }
.vc-sp-h span { font-size: 13px; color: var(--fnt); }
.vc-sp-body { flex: 1 1 auto; min-height: 0; display: grid; overflow: hidden; grid-template-columns: minmax(240px, 300px) minmax(0, 1fr); }
.vc-sp-body > * { min-height: 0; }
.vc-sp-groups { overflow-y: auto; padding: 12px; border-right: var(--hair-w) solid var(--hair); display: grid; align-content: start; gap: 4px; }
.vc-sp-sub { padding: 10px 8px 6px; font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-head); text-transform: var(--label-case); color: var(--fnt); }
.vc-sp-g { display: grid; grid-template-columns: 30px minmax(0, 1fr); align-items: start; border-radius: var(--r-item, 10px); }
.vc-sp-g.is-at { background: color-mix(in srgb, var(--a) 10%, transparent); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--a) 28%, transparent); }
.vc-sp-gt, .vc-sp-gb, .vc-sp-own, .vc-sp-pk, .vc-sp-from button { height: auto !important; padding: 0 !important; border: 0 !important; background: transparent !important;
  box-shadow: none !important; text-align: left; white-space: normal; font: inherit; color: inherit; cursor: pointer; }
.vc-sp-gt { display: grid !important; place-items: center; padding: 12px 0 0 8px !important; }
.vc-sp-gb { display: grid !important; grid-template-columns: minmax(0, 1fr) auto; gap: 2px 8px; padding: 10px 10px 10px 4px !important; }
.vc-sp-gn { font-size: 14px; font-weight: 600; color: var(--bright); }
.vc-sp-gc { font-size: 12px; color: var(--dim); font-variant-numeric: tabular-nums; }
.vc-sp-gr { grid-column: 1 / -1; font-size: 12px; color: var(--fnt); }
.vc-sp-g:not(.is-on) .vc-sp-gn { color: var(--fnt); text-decoration: line-through; }
.vc-sp-tick { display: inline-grid; place-items: center; width: 18px; height: 18px; flex: none; border-radius: 5px; box-shadow: inset 0 0 0 var(--hair-w) var(--border); color: var(--on-a, var(--bright)); }
.vc-sp-tick.is-on { background: var(--a); box-shadow: none; }
.vc-sp-tick .vc-ic { width: 12px; height: 12px; }
.vc-sp-own { display: grid !important; grid-template-columns: 30px minmax(0, 1fr); gap: 2px 0; align-items: center; margin-top: 6px; padding: 10px 8px !important; border-radius: var(--r-item, 10px) !important; color: var(--dim); }
.vc-sp-own .vc-ic { width: 15px; height: 15px; }
.vc-sp-own small { grid-column: 2; font-size: 12px; color: var(--fnt); }
.vc-sp-own:hover { background: color-mix(in srgb, var(--light) 5%, transparent) !important; }
.vc-sp-pane { min-width: 0; display: flex; flex-direction: column; padding: 14px 18px 0; }
.vc-sp-name { display: flex; align-items: center; gap: 12px; padding-bottom: 10px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-sp-name span { font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); text-transform: var(--label-case); color: var(--fnt); }
.vc-sp-name input { flex: 1 1 auto; min-width: 0; height: auto !important; padding: 4px 0 !important; border: 0 !important; background: transparent !important; box-shadow: none !important;
  outline: 0; font-family: var(--f-display, var(--f-text)); font-size: 20px; color: var(--bright); }
.vc-sp-from { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 12px; }
.vc-sp-from button { display: grid !important; gap: 3px; padding: 10px 12px !important; border-radius: var(--r-item, 10px) !important;
  box-shadow: inset 0 0 0 var(--hair-w) var(--hair) !important; font-size: 13px; color: var(--dim); }
.vc-sp-from button[aria-pressed="true"] { color: var(--bright); box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--a) 55%, transparent) !important; background: color-mix(in srgb, var(--a) 8%, transparent) !important; }
.vc-sp-from small { font-size: 12px; color: var(--fnt); }
.vc-sp-scroll { flex: 1 1 auto; min-height: 0; overflow-y: auto; overscroll-behavior: contain; padding: 4px 0 14px; }
.vc-sp-picks { list-style: none; margin: 0; padding: 0; }
.vc-sp-pk { display: grid !important; grid-template-columns: 26px minmax(0, 1fr) auto; gap: 2px 8px; align-items: center; width: 100% !important; padding: 8px 6px !important; border-radius: var(--r-item, 10px) !important; }
.vc-sp-pk:hover { background: color-mix(in srgb, var(--light) 4%, transparent) !important; }
.vc-sp-pt { font-size: 14px; color: var(--bright); }
.vc-sp-else { font-size: 12px; color: var(--a); }
.vc-sp-pw { grid-column: 2 / -1; font-size: 12px; color: var(--fnt); }
.vc-sp-none { padding: 8px 6px; font-size: 13px; color: var(--fnt); }
.vc-sp-foot { display: flex; align-items: center; flex-wrap: wrap; gap: 12px 20px; padding: 14px 22px; border-top: var(--hair-w) solid var(--hair); }
.vc-sp-after { flex: 1 1 auto; font-size: 14px; color: var(--dim); }
.vc-sp-after b { color: var(--bright); font-weight: 600; }
.vc-sp-btns { display: flex; gap: 10px; }
.vc-sp-btn { height: auto !important; min-height: 40px; padding: 8px 20px !important; border-radius: var(--r-pill) !important;
  border: var(--hair-w) solid var(--hair) !important; background: transparent !important; box-shadow: none !important; font-size: 14px; color: var(--tx); cursor: pointer; }
.vc-sp-btn--go { background: var(--a) !important; border-color: var(--a) !important; color: var(--on-a); }
.vc-sp-btn:disabled { opacity: .45; cursor: default; }
.vc-sp--narrow { padding: 0; }
.vc-sp--narrow .vc-sp { width: 100%; height: 100%; border-radius: 0; }
.vc-sp--narrow .vc-sp-body { grid-template-columns: minmax(0, 1fr); grid-template-rows: auto minmax(0, 1fr); }
.vc-sp--narrow .vc-sp-groups { display: flex; overflow-x: auto; border-right: 0; border-bottom: var(--hair-w) solid var(--hair); }
.vc-sp--narrow .vc-sp-groups .vc-sp-sub, .vc-sp--narrow .vc-sp-gr, .vc-sp--narrow .vc-sp-own small { display: none; }
.vc-sp--narrow .vc-sp-g, .vc-sp--narrow .vc-sp-own { flex: none; }
.vc-sp--narrow .vc-sp-from { grid-template-columns: 1fr; }

.vc-bnpop-pics { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
.vc-bnpop-pics:empty { display: none; }
.vc-bnpop-pic { display: block !important; width: 100%; height: 64px !important; min-height: 0; padding: 0 !important; border: 0 !important; border-radius: var(--r-item) !important; cursor: pointer;
  background-color: var(--bg-1) !important; background-size: cover !important; background-position: center !important; box-shadow: inset 0 0 0 var(--hair-w) var(--hair) !important; }
.vc-bnpop-pic:hover { box-shadow: inset 0 0 0 var(--hair-w) var(--border), var(--sh-1) !important; }
.vc-bnpop-pic.is-on { box-shadow: inset 0 0 0 2px var(--a) !important; }
.vc-bnpop-pic:focus-visible { outline: 2px solid var(--a); outline-offset: 2px; }
.vc-bnpop-tone { display: grid; grid-template-columns: auto minmax(0, 1fr) 4ch; align-items: center; gap: 12px; font-size: 13px; color: var(--dim); }
.vc-bnpop-tone input { width: 100%; accent-color: var(--a); }
.vc-bnpop-tone output { font-variant-numeric: tabular-nums; text-align: right; color: var(--bright); }
.vc-bnpop-acts { display: flex; flex-wrap: wrap; gap: 8px; }

.vc-mu { display: grid; grid-template-columns: auto auto minmax(80px, 1fr) 4.4em; grid-template-areas: "play mute vol n"; align-items: center; gap: 12px; margin-top: 14px; }
.vc-mu .vc-mu-play { grid-area: play; display: grid !important; place-items: center; width: 48px !important; height: 48px !important; min-width: 0 !important; margin: 0 !important; padding: 0 !important;
  border: 0 !important; border-radius: 50% !important; background: transparent !important; box-shadow: none !important; cursor: pointer; }
.vc-mu-pb { display: grid; place-items: center; width: 46px; height: 46px; border-radius: 50%; color: var(--on-a);
  background: radial-gradient(circle at 34% 26%, var(--a-hi), var(--a) 72%);
  box-shadow: inset 0 1px 0 color-mix(in srgb, var(--a-hi) 80%, #fff), inset 0 -2px 4px color-mix(in srgb, var(--a) 60%, #000), 0 8px 18px -8px color-mix(in srgb, var(--a) 70%, #000);
  transition: transform var(--t), box-shadow var(--t), filter var(--t); }
.vc-mu .vc-mu-play:hover .vc-mu-pb { filter: brightness(1.07); transform: scale(1.04); }
.vc-mu .vc-mu-play:active .vc-mu-pb { transform: scale(.95); }
.vc-mu .vc-mu-play.is-on .vc-mu-pb { box-shadow: inset 0 1px 0 color-mix(in srgb, var(--a-hi) 80%, #fff), inset 0 -2px 4px color-mix(in srgb, var(--a) 60%, #000), 0 0 0 5px color-mix(in srgb, var(--a) 16%, transparent), 0 8px 22px -6px color-mix(in srgb, var(--a) 70%, #000); }
.vc-mu .vc-mu-play:focus-visible { outline: none !important; }
.vc-mu .vc-mu-play:focus-visible .vc-mu-pb { outline: 2px solid var(--a); outline-offset: 3px; }
.vc-mu .vc-mu-play[disabled] { cursor: default; }
.vc-mu .vc-mu-play[disabled] .vc-mu-pb { background: var(--tile); color: var(--fnt); box-shadow: inset 0 0 0 var(--hair-w) var(--hair); filter: none; transform: none; }
.vc-mu-pb .vc-ic { width: 18px; height: 18px; margin: 0; vertical-align: 0; }
.vc-mu-play:not(.is-on) .vc-mu-pb .vc-ic { transform: translateX(1px); }
.vc-mu-mute { grid-area: mute; }
.vc-mu .vc-mu-vol { grid-area: vol; -webkit-appearance: none !important; appearance: none !important; width: 100% !important; min-width: 80px !important; max-width: none !important; height: 24px !important;
  margin: 0 !important; padding: 0 !important; border: 0 !important; border-radius: var(--r-pill) !important; background: transparent !important; box-shadow: none !important; cursor: pointer; }
.vc-mu .vc-mu-vol::-webkit-slider-runnable-track { height: 6px; border: 0; border-radius: var(--r-pill);
  background: linear-gradient(90deg, color-mix(in srgb, var(--a) 55%, transparent) 0, var(--a) var(--v, 0%), color-mix(in srgb, var(--tx) 14%, transparent) var(--v, 0%), color-mix(in srgb, var(--tx) 14%, transparent) 100%); }
.vc-mu .vc-mu-vol::-webkit-slider-thumb { -webkit-appearance: none !important; position: static !important; top: auto !important; width: 18px !important; height: 18px !important; margin-top: -6px !important;
  border: 3px solid var(--bg-2) !important; border-radius: 50% !important; background: var(--a-hi) !important; cursor: grab;
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--a) 60%, transparent), 0 2px 6px rgba(0, 0, 0, .5) !important; transition: transform var(--t); }
.vc-mu .vc-mu-vol:hover::-webkit-slider-thumb, .vc-mu .vc-mu-vol:active::-webkit-slider-thumb { transform: scale(1.12); }
.vc-mu .vc-mu-vol:focus-visible { outline: 2px solid color-mix(in srgb, var(--a) 60%, transparent) !important; outline-offset: 3px; }
.vc-mu.is-muted .vc-mu-vol { opacity: .45; }
.vc-mu-n { grid-area: n; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); text-align: right; color: var(--dim); font-variant-numeric: tabular-nums; }
.vc-mu-fade { position: relative; display: inline-flex; align-items: center; gap: 10px; font-size: 13px; color: var(--dim); cursor: pointer; }
.vc-mu-fade input { position: absolute; opacity: 0; width: 1px; height: 1px; margin: 0; pointer-events: none; }
.vc-mu-sw { position: relative; flex: none; width: 34px; height: 20px; border-radius: var(--r-pill); background: var(--tile); box-shadow: inset 0 0 0 var(--hair-w) var(--border); transition: background var(--t); }
.vc-mu-sw::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 50%; background: var(--dim); transition: transform var(--t), background var(--t); }
.vc-mu-fade input:checked + .vc-mu-sw { background: var(--a); box-shadow: none; }
.vc-mu-fade input:checked + .vc-mu-sw::after { transform: translateX(14px); background: var(--on-a); }
.vc-mu-fade input:focus-visible + .vc-mu-sw { outline: 2px solid var(--a); outline-offset: 2px; }
.vc-mupop { width: 360px; isolation: isolate; }
.vc-mupop-bg { position: absolute; inset: 0; z-index: -1; overflow: hidden; border-radius: inherit; pointer-events: none; }
.vc-mupop-bg > i { position: absolute; inset: -50px; background: center / cover no-repeat; filter: blur(40px) saturate(1.4); opacity: 0; transition: opacity .4s; }
.vc-mupop-bg > i.has-pic { opacity: .85; }
.vc-mupop-bg > i.is-yt { background-size: auto 134%; }
.vc-mupop-bg::after { content: ""; position: absolute; inset: 0;
  background: linear-gradient(180deg, color-mix(in srgb, var(--bg-2, var(--bg)) 42%, transparent), color-mix(in srgb, var(--bg-2, var(--bg)) 72%, transparent) 70%); }
.vc-mupop .vc-mu { margin-top: 2px; }
.vc-mupop-h { display: flex; align-items: center; gap: 14px; min-width: 0; }
.vc-mu-disc { position: relative; flex: none; width: 56px; height: 56px; border-radius: 50%;
  background: repeating-radial-gradient(circle, color-mix(in srgb, var(--bg) 80%, #000) 0 2px, color-mix(in srgb, var(--bg-3) 70%, #000) 2px 3px); box-shadow: 0 8px 18px -8px #000, inset 0 0 0 1px rgba(255,255,255,.06); }
.vc-mu-disc::after { content: ""; position: absolute; inset: 34%; border-radius: 50%; background: radial-gradient(circle, var(--bg) 0 12%, var(--a) 13% 100%); }
.vc-mupop-t { display: grid; gap: 2px; min-width: 0; }
.vc-mupop-t small { font-size: 12px; color: var(--fnt); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-mupop-t b { font-family: var(--f-display); font-size: 18px; font-weight: 400; line-height: 1.2; color: var(--bright); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-mupop .vc-sheet-note { margin: 0; }
.vc-trpick { display: grid; gap: 2px; max-height: 260px; overflow-y: auto; overscroll-behavior: contain; padding: 4px; border-radius: var(--r-soft); background: var(--bg-1); box-shadow: inset 0 0 0 var(--hair-w) var(--hair); }
.vc-trpick-row { display: grid !important; grid-template-columns: 16px minmax(0, 1fr) auto; align-items: center; gap: 10px; width: 100%; height: auto !important; min-height: 0; padding: 7px 10px !important;
  border: 0 !important; border-radius: var(--r) !important; background: transparent !important; box-shadow: none !important; text-align: left; color: var(--dim); font-size: 13px; cursor: pointer; }
.vc-trpick-row:hover, .vc-trpick-row:focus-visible { background: var(--tile) !important; color: var(--bright); }
.vc-trpick-row.is-on { background: var(--af) !important; color: var(--bright); }
.vc-trpick-row .vc-ic { width: 15px; height: 15px; margin: 0; vertical-align: 0; color: var(--a); }
.vc-trpick-row span { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-trpick-row span b { font-weight: inherit; color: var(--a-hi); }
.vc-trpick-row small { max-width: 15em; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; color: var(--fnt); }

.vc-pop .vc-qtoday { display: grid; gap: 4px; padding: 12px 14px; border-radius: var(--r-item); background: radial-gradient(120% 120% at 0 0, color-mix(in srgb, var(--a) 12%, transparent), transparent 60%), var(--bg-1); box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 30%, transparent); }
.vc-pop .vc-qtoday small { display: inline-flex; align-items: center; gap: 6px; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--fnt); }
.vc-pop .vc-qtoday small:first-child { color: var(--a); }
.vc-pop .vc-qtoday small .vc-ic { width: 13px; height: 13px; margin: 0; }
.vc-pop .vc-qtoday .vc-q { font-family: var(--f-display); font-style: italic; font-size: 16px; line-height: 1.45; color: var(--bright); }
.vc-pop .vc-qmany { padding: 4px 0 10px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-pop .vc-qmany summary { display: inline-flex; align-items: center; gap: 8px; padding: 6px 2px; font-size: 13px; color: var(--dim); cursor: pointer; list-style: none; }
.vc-pop .vc-qmany summary::-webkit-details-marker { display: none; }
.vc-pop .vc-qmany summary .vc-ic { width: 15px; height: 15px; margin: 0; color: var(--a); }
.vc-pop .vc-qmany summary:hover { color: var(--bright); }
.vc-pop .vc-qmany[open] summary { color: var(--bright); }
.vc-pop .vc-qpaste { box-sizing: border-box; width: 100%; min-height: 92px; margin: 6px 0 8px; resize: vertical; text-align: start !important; font-size: 13px !important; line-height: 1.5 !important; }
.vc-pop .vc-qprev { list-style: none; display: grid; gap: 4px; margin: 0 0 10px; padding: 0; }
.vc-pop .vc-qprev:empty { display: none; }
.vc-pop .vc-qprev li { display: grid; grid-template-columns: 14px minmax(0, 1fr); align-items: baseline; gap: 2px 8px; margin: 0; font-size: 12.5px; color: var(--tx); }
.vc-pop .vc-qprev li .vc-ic { width: 13px; height: 13px; margin: 0; align-self: center; }
.vc-pop .vc-qprev li.is-ok .vc-ic { color: var(--a); }
.vc-pop .vc-qprev li.is-no { color: var(--fnt); }
.vc-pop .vc-qprev li.is-no .vc-ic { color: var(--warn, var(--fnt)); }
.vc-pop .vc-qprev li i { font-family: var(--f-display); }
.vc-pop .vc-qprev li small { grid-column: 2; font-size: 11px; color: var(--warn, var(--fnt)); }
.vc-pop .vc-qmany .vc-ib[disabled] { opacity: .45; cursor: default; }
.vc-pop .vc-qfind { display: flex; align-items: center; gap: 8px; margin-top: 6px; }
.vc-pop .vc-qfind .vc-ic { width: 15px; height: 15px; margin: 0; flex: none; color: var(--fnt); }
.vc-pop .vc-qfind .vc-sheet-field { flex: 1 1 auto; box-sizing: border-box; text-align: start !important; }
.vc-pop .vc-qline[hidden] { display: none; }
.vc-pop .vc-qnone { margin: 6px 0 0; }

.vc-pop .vc-ch { flex: 1 1 auto; display: flex; flex-direction: column; min-height: 0; }
.vc-pop .vc-ch-h { display: flex; align-items: flex-start; gap: 12px; padding: 20px 18px 6px 24px; }
.vc-pop .vc-ch-h > div { display: grid; gap: 3px; min-width: 0; }
.vc-pop .vc-ch-t { font-family: var(--f-display); font-size: 23px; font-weight: 400; line-height: 1.15; letter-spacing: -.01em; color: var(--bright); }
.vc-pop .vc-ch-h small { font-size: 12.5px; color: var(--fnt); }
.vc-pop .vc-ch-x { margin-left: auto; flex: none; }
.vc-pop .vc-ch-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 10px 12px; padding: 12px 24px 14px; border-bottom: var(--hair-w) solid var(--hair); }
.vc-pop .vc-ch-dir { display: inline-flex !important; align-items: center; gap: 8px; height: 34px !important; padding: 0 11px 0 12px !important; border: 0 !important; border-radius: var(--r-pill) !important; font-size: 13px;
  color: var(--tx); background: var(--tile) !important; box-shadow: inset 0 0 0 var(--hair-w) var(--hair) !important; cursor: pointer; transition: background var(--t), box-shadow var(--t); }
.vc-pop .vc-ch-dir:hover, .vc-pop .vc-ch-dir:focus-visible { background: var(--af) !important; box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 45%, transparent) !important; color: var(--bright); outline: none; }
.vc-pop .vc-ch-dir .vc-ic { width: 15px; height: 15px; margin: 0; color: var(--a); }
.vc-pop .vc-ch-dir .vc-ic:last-child { width: 13px; height: 13px; color: var(--fnt); }
.vc-pop .vc-ch-dir b { font-weight: 500; color: var(--bright); max-width: 22ch; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-pop .vc-ch-find { flex: 1 1 200px; display: flex; align-items: center; gap: 8px; height: 34px; padding: 0 12px; border-radius: var(--r-pill); background: var(--bg-1); box-shadow: inset 0 0 0 var(--hair-w) var(--hair); color: var(--fnt); }
.vc-pop .vc-ch-find:focus-within { box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 55%, transparent); }
.vc-pop .vc-ch-find .vc-ic { width: 15px; height: 15px; margin: 0; flex: none; }
.vc-pop .vc-ch-find input, .vc-pop .vc-ch-link input { flex: 1 1 auto; min-width: 0; height: auto !important; padding: 0 !important; border: 0 !important; background: transparent !important; box-shadow: none !important; outline: none !important; font-size: 13px; color: var(--tx); text-align: start !important; }
.vc-pop .vc-ch-body { position: relative; flex: 1 1 auto; min-height: 140px; overflow-y: auto; overscroll-behavior: contain; padding: 6px 24px 18px; scrollbar-width: thin; }
.vc-pop .vc-ch-g { display: flex; align-items: center; gap: 7px; margin: 16px 0 8px; font-size: 12.5px; color: var(--dim); }
.vc-pop .vc-ch-g .vc-ic { width: 14px; height: 14px; margin: 0; color: var(--fnt); }
.vc-pop .vc-ch-g span { font-size: 11.5px; color: var(--fnt); font-variant-numeric: tabular-nums; }
.vc-pop .vc-ch-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 14px 10px; margin-top: 12px; }
.vc-pop .vc-ch-g + .vc-ch-grid { margin-top: 0; }
.vc-pop .vc-ch-th { position: relative; display: grid !important; grid-template-columns: minmax(0, 1fr); grid-template-rows: auto auto; justify-content: stretch !important; align-items: start !important; gap: 6px; width: 100% !important; justify-self: stretch; height: auto !important; padding: 0 !important; border: 0 !important; border-radius: 0 !important;
  background: transparent !important; box-shadow: none !important; text-align: left; color: var(--dim); min-width: 0; cursor: pointer; white-space: normal; justify-items: stretch; align-content: start; }
.vc-pop .vc-ch-art { position: relative; display: grid; place-items: center; width: 100%; box-sizing: border-box; aspect-ratio: 16 / 10; border-radius: var(--r-soft); background: var(--bg-3) center / cover no-repeat; color: var(--fnt);
  box-shadow: inset 0 0 0 var(--hair-w) var(--hair); transition: box-shadow var(--t), transform var(--t); }
.vc-pop .vc-ch-body--bn .vc-ch-art { aspect-ratio: 3 / 1.3; }
.vc-pop .vc-ch-art .vc-ic { width: 20px; height: 20px; margin: 0; }
.vc-pop .vc-ch-cap { justify-self: start; max-width: 100%; padding: 0 2px; font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-pop .vc-ch-th:hover .vc-ch-art, .vc-pop .vc-ch-th:focus-visible .vc-ch-art { box-shadow: inset 0 0 0 var(--hair-w) var(--a), 0 0 0 3px color-mix(in srgb, var(--a) 24%, transparent); transform: translateY(-1px); }
.vc-pop .vc-ch-th:hover .vc-ch-cap, .vc-pop .vc-ch-th:focus-visible .vc-ch-cap { color: var(--bright); }
.vc-pop .vc-ch-th:focus-visible { outline: none; }
.vc-pop .vc-ch-th.is-on .vc-ch-art { box-shadow: inset 0 0 0 2px var(--a); }
.vc-pop .vc-ch-now { position: absolute; left: 8px; top: 8px; display: inline-flex; align-items: center; gap: 4px; height: 22px; padding: 0 8px 0 6px; border-radius: var(--r-pill); font-size: 11.5px; font-weight: 600;
  color: var(--on-a, var(--bg)); background: var(--a); }
.vc-pop .vc-ch-now .vc-ic { width: 12px; height: 12px; margin: 0; }
.vc-pop .vc-ch-none { margin: 26px 0; font-size: 13px; color: var(--fnt); }
.vc-pop .vc-ch-over { position: absolute; inset: 0; z-index: 3; display: grid; place-content: center; justify-items: center; gap: 8px; pointer-events: none; opacity: 0;
  color: var(--a-hi); background: color-mix(in srgb, var(--bg-2) 82%, transparent); box-shadow: inset 0 0 0 2px var(--a); transition: opacity .15s; }
.vc-pop .vc-ch-over b { font-family: var(--f-display); font-size: 17px; font-weight: 400; color: var(--bright); }
.vc-pop .vc-ch-body.is-over .vc-ch-over { opacity: 1; }
.vc-pop .vc-ch-foot { display: flex; flex-wrap: wrap; align-items: center; gap: 10px 14px; padding: 14px 24px 18px; border-top: var(--hair-w) solid var(--hair); background: var(--bg-1); }
.vc-pop .vc-ch-file { display: inline-flex; align-items: center; gap: 8px; height: 34px; padding: 0 14px 0 11px; border-radius: var(--r-pill); font-size: 13px; color: var(--tx); cursor: pointer;
  box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--tx) 18%, transparent); transition: background var(--t), color var(--t); }
.vc-pop .vc-ch-file:hover, .vc-pop .vc-ch-file:focus-visible { background: var(--tile); color: var(--bright); outline: none; box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 45%, transparent); }
.vc-pop .vc-ch-file .vc-ic { width: 15px; height: 15px; margin: 0; color: var(--a); }
.vc-pop .vc-ch-link { flex: 1 1 260px; display: flex; align-items: center; gap: 8px; height: 36px; margin: 0; padding: 0 3px 0 12px; border-radius: var(--r-pill); background: var(--bg-2); box-shadow: inset 0 0 0 var(--hair-w) var(--hair); color: var(--fnt); }
.vc-pop .vc-ch-link:focus-within { box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 55%, transparent); }
.vc-pop .vc-ch-link > .vc-ic { width: 15px; height: 15px; margin: 0; flex: none; }
.vc-pop .vc-ch-link .vc-ib[disabled] { opacity: .4; cursor: default; }
.vc-pop .vc-ch-dirs { display: grid; gap: 4px; padding-top: 10px; }
.vc-pop .vc-ch-dirrow { display: grid !important; grid-template-columns: 16px minmax(0, 1fr) auto auto 16px; justify-content: stretch !important; align-items: center; gap: 12px; width: 100% !important; height: auto !important; min-height: 50px; padding: 8px 12px !important;
  border: 0 !important; border-radius: var(--r-soft) !important; background: transparent !important; box-shadow: none !important; text-align: left; color: var(--dim); cursor: pointer; white-space: normal; transition: background var(--t), color var(--t); }
.vc-pop .vc-ch-dirrow:hover, .vc-pop .vc-ch-dirrow:focus-visible { background: var(--tile) !important; color: var(--bright); outline: none; }
.vc-pop .vc-ch-dirrow:focus-visible { box-shadow: inset 0 0 0 var(--hair-w) var(--a) !important; }
.vc-pop .vc-ch-dirrow.is-on { background: var(--af) !important; color: var(--bright); box-shadow: inset 2px 0 0 var(--a) !important; }
.vc-pop .vc-ch-dirrow > .vc-ic { width: 16px; height: 16px; margin: 0; color: var(--a); }
.vc-pop .vc-ch-dirw { display: grid; gap: 1px; min-width: 0; }
.vc-pop .vc-ch-dirw b { font-size: 14px; font-weight: 500; color: var(--bright); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-pop .vc-ch-dirw small { font-size: 11.5px; color: var(--fnt); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-pop .vc-ch-dirn { font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); color: var(--fnt); white-space: nowrap; font-variant-numeric: tabular-nums; }
.vc-pop .vc-ch-strip { display: flex; gap: 3px; }
.vc-pop .vc-ch-strip i { display: block; width: 44px; height: 28px; border-radius: 4px; background: var(--bg-3) center / cover no-repeat; box-shadow: inset 0 0 0 var(--hair-w) var(--hair); }
.vc-pop .vc-ch-dirnow .vc-ic { width: 15px; height: 15px; margin: 0; color: var(--a); }
.vc-pop .vc-pt { display: grid; gap: 12px; width: 280px; }
.vc-pop .vc-pt .vc-sheet-note { margin: 0; }
.vc-pop .vc-ptslide { display: flex; align-items: center; gap: 12px; }
.vc-pop .vc-ptslide .hd-slide-w, .vc-pop .vc-ptslide .hd-slide-v { flex: none; font-family: var(--f-label); font-size: 12px; letter-spacing: var(--trk-label); color: var(--dim); }
.vc-pop .vc-ptslide .hd-slide-v { min-width: 4ch; text-align: right; font-variant-numeric: tabular-nums; }
.vc-pop .vc-ptslide .hd-range { -webkit-appearance: none !important; appearance: none !important; flex: 1 1 auto; min-width: 80px; height: 22px !important; margin: 0 !important; padding: 0 !important;
  border: 0 !important; background: transparent !important; box-shadow: none !important; cursor: pointer; }
.vc-pop .vc-ptslide .hd-range::-webkit-slider-runnable-track { height: 4px; border-radius: var(--r-pill); background: linear-gradient(90deg, var(--a) var(--v, 0%), color-mix(in srgb, var(--tx) 16%, transparent) var(--v, 0%)); }
.vc-pop .vc-ptslide .hd-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--a); border: 2px solid var(--bg-2); box-shadow: var(--sh-1); }
.vc-pop .vc-ptslide .hd-range:focus-visible { outline: 2px solid color-mix(in srgb, var(--a) 60%, transparent) !important; outline-offset: 3px; }
.vc-pop .vc-ptacts { display: flex; flex-wrap: wrap; gap: 8px; }

.vc-pop .vc-mt-grid { grid-template-columns: repeat(auto-fill, minmax(136px, 1fr)); }
.vc-pop .vc-ch-th.vc-mt { grid-template-rows: auto auto auto; gap: 3px; }
.vc-pop .vc-ch-art.vc-mt-art { aspect-ratio: 1; overflow: hidden; margin-bottom: 4px; background: var(--bg-3) center / cover no-repeat; }
.vc-pop .vc-ch-art.vc-mt-art.is-yt { background-size: auto 134%; }
.vc-pop .vc-mt-rec { position: absolute; inset: 11%; border-radius: 50%;
  background: radial-gradient(circle, var(--bg) 0 3.5%, var(--a-hi) 4.5%, var(--a) 29%, rgba(0, 0, 0, .5) 30% 31.5%, transparent 32.5%),
    conic-gradient(from 30deg, transparent 0 4%, color-mix(in srgb, var(--a-hi) 18%, transparent) 9%, transparent 15% 50%, color-mix(in srgb, var(--tx) 12%, transparent) 57%, transparent 64%),
    radial-gradient(circle, color-mix(in srgb, var(--bg-3) 40%, #000) 0, color-mix(in srgb, var(--bg) 18%, #000) 70%);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--tx) 12%, transparent), inset 0 0 0 9px rgba(0, 0, 0, .25), inset 0 0 0 10px color-mix(in srgb, var(--tx) 6%, transparent), 0 10px 18px -8px rgba(0, 0, 0, .7); }
.vc-pop .vc-mt-art.has-pic .vc-mt-rec { display: none; }
.vc-pop .vc-mt-go { position: absolute; right: 8px; bottom: 8px; display: grid; place-items: center; width: 34px; height: 34px; border-radius: 50%; color: var(--on-a);
  background: radial-gradient(circle at 34% 26%, var(--a-hi), var(--a) 72%); box-shadow: 0 6px 14px -6px rgba(0, 0, 0, .8); opacity: 0; transform: translateY(4px); transition: opacity var(--t), transform var(--t); }
.vc-pop .vc-mt-go .vc-ic { width: 15px; height: 15px; margin: 0; }
.vc-pop .vc-mt:not(.is-live) .vc-mt-go .vc-ic { transform: translateX(1px); }
.vc-pop .vc-mt:hover .vc-mt-go, .vc-pop .vc-mt:focus-visible .vc-mt-go, .vc-pop .vc-mt.is-live .vc-mt-go { opacity: 1; transform: none; }
.vc-pop .vc-mt.is-live .vc-ch-art { box-shadow: inset 0 0 0 2px var(--a), 0 0 0 4px color-mix(in srgb, var(--a) 22%, transparent); }
.vc-pop .vc-ch-now.vc-mt-who { color: var(--bright); background: color-mix(in srgb, var(--bg) 72%, transparent); box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--tx) 18%, transparent); }
.vc-pop .vc-mt-by { justify-self: start; max-width: 100%; padding: 0 2px; font-size: 11.5px; color: var(--fnt); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vc-pop .vc-mch .vc-ch-bar { display: flex; gap: 10px; align-items: center; }
.vc-pop .vc-mch .vc-ch-find { flex: 1; }
.vc-pop .vc-mch-foot .vc-ch-link { flex: 1; }
.vc-mu-disc.has-pic { border-radius: var(--r-soft); background: var(--bg-3) center / cover no-repeat; box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--tx) 12%, transparent), 0 8px 16px -8px rgba(0, 0, 0, .7); }
.vc-mu-disc.has-pic::after { display: none; }
.vc-mu-disc.has-pic.is-yt { width: 84px; height: 47px; background-size: 100% auto; }
.vc-qs { display: flex; flex-wrap: wrap; gap: 8px; }
.vc-qs .vc-qs-b { position: relative; display: grid !important; width: 42px !important; height: 42px !important; min-width: 0 !important; margin: 0 !important; padding: 0 !important; border: 0 !important;
  border-radius: var(--r-soft) !important; overflow: hidden; background: var(--bg-3) !important; box-shadow: inset 0 0 0 var(--hair-w) var(--hair) !important; cursor: pointer; transition: transform var(--t); }
.vc-qs .vc-qs-b i { position: absolute; inset: 0; background: center / cover no-repeat; }
.vc-qs .vc-qs-b i.is-yt { background-size: auto 134%; }
.vc-qs .vc-qs-b i:not(.has-pic) { inset: 5px; border-radius: 50%; background: radial-gradient(circle, var(--bg) 0 6%, var(--a) 7% 30%, rgba(0, 0, 0, .5) 31% 33%, color-mix(in srgb, var(--bg) 18%, #000) 34%); }
.vc-qs .vc-qs-b:hover { transform: translateY(-1px); }
.vc-qs .vc-qs-b.is-on { box-shadow: inset 0 0 0 2px var(--a), 0 0 0 3px color-mix(in srgb, var(--a) 22%, transparent) !important; }
.vc-qs .vc-qs-b:focus-visible { outline: 2px solid var(--a); outline-offset: 2px; }

.vc-rooms .vc-rooms-grp { margin-left: auto; display: inline-flex; align-items: center; gap: 2px; border-radius: var(--r-pill); transition: background var(--t), box-shadow var(--t); }
.vc-rooms .vc-rooms-grp + .vc-rooms-grp, .vc-rooms .vc-rooms-grp ~ .vc-rooms-now { margin-left: 10px; }
.vc-rooms .vc-rooms-grp.is-open { padding-left: 4px; background: color-mix(in srgb, var(--tx) 5%, transparent); box-shadow: inset 0 0 0 var(--hair-w) var(--hair); }
.vc-rooms .vc-rooms-gin { display: inline-flex; align-items: center; gap: 2px; }
.vc-rooms .vc-rooms-gin[hidden] { display: none; }
.vc-rooms .vc-rooms-gp { color: var(--dim); }
.vc-rooms .vc-rooms-gp .vc-word { max-width: 14em; opacity: 1; margin-inline-start: .4em; }
.vc-rooms .vc-rooms-gp .vc-ic:last-child { width: 13px; height: 13px; margin-inline-start: .3em; opacity: .7; }
.vc-rooms .vc-rooms-gp.is-here { color: var(--a); }
.vc-rooms .vc-rooms-grp:not(.is-open) .vc-rooms-gp.is-here { background: color-mix(in srgb, var(--a) 12%, transparent) !important; }

.vc-keyget { display: inline-flex; align-items: center; gap: 5px; flex: none; font: 12.5px/1.2 var(--f-text); letter-spacing: 0; text-transform: none; color: var(--a); text-decoration: none; white-space: nowrap; }
.vc-keyget:hover { text-decoration: underline; text-underline-offset: 3px; }
.vc-keyget .vc-ic { width: 13px; height: 13px; }
.vc-pop .vc-keyget { margin-top: 8px; }
```
