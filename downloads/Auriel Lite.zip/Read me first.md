# Read me first

This folder is an Obsidian vault. Open Obsidian, choose **Open folder as vault**, and pick this folder. It stays in Obsidian's vault list after that. When Obsidian asks whether you trust the author of this vault, choose Trust author and enable plugins; in restricted mode nothing below is drawn.

The first page is the Hall. It is drawn by the Custom Views plugin: if you see a plain note instead, open Settings, Community plugins, Custom Views, and turn on **Allow JavaScript execution**, then reopen the note.

## The keys

`Alt+C` a task for today · `Alt+J` a thought · `Alt+I` an inbox line · `Alt+E` link the selected words · `Alt+W` something you want · `Alt+Z` the full menu · `Ctrl+Shift+D` today's note.

## What is inside

The plugins the vault needs are already in it, each with its licence: see [[99_Meta/Licences|Licences]]. The vault makes one network request on opening, for the Satoshi typeface from Fontshare; with no network it draws in Manrope, which travels inside the vault.

[[Vault Guide]] says how the vault is meant to be used.
