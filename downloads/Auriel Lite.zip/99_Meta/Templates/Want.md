<%*
const id = tp.date.now("YYYYMMDDHHmmss");
const selectedText = tp.file.selection();

const title = await tp.system.prompt("What is it?");
if (title === null || !title.trim()) {
  new Notice("Cancelled.");
  try { await app.vault.delete(tp.config.target_file); } catch (e) {}
  return;
}
await tp.file.move(`/01_Zettelkasten/Permanent/${title.trim()}`);
_%>---
id: <% id %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
type: want
status: want
tags:
  - permanent
  - want
---
# <% title.trim() %>

- price:: 
- where:: 
- link:: 
- why:: 

<% selectedText ? selectedText : "" %><% tp.file.cursor() %>
