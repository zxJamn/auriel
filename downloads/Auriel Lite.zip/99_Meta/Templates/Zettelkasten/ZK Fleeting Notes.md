<%* 
const id = tp.date.now("YYYYMMDDHHmm");
const title = await tp.system.prompt("Title (optional)");
const alias = await tp.system.prompt("Alias (optional)");
const selectedText = tp.file.selection();

    const mocLabels = [
        "🎨 Art", "🏢 Business", "💬 Communication", "🧠 EQ", "💰 Finance",
        "🩺 Health", "📜 History", "💻 Infrastructure", "🗣️ Languages", "📣 Marketing", "🧮 Maths", "🧘 Philosophy", "🌐 Physics", "⚡ Productivity",
        "💻 Programming", "🧠 Psychology", "✍️ Writing", "❌ None / Independent"
    ];
    const mocValues = [
        "Art", "Business", "Communication", "EQ", "Finance",
        "Health", "History", "Infrastructure", "Languages", "Marketing",
        "Maths", "Philosophy", "Physics", "Productivity",
        "Programming", "Psychology", "Writing", ""
    ];

const selectedMoc = await tp.system.suggester(mocLabels, mocValues, false, "Select Domain/MOC? (Esc to skip)");
let parentMocBreadcrumb = "";
let parentMocTag = "";

if (selectedMoc) {
    parentMocBreadcrumb = `> [[MOC - ${selectedMoc}|↑ Back to ${selectedMoc}]]`;
    parentMocTag = selectedMoc.toLowerCase();
}

let existingTags = Object.keys(app.metadataCache.getTags()).map(t => t.replace(/^#/, '')).sort();
let userTags = [];
if (parentMocTag) userTags.push(parentMocTag);

while (true) {
    let displayOptions = ["✅ Done adding tags", "➕ Type a new tag...", ...existingTags.map(t => userTags.includes(t) ? `✔️ ${t}` : t)];
    let valueOptions = ["DONE", "NEW", ...existingTags];
    let pick = await tp.system.suggester(displayOptions, valueOptions, false, "Search and select a tag (Esc to finish)");
    if (!pick || pick === "DONE") break;
    
    if (pick === "NEW") {
        let newTag = await tp.system.prompt("Type new tag (without #)");
        if (newTag && newTag.trim() !== "") userTags.push(newTag.trim().replace(/^#/, ''));
    } else {
        if (!userTags.includes(pick)) userTags.push(pick);
    }
}

const allFiles = app.vault.getMarkdownFiles().map(f => f.basename).sort();
const related = await tp.system.suggester(allFiles, allFiles, false, "Search for a related note (Esc to skip)");

let tagsArr = ["#fleeting"];
let breadcrumbs = [];
if (parentMocBreadcrumb) breadcrumbs.push(parentMocBreadcrumb);

const domains = ["Business", "Communication", "EQ", "Finance", "Health", "History", "Languages", "Marketing", "Maths", "Philosophy", "Physics", "Productivity", "Programming", "Psychology", "Writing"];
const lowerDomains = domains.map(d => d.toLowerCase());

userTags.forEach(t => {
    if (!tagsArr.includes(`#${t}`)) tagsArr.push(`#${t}`);
    let root = t.split("/")[0].toLowerCase();
    let idx = lowerDomains.indexOf(root);
    if (idx !== -1 && !parentMocBreadcrumb) {
        let properName = domains[idx];
        let bc = `> [[MOC - ${properName}|↑ Back to ${properName}]]`;
        if (!breadcrumbs.includes(bc)) breadcrumbs.push(bc);
    }
});

if (!related && breadcrumbs.length === 0 && userTags.length === 0) {
    tagsArr.push("#review/orphan");
}

const tagsStr = tagsArr.join(" ");
const name = title ? `${id} - ${title}` : id;
await tp.file.rename(name);
await tp.file.move(`/01_Zettelkasten/Fleeting/${name}`);

let aliasFrontmatter = alias ? `\naliases:\n  - ${alias}` : "";
let breadcrumbOutput = breadcrumbs.length > 0 ? breadcrumbs.join(" | ") + "\n\n" : "";
_%>
---
id: <% tp.date.now("YYYYMMDDHHmm") %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %><% aliasFrontmatter %>
type: fleeting
tags: <% tagsStr %>
---
<% breadcrumbOutput %><% title ? `# ${title}\n\n` : "" %>## Idea
<% selectedText ? selectedText : "" %>

## Links
<% related ? `- [[${related}]]` : "- [[ ]]" %>

---

> [!info]- 🧭 Fleeting Note Workflow Guide
> **The Purpose:**
> - Fleeting notes are for capturing unrefined thoughts, shower ideas, or passing concepts before you forget them. 
> - They do not need to be perfect or fully formed. 
>
> **The Processing:**
> - Review your fleeting notes regularly. If an idea has merit, rewrite it into a well-structured **Permanent Note**, and delete or archive this fleeting note.
> - If a note remains isolated with no links, it is marked with \`#review/orphan\` so you can clean it up later.