---
id: lamplit
kind: theme
version: "1.0"
date: 2026-11-06
type: vault-store-record
---

Lamplit 1.0 is installed. The Store keeps this note to know what it installed; deleting it makes the Store treat Lamplit as not installed.

```json
{
 "id": "lamplit",
 "kind": "theme",
 "name": "Lamplit",
 "version": "1.0",
 "date": "2026-11-06",
 "files": [
  {
   "path": "99_Meta/Themes/Lamplit.md",
   "mode": "owned"
  }
 ],
 "views": [],
 "includes": []
}
```
