---
tags:
  - homedashboard
---
# The Hall

*The Home view draws this page. What follows is what you see if it ever does not — a note that
answers nothing is worse than one that is missing, because only the missing one is visible.*

## Doors

- [[Vault Guide|❦ The Guide]] — how the vault works

## The maps

No maps yet. A map is a note in 02_MOCs that links what belongs together; the Hall's shelves list
them as you make them.

## Capture

| key | what it does |
| --- | --- |
| `Alt+C` | a task into today's note — it stays on that day |
| `Alt+J` | a thought into today's journal, with its time |
| `Alt+I` | anything throwaway into [[00_Inbox/Inbox|Inbox]] — clear it every week |
| `Alt+E` | select words, then link them to the note they mean — or to a new permanent note |
| `Alt+W` | something you want |
| `Ctrl+Shift+D` | today's note |
| `Alt+Z` | the full menu |

> [!info]- If this page is showing instead of the dashboard
> The Hall is drawn by the Custom Views plugin: its Home view is bound to the tag `homedashboard`,
> which this note carries. If you are reading this, check that Custom Views is turned on and that
> **Allow JavaScript execution** is on in its settings, then reopen the note.
