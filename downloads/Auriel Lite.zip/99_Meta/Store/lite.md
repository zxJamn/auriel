---
id: lite
kind: edition
version: "2.4"
date: 2026-11-06
type: vault-store-record
---

Auriel Lite 2.4 is installed. The Store keeps this note to know what it installed; deleting it makes the Store treat Auriel Lite as not installed.

```json
{
 "id": "lite",
 "kind": "edition",
 "name": "Auriel Lite",
 "version": "2.4",
 "date": "2026-11-06",
 "files": [
  {
   "path": "99_Meta/Modules/Vault-Module.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Modules/Vault-Store.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Vault Chrome.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Vault Fonts.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Packs/core.md",
   "mode": "owned"
  },
  {
   "path": ".obsidian/themes/Lamplit/theme.css",
   "mode": "owned"
  },
  {
   "path": ".obsidian/themes/Lamplit/manifest.json",
   "mode": "owned"
  },
  {
   "path": ".obsidian/plugins/vault-later/main.js",
   "mode": "owned"
  },
  {
   "path": ".obsidian/plugins/vault-later/manifest.json",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Daily Note.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Zettelkasten/ZK Fleeting Notes.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Zettelkasten/ZK Literature Note.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Zettelkasten/ZK Permanent Note.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Zettelkasten/ZK Permanent Stub.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Templates/Want.md",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Scripts/day-note.js",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Scripts/link.js",
   "mode": "owned"
  },
  {
   "path": "99_Meta/Licences.md",
   "mode": "owned"
  },
  {
   "path": "Home Dashboard.md",
   "mode": "seeded"
  },
  {
   "path": "Vault Guide.md",
   "mode": "seeded"
  },
  {
   "path": "Read me first.md",
   "mode": "seeded"
  },
  {
   "path": "99_Meta/Vault Settings.md",
   "mode": "seeded"
  },
  {
   "path": "99_Meta/Quotes.md",
   "mode": "seeded"
  },
  {
   "path": "00_Inbox/Inbox.md",
   "mode": "seeded"
  }
 ],
 "views": [
  "core-hall",
  "core-daily"
 ],
 "includes": [
  "lamplit"
 ]
}
```
