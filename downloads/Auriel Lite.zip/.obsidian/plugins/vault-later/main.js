const { Plugin, PluginSettingTab, Setting, Platform } = require("obsidian");

const AFTER = { soon: 2000, later: 8000 };
const WORDS = { start: "as Obsidian opens", soon: "soon after (2s)", later: "a while after (8s)" };
const TOOK = "vault-later:took";

module.exports = class Later extends Plugin {
  async onload() {
    this.data = Object.assign({ soon: [], later: [], phone: false }, await this.loadData());
    this.timers = [];
    this.addSettingTab(new LaterTab(this.app, this));
    if (Platform.isMobile && !this.data.phone) { await this.run("soon"); await this.run("later"); return; }
    this.app.workspace.onLayoutReady(() => {
      this.timers = ["soon", "later"].map(k => window.setTimeout(() => this.run(k), AFTER[k]));
    });
  }
  onunload() { this.timers.forEach(t => window.clearTimeout(t)); }

  when(id) {
    if (this.app.plugins.enabledPlugins.has(id)) return "start";
    return this.data.soon.includes(id) ? "soon" : this.data.later.includes(id) ? "later" : "";
  }
  took() { try { return JSON.parse(window.localStorage.getItem(TOOK) || "{}") || {}; } catch (e) { return {}; } }

  async run(kind) {
    const P = this.app.plugins, took = this.took(), said = [];
    for (const id of this.data[kind]) {
      if (P.enabledPlugins.has(id) || P.plugins[id] || !P.manifests[id]) continue;
      if (Platform.isMobile && P.manifests[id].isDesktopOnly) continue;
      const t0 = performance.now();
      try { await P.enablePlugin(id); } catch (e) { console.error("[Later] " + id, e); }
      took[id] = Math.round(performance.now() - t0);
      said.push(`${id} ${took[id]}ms`);
      await new Promise(r => window.setTimeout(r, 30));
    }
    try { window.localStorage.setItem(TOOK, JSON.stringify(took)); } catch (e) {}
    if (said.length) console.log(`[Later] ${WORDS[kind]}: ${said.join(", ")}`);
    this.redraw();
  }
  redraw() {
    this.app.workspace.getLeavesOfType("markdown").forEach(leaf => {
      const v = leaf.view;
      try { if (v && v.getMode && v.getMode() === "preview" && !v.containerEl.querySelector("[data-cv-id]")) v.previewMode.rerender(true); } catch (e) {}
    });
  }

  async move(id, to) {
    const P = this.app.plugins;
    this.data.soon = this.data.soon.filter(x => x !== id);
    this.data.later = this.data.later.filter(x => x !== id);
    if (to === "start") {
      if (P.plugins[id]) { P.enabledPlugins.add(id); await P.saveConfig(); }
      else await P.enablePluginAndSave(id);
    } else {
      this.data[to].push(id);
      if (P.enabledPlugins.has(id)) { P.enabledPlugins.delete(id); await P.saveConfig(); }
    }
    await this.saveData(this.data);
  }
};

class LaterTab extends PluginSettingTab {
  constructor(app, plugin) { super(app, plugin); this.plugin = plugin; }
  display() {
    const L = this.plugin, P = this.app.plugins, el = this.containerEl, took = L.took();
    el.empty();
    el.createEl("p", { text: "Obsidian reads and runs every plugin it starts with before it draws the first page. A plugin nothing needs as it opens can be loaded a moment after, and the first page comes sooner." });
    el.createEl("p", { cls: "setting-item-description", text: "Turning this plugin off leaves the plugins it loads off as well: put them back as Obsidian opens first." });
    new Setting(el).setName("On the phone too").setDesc("Off, the phone loads every plugin as Obsidian opens, since a phone's limit is its memory and loading them while the first page is drawn and the vault is indexed stacked the two.")
      .addToggle(t => t.setValue(!!L.data.phone).onChange(async v => { L.data.phone = v; await L.saveData(L.data); }));
    new Setting(el).setName("Every plugin as Obsidian opens").setDesc("as it was before this plugin")
      .addButton(b => b.setButtonText("put all back").onClick(async () => {
        for (const id of [...L.data.soon, ...L.data.later]) await L.move(id, "start");
        this.display();
      }));
    const ids = Object.keys(P.manifests).filter(id => id !== L.manifest.id && L.when(id))
      .sort((a, b) => P.manifests[a].name.localeCompare(P.manifests[b].name));
    for (const id of ids) {
      const now = L.when(id);
      new Setting(el).setName(P.manifests[id].name)
        .setDesc(now !== "start" && took[id] != null ? `took ${took[id]}ms to load at the last start` : "")
        .addDropdown(d => d.addOptions(WORDS).setValue(now).onChange(async v => { await L.move(id, v); this.display(); }));
    }
  }
}
