---
type: vault-settings
country: ""
currency: "£"
weather_query: ""
weather_label: ""
banner: ""
daily_note_folder: Daily
doors:
  - { glyph: "§", label: Daily Note, sub: the record, path: "@daily" }
  - { glyph: "❦", label: The Guide, sub: how the vault works, path: Vault Guide }
habits: []
countdowns: []
working: true
studying: false
work_schedule: []
study_schedule: []
training_schedule: []
fixed_costs: []
fin_anchor_amount: 0
fin_anchor_date: ""
fin_expected_income: 0
fin_expected_period: weekly
fin_payday_mode: weekly
fin_payday_weekday: 5
fin_payday_day: 28
fin_payday_dates: []
fin_savings_target: 0
fin_savings_by: ""
fin_ratio_needs: 70
fin_ratio_wants: 20
fin_ratio_save: 10
fin_cat_needs: [food, transport, health]
compass: []
dates: []
shutdown_hour: 21
envelopes: {}
paid: {}
deferred: {}
---
# Vault Settings

The Hall and the daily note read and write these. Edit them from the Hall's settings page; a value typed here by hand is kept too.
