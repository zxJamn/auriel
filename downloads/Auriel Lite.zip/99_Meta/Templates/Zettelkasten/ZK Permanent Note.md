<%*
const selectedText = tp.file.selection();

const title = await tp.system.prompt("Title");
if (title === null || !title.trim()) {
  new Notice("Note creation cancelled.");
  try { await app.vault.delete(tp.config.target_file); } catch (e) {}
  return;
}
const name = title.trim();

const id = tp.date.now("YYYYMMDDHHmmss");
await tp.file.move(`/01_Zettelkasten/Permanent/${id} - ${name}`);

const mod = await (async () => {
  for (const f of app.vault.getFiles().filter(f => /^Vault-Module\.md$/i.test(f.name))) {
    try {
      const raw = await app.vault.read(f), src = (raw.match(/`{3}(?:js|javascript)\s*\n([\s\S]*?)`{3}/) || [, raw])[1];
      const m = new Function(src + "\nreturn typeof VAULT_MODULE !== 'undefined' ? VAULT_MODULE : null;")();
      if (m && m.maps && typeof m.askHome === "function") return { M: m, note: raw };
    } catch (e) {}
  }
  return null;
})();
const me = tp.config.target_file;
if (!mod) new Notice(`${name} · no home yet: the core module was not found`);
else {
  const { M, note } = mod, I = M.maps.index(app, tp.date.now("YYYY-MM-DD"));
  const target = await M.askHome(app, { title: name, guesses: M.maps.guessForText(I, { title: name }) }, note);
  if (!target) new Notice(`${name} · no home yet, it waits in Unfiled`);
  else tp.hooks.on_all_templates_executed(async () => {
    try { const r = await M.maps.setHome(app, [me], target); new Notice(String(r.why || r.said).replace(/<[^>]+>/g, "")); }
    catch (e) { new Notice(`${name} · no home: ${(e && e.message) || e}`); }
  });
}
_%>---
id: <% id %>
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
type: permanent
tags:
  - permanent
---
# <% name %>

<% selectedText %><% tp.file.cursor() %>
