---
id: lamplit
kind: theme
version: "1.3"
date: 2026-11-23
type: vault-store-record
---

Lamplit 1.3 is installed. The Store keeps this note to know what it installed; deleting it makes the Store treat Lamplit as not installed.

```json
{
 "id": "lamplit",
 "kind": "theme",
 "name": "Lamplit",
 "version": "1.3",
 "date": "2026-11-23",
 "files": [
  {
   "path": "99_Meta/Themes/Lamplit.md",
   "mode": "owned"
  }
 ],
 "views": [],
 "includes": []
}
```
