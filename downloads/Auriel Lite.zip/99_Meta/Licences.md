---
type: licences
---
# Licences

The plugins inside this vault, each the work of its author, under its own licence. The licence text is beside each plugin's code in `.obsidian/plugins`.

| plugin | version | repo | licence |
| --- | --- | --- | --- |
| custom-views | 0.3.2 | https://github.com/anupchavan/obsidian-custom-views | MIT License |
| homepage | 4.4.2 | https://github.com/mirnovov/obsidian-homepage | Copyright (c) 2020-present Obsidian, novov |
| templater-obsidian | 2.20.4 | https://github.com/silentvoid13/Templater | GNU AFFERO GENERAL PUBLIC LICENSE |
| quickadd | 2.12.3 | https://github.com/chhoumann/quickadd | MIT License |
| obsidian-style-settings | 1.0.9 | https://github.com/obsidian-community/obsidian-style-settings | GNU GENERAL PUBLIC LICENSE |
| obsidian-icon-folder | 2.14.7 | https://github.com/florianwoelki/obsidian-iconize | MIT License |
