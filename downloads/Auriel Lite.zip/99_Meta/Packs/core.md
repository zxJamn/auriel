---
id: core
kind: edition
edition: lite
version: "2.4"
parts: [hall, shelves, ledger, settings, banner, day, journal, source, blocks, habits, utility-tab, focus, breathe]
---
