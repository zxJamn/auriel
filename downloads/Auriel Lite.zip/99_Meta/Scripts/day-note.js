const INBOX = "00_Inbox/Inbox.md";

async function loadDayNote(app) {
  const hits = app.vault.getFiles().filter(f => /^Vault-Module\.md$/i.test(f.name));
  for (const f of hits) {
    try {
      const raw = await app.vault.read(f);
      const fenced = raw.match(/```(?:js|javascript)\s*\n([\s\S]*?)```/);
      const src = fenced ? fenced[1] : raw;
      if (!/VAULT_MODULE/.test(src)) continue;
      const M = new Function(src + "\nreturn typeof VAULT_MODULE !== 'undefined' ? VAULT_MODULE : null;")();
      if (M && M.dayNote && typeof M.dayNote.addTask === "function" && typeof M.dayNote.addJournal === "function") {
        try { if (M.loadPacks) await M.loadPacks(app); } catch (e) { console.error("[day-note] the packs", e); }
        return M;
      }
    } catch (e) { console.error("[day-note] the core module at " + f.path, e); }
  }
  return null;
}

function today(app) {
  const o = (app.internalPlugins && app.internalPlugins.getPluginById && app.internalPlugins.getPluginById("daily-notes")?.instance?.options) || {};
  const folder = String(o.folder || "").replace(/^\/+|\/+$/g, "");
  const name = window.moment().format(o.format || "YYYY-MM-DD");
  return {
    folder, name,
    path: (folder ? folder + "/" : "") + name + ".md",
    template: o.template ? String(o.template).replace(/\.md$/, "") + ".md" : "",
  };
}

async function beginToday(app, d) {
  const tp = app.plugins?.plugins?.["templater-obsidian"]?.templater;
  const tpl = d.template && app.vault.getAbstractFileByPath(d.template);
  const dir = d.folder ? app.vault.getAbstractFileByPath(d.folder) : app.vault.getRoot();
  if (!tp || !tpl || !dir) return null;
  try { await tp.create_new_note_from_template(tpl, dir, d.name, false); }
  catch (e) { console.error("[day-note] begin today's note", e); return null; }
  return app.vault.getAbstractFileByPath(d.path);
}

async function toInbox(app, line) {
  let f = app.vault.getAbstractFileByPath(INBOX);
  if (!f) f = await app.vault.create(INBOX, "# Inbox\n\n");
  await app.vault.process(f, data => data + (data.endsWith("\n") || !data ? "" : "\n") + line + "\n");
}

async function write(params, kind) {
  const { app, quickAddApi, variables } = params;
  const Notice = (params.obsidian && params.obsidian.Notice) || globalThis.Notice || function (m) { console.log(m); };
  const thought = kind === "thought";
  const asked = variables && (thought ? variables.thought : variables.task);
  const text = String(asked || await quickAddApi.inputPrompt(thought ? "A thought for today" : "A task for today") || "").replace(/\s+/g, " ").trim();
  if (!text) return;

  const hhmm = window.moment().format("HH:mm");
  const M = await loadDayNote(app), dayNote = M ? M.dayNote : null;
  const d = today(app);
  if (/^\/\w/.test(text)) {
    const plain = s => String(s || "").replace(/<[^>]+>/g, "");
    if (!M || !M.commands) { new Notice("the command line is the core module's, and no Vault-Module note was found"); return; }
    const r = await M.commands.run(app, text, { today: window.moment().format("YYYY-MM-DD") });
    new Notice(r.why ? plain(r.why) : `✓ ${plain(r.said)}`);
    return;
  }
  const file = app.vault.getAbstractFileByPath(d.path) || (dayNote ? await beginToday(app, d) : null);
  if (!dayNote || !file) {
    await toInbox(app, thought ? `- ${hhmm} ${text}` : `- [ ] ${hhmm} ${text}`);
    new Notice(`${!dayNote ? "no Vault-Module note to write with" : "no note for today, and no daily template to begin one"} — "${text}" is in the inbox`);
    return;
  }
  const due = window.moment().format("YYYY-MM-DD");
  await app.vault.process(file, data => {
    const lines = data.split("\n");
    if (thought) dayNote.addJournal(lines, text, hhmm);
    else dayNote.addTask(lines, `${text} #task 📅 ${due}`);
    return lines.join("\n");
  });
  new Notice(thought ? `✓ ${text} — today's journal` : `✓ ${text} — today's note`);
}

module.exports = {
  entry: (params, settings) => write(params, (settings && settings["Write as"]) === "thought" ? "thought" : "task"),
  settings: {
    name: "Day note",
    author: "the vault",
    options: { "Write as": { type: "dropdown", defaultValue: "task", options: ["task", "thought"] } },
  },
  today,
};
