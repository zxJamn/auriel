---
type: vault-module
---

# Vault-Store

The Store: the Hall's page that shows what this vault has and what its keys cover, and installs,
updates and removes add-ons and themes. The first block holds the keys' check, the installer and the
page, in that order; the second is the page's stylesheet. It is loaded the first time the page opens.

**Do not edit these blocks by hand.** They are read by this note's name and replaced whole whenever
the vault's code is updated, so anything typed here is lost.

```js
const VAULT_KEYS = (() => {
  const FORMAT = "NEU1";
  const enc = new TextEncoder(), dec = new TextDecoder();

  const toB64u = bytes => { let s = ""; for (const b of bytes) s += String.fromCharCode(b); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); };
  function fromB64u(s) {
    if (!/^[A-Za-z0-9_-]*$/.test(s)) throw new Error("not base64url");
    const t = s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4);
    const bin = atob(t), out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  const encode = payload => toB64u(enc.encode(JSON.stringify(payload)));

  function read(text) {
    if (typeof text !== "string") return { ok: false, why: "is not an Auriel key" };
    const t = text.replace(/\s+/g, "");
    if (!t.startsWith(FORMAT + ".")) return { ok: false, why: "is not an Auriel key" };
    const parts = t.split(".");
    if (parts.length !== 3 || !parts[1] || !parts[2]) return { ok: false, why: "is cut short: a key has three parts" };
    try {
      const payload = JSON.parse(dec.decode(fromB64u(parts[1])));
      if (!payload || typeof payload !== "object" || !Array.isArray(payload.i) || !payload.k) return { ok: false, why: "cannot be read" };
      return { ok: true, payload, body: parts[1], sig: parts[2] };
    } catch (e) { return { ok: false, why: "cannot be read" }; }
  }

  async function verify(text, publicJwk, subtle = globalThis.crypto && globalThis.crypto.subtle) {
    const r = read(text);
    if (!r.ok || !publicJwk || !subtle) return false;
    try {
      const pub = await subtle.importKey("jwk", publicJwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      return await subtle.verify({ name: "ECDSA", hash: "SHA-256" }, pub, fromB64u(r.sig), enc.encode(r.body));
    } catch (e) { return false; }
  }

  const ISO = /^\d{4}-\d{2}-\d{2}$/;
  function covers(payload, item) {
    if (!payload || !item) return false;
    const names = payload.i || [];
    const named = names.includes(item.id) || names.includes("*") || (item.kind === "theme" && names.includes("*theme")) || (item.kind === "addon" && names.includes("*addon"));
    if (!named) return false;
    if (payload.a && item.kind === "addon" && !(ISO.test(String(item.date || "")) && String(item.date) <= String(payload.a))) return false;
    if (!payload.u) return true;
    return ISO.test(String(item.date || "")) && String(item.date) <= String(payload.u);
  }
  function names(payload, items) {
    const byId = new Map((items || []).map(it => [it.id, it]));
    const out = new Set(), made = payload && ISO.test(String(payload.d || "")) ? String(payload.d) : "";
    const add = (id, by) => {
      const it = byId.get(id);
      if (by && it && it.kind !== "bundle" && String(it.first || it.date || "") > by) return;
      if (out.has(id)) return;
      out.add(id);
      if (!it) return;
      if (it.kind !== "bundle") return (it.includes || []).forEach(x => add(x, ""));
      const cut = it.asBought && made && (!by || made < by) ? made : by;
      (it.items || []).forEach(x => add(x, cut));
    };
    ((payload && payload.i) || []).forEach(x => add(x, ""));
    return { ...payload, i: [...out] };
  }
  const coveredIds = (payloads, items) => {
    const named = payloads.map(p => names(p, items));
    return items.filter(it => it.kind !== "bundle" && named.some(p => covers(p, it))).map(it => it.id);
  };

  const SHOP_SHAPE = /^[A-Za-z0-9][A-Za-z0-9_-]{7,99}$/;
  function accepts(text) {
    const t = String(text == null ? "" : text).trim();
    if (!t.startsWith(FORMAT + ".") && SHOP_SHAPE.test(t)) return { ok: true, shop: true };
    return read(t);
  }

  return { FORMAT, read, accepts, verify, covers, coveredIds, names, encode };
})();

const VAULT_INSTALL = (() => {
  const RECORDS = "99_Meta/Store";
  const FENCE = "`".repeat(3);
  const BACKUPS = ".neurora/backups";
  const HIDDEN_OK = [/^\.obsidian\/themes\/Lamplit\/[^/]+$/, /^\.obsidian\/plugins\/vault-later\/(?:main\.js|manifest\.json)$/];

  const pathWhy = p => {
    if (typeof p !== "string" || !p) return "it is no path";
    if (p.includes("\\")) return "it holds a backslash";
    if (/^[A-Za-z]:/.test(p)) return "it names a drive";
    if (p.startsWith("/")) return "it starts at the root";
    if (p.split("/").some(s => s === "" || s === "." || s === "..")) return "it steps outside the vault";
    if (p === RECORDS || p.startsWith(RECORDS + "/")) return "the Store's records are the Store's";
    if (p.split("/").some(s => s.startsWith(".")) && !HIDDEN_OK.some(r => r.test(p))) return "it is a hidden file the Store does not write";
    return null;
  };

  const nums = v => String(v).replace(/^[\^~=v ]+/, "").split(".").map(n => parseInt(n, 10) || 0);
  function meets(range, version) {
    const want = nums(range), have = nums(version);
    if (have[0] !== want[0]) return false;
    for (let i = 1; i < Math.max(want.length, have.length); i++) { if ((have[i] || 0) !== (want[i] || 0)) return (have[i] || 0) > (want[i] || 0); }
    return true;
  }

  const two = n => String(n).padStart(2, "0");
  const stamp = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())} ${two(d.getHours())}-${two(d.getMinutes())}-${two(d.getSeconds())}`;
  const recordPath = id => `${RECORDS}/${id}.md`;
  const nameOf = pkg => pkg.name || pkg.id;

  function recordText(pkg) {
    const body = { id: pkg.id, kind: pkg.kind, name: nameOf(pkg), version: pkg.version, date: pkg.date || "",
      files: (pkg.files || []).map(f => ({ path: f.path, mode: f.mode })), views: (pkg.views || []).map(v => v.id), includes: (pkg.includes || []).slice() };
    return `---\nid: ${pkg.id}\nkind: ${pkg.kind}\nversion: "${pkg.version}"\ndate: ${pkg.date || ""}\ntype: vault-store-record\n---\n\n` +
      `${nameOf(pkg)} ${pkg.version} is installed. The Store keeps this note to know what it installed; deleting it makes the Store treat ${nameOf(pkg)} as not installed.\n\n` +
      FENCE + "json\n" + JSON.stringify(body, null, 1) + "\n" + FENCE + "\n";
  }

  async function installed(io) {
    const out = [];
    for (const p of await io.list(RECORDS)) {
      if (!p.endsWith(".md")) continue;
      const text = await io.read(p);
      const m = /`{3}json\r?\n([\s\S]*?)\r?\n`{3}/.exec(text || "");
      if (!m) continue;
      let r = null;
      try { r = JSON.parse(m[1]); } catch (e) { continue; }
      if (!r || !r.id || !r.kind || !Array.isArray(r.files)) continue;
      if (r.files.some(f => !f || pathWhy(f.path))) continue;
      out.push({ views: [], includes: [], ...r });
    }
    return out;
  }

  async function plan(pkg, io) {
    const p = { id: pkg && pkg.id, kind: pkg && pkg.kind, version: pkg && pkg.version, from: null, add: [], replace: [], keep: [], drop: [],
      views: { add: [], replace: [] }, reload: false, refused: null };
    const refuse = why => { p.refused = why; return p; };
    if (!pkg || !pkg.id || !pkg.kind || !pkg.version || !Array.isArray(pkg.files)) return refuse("refuses this package: it says no id, kind, version or files");
    if (pkg.kind === "bundle") return refuse("refuses this package: a bundle is installed as its items");
    for (const f of pkg.files) { const why = pathWhy(f.path); if (why) return refuse(`refuses ${f.path || "a file with no path"}: ${why}`); }
    const records = await installed(io);
    const edition = records.find(r => r.kind === "edition");
    const need = pkg.requires && pkg.requires.core;
    if (need && pkg.kind !== "edition") {
      if (!edition) return refuse(`${nameOf(pkg)} needs Plus`);
      if (!meets(need, edition.version)) return refuse(`${nameOf(pkg)} needs Plus ${String(need).replace(/^\^/, "")} or later; this vault has ${edition.version}`);
    }
    const before = records.filter(r => r.id === pkg.id || (pkg.kind === "edition" && r.kind === "edition"));
    const same = before.find(r => r.id === pkg.id);
    p.from = same ? same.version : null;
    const paths = new Set(pkg.files.map(f => f.path));
    for (const f of pkg.files) {
      const there = (await io.read(f.path)) != null;
      if (f.mode === "seeded") (there ? p.keep : p.add).push(f.path);
      else (there ? p.replace : p.add).push(f.path);
    }
    for (const r of before) for (const f of r.files)
      if (f.mode === "owned" && !paths.has(f.path) && !p.drop.includes(f.path) && (await io.read(f.path)) != null) p.drop.push(f.path);
    const have = new Set((await io.views()).map(v => v.id));
    for (const v of pkg.views || []) (have.has(v.id) ? p.views.replace : p.views.add).push(v.id);
    p.reload = (pkg.views || []).some(v => v.id === "core-hall");
    return p;
  }

  async function backUp(io, now, paths, viewsToo) {
    if (!paths.length && !viewsToo) return null;
    let dir = `${BACKUPS}/${stamp(now)}`;
    for (let n = 2; (await io.list(dir)).length; n++) dir = `${BACKUPS}/${stamp(now)} (${n})`;
    for (const path of paths) { const text = await io.read(path); if (text != null) await io.write(`${dir}/${path}`, text); }
    if (viewsToo) await io.write(`${dir}/views.json`, JSON.stringify(await io.views(), null, 1));
    return dir;
  }

  async function apply(pkg, io, { now = new Date() } = {}) {
    const p = await plan(pkg, io);
    if (p.refused) throw new Error(p.refused);
    const records = await installed(io);
    const others = records.filter(r => r.id !== pkg.id && pkg.kind === "edition" && r.kind === "edition");
    const backup = await backUp(io, now, [...p.replace, ...p.drop, ...others.map(r => recordPath(r.id))], p.replace.length + p.drop.length + p.views.replace.length > 0);
    for (const f of pkg.files) if (!(f.mode === "seeded" && p.keep.includes(f.path))) await io.write(f.path, f.text);
    for (const path of p.drop) await io.remove(path);
    if ((pkg.views || []).length) {
      const fresh = new Map(pkg.views.map(v => [v.id, v]));
      const current = await io.views();
      const merged = current.map(v => fresh.has(v.id) ? fresh.get(v.id) : v);
      for (const v of pkg.views) if (!current.some(x => x.id === v.id)) merged.push(v);
      await io.setViews(merged);
    }
    for (const r of others) await io.remove(recordPath(r.id));
    await io.write(recordPath(pkg.id), recordText(pkg));
    return { plan: p, backup };
  }

  async function remove(id, io, { now = new Date() } = {}) {
    const r = (await installed(io)).find(x => x.id === id);
    if (!r) throw new Error(`${id} is not installed`);
    if (r.kind === "edition") throw new Error("an edition is not removed");
    const owned = [];
    for (const f of r.files) if (f.mode === "owned" && (await io.read(f.path)) != null) owned.push(f.path);
    const kept = r.files.filter(f => f.mode !== "owned").map(f => f.path);
    const backup = await backUp(io, now, [...owned, recordPath(id)], r.views.length > 0);
    for (const path of owned) await io.remove(path);
    if (r.views.length) { const gone = new Set(r.views); await io.setViews((await io.views()).filter(v => !gone.has(v.id))); }
    await io.remove(recordPath(id));
    return { removed: owned, kept, views: r.views.slice(), backup };
  }

  return { plan, apply, remove, installed, recordText, meets };
})();

const VAULT_STORE = (() => {
  const cvDir = app => `${(app && app.vault && app.vault.configDir) || ".obsidian"}/plugins/custom-views`;
  const norm = p => String(p == null ? "" : p).replace(/\\/g, "/").replace(/^\/+/, "");
  const parentOf = p => p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
  const parse = t => { try { return JSON.parse(t); } catch (e) { return null; } };
  const copy = o => JSON.parse(JSON.stringify(o));

  function obsidianIO(app) {
    const A = app.vault.adapter;
    const plugin = () => (app.plugins && app.plugins.plugins && app.plugins.plugins["custom-views"]) || null;
    async function ensure(dir) {
      if (!dir || (await A.exists(dir))) return;
      await ensure(parentOf(dir));
      await A.mkdir(dir);
    }
    const UNREAD = "the Custom Views store could not be read, so its views are not changed";
    async function held() {
      const pl = plugin();
      if (pl && pl.settings) {
        if (!Array.isArray(pl.settings.views) || typeof pl.saveSettings !== "function") throw new Error(UNREAD);
        return { pl, views: pl.settings.views };
      }
      const text = await io.read(cvDir(app) + "/data.json");
      if (text == null) return { pl: null, file: {}, views: [] };
      const d = parse(text);
      if (!d || typeof d !== "object" || (d.views != null && !Array.isArray(d.views))) throw new Error(UNREAD);
      return { pl: null, file: d, views: d.views || [] };
    }
    const at = p => { p = norm(p); const c = app.vault.configDir; return c && c !== ".obsidian" && p.startsWith(".obsidian/") ? c + p.slice(9) : p; };
    const io = {
      name: typeof app.vault.getName === "function" ? app.vault.getName() : "this vault",
      reloadNeeded: false,
      async read(p) {
        p = at(p);
        try { return (await A.exists(p)) ? await A.read(p) : null; } catch (e) { return null; }
      },
      async write(p, text) { p = at(p); await ensure(parentOf(p)); await A.write(p, text); },
      async remove(p) { p = at(p); if (await A.exists(p)) await A.remove(p); },
      async list(dir) {
        const out = [];
        const walk = async d => {
          if (d && !(await A.exists(d))) return;
          const r = await A.list(d || "/");
          out.push(...(r.files || []).map(norm));
          for (const f of r.folders || []) await walk(norm(f));
        };
        await walk(norm(dir).replace(/\/+$/, ""));
        return out;
      },
      async views() { return copy((await held()).views); },
      async setViews(list) {
        const h = await held();
        if (h.pl) {
          h.pl.settings.views = copy(list);
          await h.pl.saveSettings();
          if (typeof h.pl.refreshAllViews === "function") h.pl.refreshAllViews();
          return;
        }
        await io.write(cvDir(app) + "/data.json", JSON.stringify({ ...h.file, views: copy(list) }, null, 2));
        io.reloadNeeded = true;
      },
      async viewsNote() {
        if (!io.reloadNeeded) return null;
        const installed = (app.plugins && app.plugins.manifests && app.plugins.manifests["custom-views"]) || (await io.read(cvDir(app) + "/manifest.json")) != null;
        return installed ? "turn Custom Views on in Settings, Community plugins (or reload Obsidian if it is on) for the views to appear"
          : "the views appear once Custom Views is installed and turned on, from Settings, Community plugins";
      },
    };
    return io;
  }

  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const two = n => String(n).padStart(2, "0");
  const isoDay = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
  const spoken = d => `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${two(d.getHours())}:${two(d.getMinutes())}`;
  function newer(a, b) {
    const x = String(a || "0").split(".").map(Number), y = String(b || "0").split(".").map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  }
  const maskKey = (text, answer) => "••••" + String((answer && answer.id) || text || "").slice(-4);
  const itemsOf = st => (st.catalogue && Array.isArray(st.catalogue.items) ? st.catalogue.items : []);
  const recordOf = (st, id) => (st.installed || []).find(r => r.id === id) || null;
  function freeIds(items) {
    const s = new Set();
    for (const it of items) if (it.free) { s.add(it.id); for (const x of it.includes || []) s.add(x); }
    return s;
  }
  function endedFor(item, st) {
    const items = itemsOf(st);
    for (const k of st.keys || []) {
      const a = k.answer || {};
      if (!a.ok || !(a.until || a.updates)) continue;
      const named = VAULT_KEYS.names({ i: a.items || [] }, items);
      if (!VAULT_KEYS.covers(named, { id: item.id, kind: item.kind, date: item.date })) continue;
      if (a.until && String(item.date || "") > a.until) return `your yearly ended on ${a.until}; this version came after`;
      if (a.updates && item.kind === "addon" && String(item.date || "") > a.updates) return `your updates ended on ${a.updates}; this version came after`;
    }
    return null;
  }
  const removable = (item, st) => item.kind === "addon" || (item.kind === "theme" && !!st.themeInUse && item.id !== st.themeInUse);

  function pressFor(item, st) {
    if (item.kind === "bundle") return "get";
    const have = recordOf(st, item.id);
    const cover = freeIds(itemsOf(st)).has(item.id) || (st.covered || []).includes(item.id);
    if (!have && item.kind === "edition") {
      const ed = (st.installed || []).find(r => r.kind === "edition");
      if (ed && (item.free || !freeIds(itemsOf(st)).has(ed.id))) return null;
    }
    if (!have) return cover ? "install" : "get";
    if (newer(item.version, have.version)) return cover ? "update" : endedFor(item, st) ? null : "get";
    return removable(item, st) ? "remove" : null;
  }
  const onFree = st => { const ed = (st.installed || []).find(r => r.kind === "edition"); return !!ed && freeIds(itemsOf(st)).has(ed.id); };
  const coreOnly = item => item.kind === "theme" || item.kind === "addon"
    || (item.kind === "bundle" && !(item.items || []).some(i => i === "*" || i === "core"));
  function row(item, st) {
    const have = recordOf(st, item.id);
    let press = pressFor(item, st), why = null;
    if (!have && coreOnly(item) && onFree(st) && !freeIds(itemsOf(st)).has(item.id)) {
      const core = itemsOf(st).find(i => i.kind === "edition" && !i.free);
      press = null; why = core && (st.covered || []).includes(core.id) && (st.covered || []).includes(item.id) ? `your key covers it once ${core.name} is in` : `needs ${(core && core.name) || "Plus"}`;
    }
    if (press === null && have && newer(item.version, have.version)) why = endedFor(item, st);
    if (st.online === false && (press === "install" || press === "update")) { press = null; why = "this needs the Store, which could not be reached"; }
    return { id: item.id, name: item.name || item.id, kind: item.kind, version: item.version, have: have ? have.version : null, press, why,
      about: item.about || "", price: item.price || "", was: item.was || "", later: item.later || "", after: item.after || "", offer: item.offer || "", yearly: !!item.yearly, ...(Array.isArray(item.items) ? { items: item.items } : {}),
      ...(Array.isArray(item.includes) ? { includes: item.includes } : {}), ...(Array.isArray(item.points) ? { points: item.points.map(String) } : {}),
      ...(Array.isArray(item.pics) ? { pics: item.pics } : {}), ...(item.mark ? { mark: String(item.mark) } : {}),
      ...(Array.isArray(item.shows) ? { shows: item.shows.filter(s => s && s.title) } : {}) };
  }
  function sections(st) {
    const items = itemsOf(st), now = st.now || new Date();
    const edRec = (st.installed || []).find(r => r.kind === "edition") || null;
    const edItem = edRec ? items.find(i => i.id === edRec.id) || { id: edRec.id, name: edRec.name || edRec.id } : null;
    const updates = items.filter(i => i.kind !== "bundle" && recordOf(st, i.id) && newer(i.version, recordOf(st, i.id).version)).map(i => row(i, st));
    const due = updates.filter(u => u.press === "update").length;
    const since = st.lastOpened || isoDay(new Date(now.getTime() - 30 * 864e5));
    const held = new Set(items.filter(i => i.kind === "edition").flatMap(i => i.includes || [])), free = freeIds(items);
    const forSale = i => !i.later && (i.kind !== "theme" || held.has(i.id) || free.has(i.id) || (st.covered || []).includes(i.id) || !!i.price);
    const fresh = items.filter(i => i.kind !== "bundle" && i.kind !== "edition" && !recordOf(st, i.id) && i.first && i.first > since && forSale(i)).map(i => row(i, st));
    const paid = items.find(i => i.kind === "edition" && !i.free);
    return {
      vault: {
        line: edRec ? `${edItem.name} ${edRec.version} · ${due ? `${due} update${due === 1 ? "" : "s"}` : "up to date"}` : "No edition is recorded in this vault",
        upgrade: edItem && freeIds(items).has(edItem.id) && paid ? row(paid, st) : null,
      },
      offline: st.online === false ? `${st.local ? "The Store on this computer is not running" : "The Store could not be reached"}${st.readAt ? `: the list as read on ${spoken(new Date(st.readAt))}` : ", and no list has been read on this device yet"}` : null,
      keys: (st.keys || []).map(k => ({ mask: maskKey(k.text, k.answer), ok: !!(k.answer && k.answer.ok), why: (k.answer && k.answer.why) || null,
        name: (k.answer && k.answer.name) || "", covers: (k.answer && k.answer.items) || [], until: (k.answer && k.answer.until) || null, updates: (k.answer && k.answer.updates) || null })),
      updates, fresh,
      addons: items.filter(i => i.kind === "addon").map(i => row(i, st)),
      themes: items.filter(i => i.kind === "theme").map(i => row(i, st)),
      bundles: items.filter(i => i.kind === "bundle").map(i => row(i, st)),
      installed: (st.installed || []).map(r => { const it = items.find(i => i.id === r.id) || { id: r.id, name: r.name || r.id, kind: r.kind, version: r.version };
        return { ...row(it, st), press: removable(it, st) ? "remove" : null, why: null }; }),
    };
  }
  const countFor = st => { const s = sections(st); return s.updates.filter(u => u.press === "update").length + s.fresh.length; };

  const CACHE = "neurora-store-catalogue";
  function catalogueCache(app) {
    return {
      read() { try { const v = app.loadLocalStorage(CACHE); const o = typeof v === "string" ? parse(v) : v; return o && o.catalogue ? { catalogue: o.catalogue, at: o.at } : null; } catch (e) { return null; } },
      write(catalogue, at = new Date()) { try { app.saveLocalStorage(CACHE, JSON.stringify({ catalogue, at: new Date(at).toISOString() })); } catch (e) { } },
    };
  }

  const HOUR = 36e5;
  const DEFAULT_URL = "https://store.jamn.workers.dev";
  const OPENED = "neurora-store-opened", COVERS = "neurora-store-covers", CHECKED = "neurora-store-checked";
  const SETTINGS = "99_Meta/Vault Settings.md";
  const recordPath = id => `99_Meta/Store/${id}.md`;
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const KIND_WORD = { edition: "edition", addon: "add-on", theme: "theme", bundle: "bundle" };
  const PRESS_WORD = { install: "Install", update: "Update", get: "Get it", remove: "Remove" };
  const and = xs => xs.length < 2 ? xs.join("") : `${xs.slice(0, -1).join(", ")} and ${xs[xs.length - 1]}`;
  const plural = (n, one, many = one + "s") => `${n} ${n === 1 ? one : many}`;
  const keysOf = s => [].concat(s.store_keys || []).map(k => String(k).replace(/\s+/g, "")).filter(Boolean);
  const checkOn = s => !(s.store_check === false || String(s.store_check).trim().toLowerCase() === "false");
  const baseOf = s => String(s.store_url || DEFAULT_URL).trim().replace(/\/+$/, "");
  const local = (app, k) => { try { const v = app.loadLocalStorage(k); return typeof v === "string" ? parse(v) : v || null; } catch (e) { return null; } };
  const keep = (app, k, v) => { try { app.saveLocalStorage(k, v == null ? null : JSON.stringify(v)); } catch (e) { } };

  function asker(settings) {
    const base = baseOf(settings);
    return async (route, body) => {
      let req = null;
      try { const o = require("obsidian"); if (o && o.requestUrl) req = o.requestUrl; } catch (e) { }
      try { if (!req && window.requestUrl) req = window.requestUrl; } catch (e) { }
      const post = body !== undefined;
      if (req) {
        const r = await req({ url: base + route, method: post ? "POST" : "GET", contentType: "application/json", body: post ? JSON.stringify(body) : undefined, headers: { Accept: "application/json" }, throw: false });
        let json = null; try { json = r.json; } catch (e) { }
        return { status: r.status, json, text: r.text };
      }
      const r = await fetch(base + route, { method: post ? "POST" : "GET", body: post ? JSON.stringify(body) : undefined, headers: post ? { Accept: "application/json", "content-type": "application/json" } : { Accept: "application/json" } });
      const text = await r.text();
      return { status: r.status, json: parse(text), text };
    };
  }
  async function call(ask, route, body) {
    const r = await ask(route, body);
    let j = r && r.json != null ? r.json : r && typeof r.text === "string" ? parse(r.text) : null;
    if (!r || !j || typeof j !== "object") throw new Error(`the Store answered ${r && r.status ? r.status : "nothing"}, not with its own reply`);
    if (!(r.status >= 200 && r.status < 300)) { const e = new Error(String(j.why || `the Store answered ${r.status}`)); e.refused = true; throw e; }
    return j;
  }
  const unreached = e => e && (e.refused || /^the Store answered/.test(String(e.message))) ? String(e.message) : null;
  const optsOf = (ctx, o = {}) => ({ ask: o.ask || asker(ctx.settings || {}), now: o.now || new Date(), open: o.open || (u => { try { window.open(u); } catch (e) { } }) });
  const sayOf = ctx => label => { try { (ctx.ui && ctx.ui.toast ? ctx.ui.toast : ctx.NV.toast)(label); } catch (e) { } };
  const PAGES = new WeakMap();

  async function stateOf(ctx, o, { fresh }) {
    const app = ctx.app, s = ctx.settings || {}, io = obsidianIO(app), cache = catalogueCache(app), keys = keysOf(s);
    const records = await VAULT_INSTALL.installed(io);
    let catalogue = null, readAt = null, online = true, why = null, answer = null;
    if (fresh) {
      try {
        const c = await call(o.ask, "/catalogue");
        if (!Array.isArray(c.items)) throw new Error("the Store's list holds no items");
        cache.write(c, o.now); catalogue = c; readAt = new Date(o.now).toISOString();
        keep(app, CHECKED, { at: readAt });
      } catch (e) { online = false; why = unreached(e); }
      if (online && keys.length) {
        try { answer = await call(o.ask, "/covers", { keys }); keep(app, COVERS, { keys, answer }); }
        catch (e) { if (e.refused) why = `the keys could not be checked: ${e.message}`; else { online = false; why = unreached(e); } }
      }
    }
    if (!catalogue) { const c = cache.read(); catalogue = c ? c.catalogue : { items: [] }; readAt = c ? c.at : null; }
    if (!answer) { const c = local(app, COVERS); answer = c && JSON.stringify(c.keys) === JSON.stringify(keys) ? c.answer : null; }
    const shown = keys.map((text, i) => {
      const a = answer && Array.isArray(answer.keys) ? answer.keys[i] : null, r = VAULT_KEYS.read(text), p = r.ok ? r.payload : {};
      return { text, answer: a || { ok: false, unchecked: true, id: p.k ? String(p.k) : "", name: p.n ? String(p.n) : "", items: (p.i || []).map(String), until: p.u ? String(p.u) : undefined, updates: p.a ? String(p.a) : undefined } };
    });
    const opened = local(app, OPENED);
    return { io, records, catalogue, readAt, online: fresh ? online : !!(answer || local(app, CHECKED)), local: /^https?:\/\/(127\.|localhost|\[::1\])/.test(baseOf(s)), why, keys: shown,
      covered: answer && Array.isArray(answer.covered) ? answer.covered.map(String) : [],
      installed: records.map(r => ({ id: r.id, kind: r.kind, version: r.version, name: r.name })), themeInUse: String(s.style || "").trim().toLowerCase() || null,
      lastOpened: opened && opened.day ? opened.day : null, now: o.now };
  }

  function setCount(ctx, n) {
    try { const t = ctx.ui && ctx.ui.tab && ctx.ui.tab(), b = t && t.querySelector(".vc-tab-n"); if (b) b.textContent = n ? String(n) : ""; } catch (e) { }
  }

  function coversWords(items, catalogue) {
    const byId = new Map(((catalogue && catalogue.items) || []).map(i => [i.id, i.name]));
    const words = (items || []).map(x => x === "*" ? "everything" : x === "*theme" ? "every theme" : x === "*addon" ? "every add-on" : byId.get(x) || x);
    return words.length ? words.join(", ") : "nothing yet";
  }

  const SITE = "https://auriel.me/", PIC_BASE = SITE + "img/";
  const PICS = {
    core: ["p03-lamplit-forest-hall", "p04-flat-heather-hall", "p08-material-cobalt-hall"],
    lamplit: ["p03-lamplit-forest-hall", "p01-lamplit-oxblood-ledger", "p02-lamplit-midnight-shelves"],
    flat: ["p04-flat-heather-hall", "p05-flat-indigonight-settings", "p07-flat-nocturne-daily"],
    material: ["p08-material-cobalt-hall", "p09-material-cobaltdark-shelves", "p10-material-sage-sound"],
    everything: ["p05-flat-indigonight-settings", "p02-lamplit-midnight-shelves", "p10-material-sage-sound"],
    lifetime: ["p01-lamplit-oxblood-ledger", "p06-flat-hearthlight-ledger", "p09-material-cobaltdark-shelves"],
  };
  const KIND_MARK = { theme: "palette", bundle: "cards", addon: "frame", edition: "arch" };
  const markOf = r => (typeof r.mark === "string" && /^[\w-]+$/.test(r.mark) && r.mark) || KIND_MARK[r.kind] || "image";
  const picsOf = r => (Array.isArray(r.pics) && r.pics.length ? r.pics : (PICS[r.id] || []).map(f => `${PIC_BASE}${f}.jpg`)).map(String).filter(u => /^https:\/\/\S+$/.test(u));
  const pic = (u, alt) => `<span class="st-pic"><img src="${esc(u)}" alt="${esc(alt || "")}" loading="lazy" decoding="async" data-st-pic></span>`;
  const frame = (NV, r, words) => `<span class="st-pic st-pic--none"><span class="st-ph"><span class="st-ph-mark">${NV && NV.icon ? NV.icon(markOf(r)) : ""}</span>` +
    `${words ? `<span class="st-ph-w">${esc(words)}</span>` : ""}</span></span>`;
  const cap = s => String(s || "").charAt(0).toUpperCase() + String(s || "").slice(1);

  const PRESS_MARK = { install: "import", update: "refresh", get: "basket", remove: "delete" };
  function pressHtml(word, mark, { hot = false, warn = false, quiet = false, attrs = "", cls = "" } = {}, NV = VNV) {
    const ic = NV && NV.icon ? NV.icon(mark) : "";
    return `<button class="vc-ib${quiet ? " vc-ib--sm" : " vc-ib--ring"} vc-ib--word is-on${hot ? " vc-ib--hot" : ""}${warn ? " vc-ib--warn" : ""}${cls ? " " + cls : ""}" ${attrs}>` +
      `${ic}<span class="vc-word">${esc(word)}</span></button>`;
  }
  let VNV = null;
  function btnOf(r, { word = "" } = {}) {
    if (!r.press || (r.later && r.press === "get")) return "";
    const hot = r.press === "install" || r.press === "update" || r.press === "get";
    return pressHtml(word || PRESS_WORD[r.press], PRESS_MARK[r.press] || "go", { hot, warn: r.press === "remove", attrs: `data-st-press="${r.press}" data-st-id="${esc(r.id)}" aria-label="${esc(PRESS_WORD[r.press] + " " + r.name)}"` });
  }
  const perOf = r => r.yearly ? (r.after && /^then /.test(r.after) ? "the first year" : "a year") : "";
  function amtHtml(r, { planned = false } = {}) {
    if (!r.price) return "";
    const per = perOf(r) || (planned || r.kind === "bundle" ? "once" : "");
    const small = [r.after, planned ? "planned" : ""].filter(Boolean).map(esc).join(" · ");
    return `<p class="st-amt"><b>${esc(r.price)}</b>${per ? `<span class="st-per">${per}</span>` : ""}${r.was && !planned ? `<s>${esc(r.was)}</s>` : ""}${small ? `<small>${small}</small>` : ""}</p>`;
  }
  const holdsOf = (r, items) => and((r.items || []).map(x => x === "*" ? "everything" : x === "*theme" ? "every theme" : x === "*addon" ? "every add-on" : ((items.find(i => i.id === x) || {}).name || x)));
  const wildcard = r => (r.items || []).some(i => String(i).startsWith("*"));

  function lineHtml(r, NV, st, { installed = false } = {}) {
    const ver = r.have && r.version && r.have !== r.version ? `${esc(r.have)} → ${esc(r.version)}` : esc(r.version || r.have || "");
    const ps = picsOf(r);
    const thumb = `<span class="st-thumb">${ps.length ? pic(ps[0], "") : frame(NV, r, "")}</span>`;
    const end = r.later && !r.have ? `<span class="st-end">${amtHtml(r, { planned: true })}<span class="st-when">${esc(cap(r.later))}</span></span>`
      : r.press === "get" && r.price ? `<span class="st-end">${amtHtml(r)}</span>` : "";
    const inUse = r.kind === "theme" && st.themeInUse === r.id;
    const done = (installed || !r.press) && !r.why && r.have && r.press !== "remove" ? `<span class="vc-tag vc-tag--good">${inUse ? "in use" : "installed"}</span>` : "";
    return `<div class="st-line" data-st-row="${esc(r.id)}">${thumb}<span class="st-name"><b>${esc(r.name)}</b>${ver ? `<span class="st-ver">${ver}</span>` : ""}</span>` +
      `<span class="vc-sub">${esc(r.about || KIND_WORD[r.kind] || "")}${r.why ? ` <span class="st-why">${esc(r.why)}</span>` : ""}</span>${end}${done}${btnOf(r)}</div>`;
  }
  const lines = rs => `<div class="st-lines">${rs}</div>`;

  function tileHtml(r, NV, st, { short, held, free, freeShort }) {
    const ps = picsOf(r), inUse = st.themeInUse === r.id;
    const tag = r.have ? `<span class="vc-tag vc-tag--good">${inUse ? "in use" : "installed"}</span>`
      : free.has(r.id) ? `<span class="vc-tag">in ${esc(freeShort)}</span>` : held.has(r.id) ? `<span class="vc-tag">with ${esc(short)}</span>`
      : r.later ? `<span class="vc-tag vc-tag--note">coming</span>` : r.price ? `<span class="vc-tag">${esc(r.price)}</span>` : "";
    return `<article class="st-tile${inUse ? " is-on" : ""}" data-st-row="${esc(r.id)}"><span class="st-shot">${ps.length ? pic(ps[0], r.name) : frame(NV, r, "Picture to come")}</span>` +
      `<div class="st-tile-b"><b class="st-title">${esc(r.name)}</b>${tag}${r.press && r.press !== "remove" ? btnOf(r) : ""}` +
      `${r.about || r.why ? `<span class="st-sub">${esc(r.about || "")}${r.why ? ` <span class="st-why">${esc(r.why)}</span>` : ""}</span>` : ""}</div></article>`;
  }

  function coreHtml(c, { have, short, items, open = false }) {
    const themes = (c.includes || []).map(id => (items.find(i => i.id === id) || {}).name || id);
    const ticks = [...(c.points || []), ...(themes.length ? [`${and(themes)}, every palette`] : [])];
    const keyed = !have && c.press === "install";
    return `<article class="st-offer st-offer--rec" data-st-row="${esc(c.id)}">${have ? `<span class="st-tag st-tag--good">In this vault</span>` : keyed ? `<span class="st-tag st-tag--good">Your key</span>` : `<span class="st-tag">Recommended</span>`}` +
      `<h3 class="st-title">${esc(c.name)}</h3>` +
      (have ? `<p class="st-amt st-amt--have"><b>Yours</b><small>paid once, with every update for good</small></p>`
        : keyed ? `<p class="st-amt st-amt--have"><b>Yours</b><small>your key covers it, with every update</small></p>` : `${amtHtml(c)}<p class="st-once">paid once, with every update</p>`) +
      (ticks.length ? `<ul class="st-ticks">${ticks.map(t => `<li>${esc(t)}</li>`).join("")}</ul>` : "") +
      ((c.shows || []).length ? pressHtml(addsWord(short, open), "image", { quiet: true, cls: "st-seeadds", attrs: `data-st-adds aria-controls="st-adds" aria-expanded="${open}"` }) : "") +
      (c.why ? `<p class="st-why">${esc(c.why)}</p>` : "") +
      (!have && c.press ? `<div class="st-acts">${btnOf(c, { word: c.press === "get" ? `Get ${short}` : `Install ${short}` })}${keyed ? "" : pressHtml("I have a key", "key", { quiet: true, attrs: 'data-st-press="key-add"' })}</div>` : "") + `</article>`;
  }
  function passesHtml(passes, { short, items }) {
    const coming = passes.every(r => r.later);
    return `<article class="st-offer st-offer--passes">${coming ? `<span class="st-tag">Coming</span>` : ""}<h3 class="st-title">The passes</h3>` +
      `<p class="st-once">on top of ${esc(short)}, billed yearly, cancel any time</p><ul class="st-plist">` +
      passes.map(r => `<li data-st-row="${esc(r.id)}"><b>${esc(r.name)}</b><span class="vc-sub">${esc(holdsOf(r, items))}${r.why ? ` <span class="st-why">${esc(r.why)}</span>` : ""}</span>` +
        `${amtHtml(r, { planned: !!r.later })}${r.later ? "" : btnOf(r)}</li>`).join("") + `</ul>` +
      `<p class="st-fine">${coming ? "Each goes on sale once there is something in it. " : ""}A pass holds what is out while it runs; what you install keeps working after it ends.</p></article>`;
  }
  function lifeHtml(r, { short, items }) {
    const tag = r.later ? "Coming" : r.offer ? String(r.offer).split(" · ")[0] + " price" : "";
    return `<article class="st-offer st-offer--life" data-st-row="${esc(r.id)}">${tag ? `<span class="st-tag">${esc(tag)}</span>` : ""}<h3 class="st-title">${esc(r.name)}</h3>` +
      `${amtHtml(r, { planned: !!r.later })}<p class="st-once">on top of ${esc(short)}, paid once, with every update for good</p>` +
      `<ul class="st-ticks"><li>${esc(cap(holdsOf(r, items)))}, as each is out</li><li>Every update</li></ul>` +
      (r.why ? `<p class="st-why">${esc(r.why)}</p>` : "") +
      (r.later ? `<p class="st-fine">On sale ${esc(r.later)}${r.after ? ", at its beta price while the beta runs" : ""}. All it will hold is planned, not promised.</p>`
        : r.press ? `<div class="st-acts">${btnOf(r, { word: r.press === "get" ? `Get ${r.name}` : "" })}</div>` : "") + `</article>`;
  }
  const addsWord = (short, open) => open ? "Hide the pictures" : `See what ${short} adds`;
  function lookOf(el, st) {
    try {
      const n = String(getComputedStyle(el).getPropertyValue("--theme-name") || "").replace(/["']/g, "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
      return st.themeInUse && n ? `${st.themeInUse}-${n}` : "";
    } catch (e) { return ""; }
  }
  function addsHtml(c, NV, { short, look, open, lite, freeShort }) {
    const fig = s => {
      const mine = s.looks && look && typeof s.looks[look] === "string" && /^https:\/\/\S+$/.test(s.looks[look]) ? [s.looks[look]] : [];
      const ps = (mine.length ? mine : picsOf(s)).slice(0, 2);
      const shot = ps.length ? ps.map(u => pic(u, s.title)).join("") : frame(NV, { mark: s.mark || "image" }, "Picture to come");
      return `<figure class="st-add"><span class="st-add-shot${ps.length > 1 ? " st-add-shot--two" : ""}${ps.length ? "" : " st-add-shot--none"}">${shot}</span>` +
        `<figcaption><b class="st-title">${esc(s.title)}</b>${s.words ? `<span class="vc-sub">${esc(s.words)}</span>` : ""}</figcaption></figure>`;
    };
    return `<section class="st-adds" id="st-adds" data-st-adds-sec${open ? "" : " hidden"}>${secH(`What ${short} adds to ${freeShort}`, "the vault as it is, in the palette you wear")}` +
      (lite ? `<p class="st-adds-lite"><b>${esc(freeShort)} holds</b> ${esc(lite.charAt(0).toLowerCase() + lite.slice(1))}</p>` : "") +
      `<div class="st-adds-g">${c.shows.map(fig).join("")}</div></section>`;
  }
  const ADDS_OPEN = new WeakSet();

  function holdsTable(c, passes, lives, { short, have }) {
    const cols = [c, ...passes, ...lives];
    const has = (col, kind) => col !== c && (col.items || []).some(i => i === "*" || i === "*" + kind);
    const cell = (col, yes) => `<td${col === c ? ' class="st-on"' : ""}>${yes ? `<i class="st-yes" aria-label="yes"></i><small>${col.yearly ? "while it runs" : "for good"}</small>` : `<span class="st-no" aria-label="no">—</span>`}</td>`;
    const row = (words, yes) => `<tr><th scope="row">${esc(words)}</th>${cols.map(col => cell(col, yes(col))).join("")}</tr>`;
    return `<section class="st-holds">${secH("What each holds, with " + short, have ? `${short} is in this vault` : "")}<div class="st-cmp-w"><table class="st-cmp">` +
      `<thead><tr><th></th>${cols.map(col => `<th scope="col"${col === c ? ' class="st-on"' : ""}>${col === c ? esc(short) : "+ " + esc(col.name)}</th>`).join("")}</tr></thead><tbody>` +
      `<tr><th scope="row">${esc(c.name)} and its themes</th>${cols.map(col => `<td${col === c ? ' class="st-on"' : ""}><i class="st-yes" aria-label="yes"></i><small>for good</small></td>`).join("")}</tr>` +
      row("Every theme, as each is out", col => has(col, "theme")) + row("Every add-on, as each is out", col => has(col, "addon")) +
      `<tr><th scope="row">How it is paid</th>${cols.map(col => `<td${col === c ? ' class="st-on"' : ""}>${col === c ? "Once" : col.yearly ? `${esc(short)} once, then yearly` : `${esc(short)} and ${esc(col.name)} once`}</td>`).join("")}</tr>` +
      `</tbody></table></div></section>`;
  }

  const secH = (title, sub, more = "") => `<div class="st-sec-h"><h2 class="st-title">${esc(title)}</h2>${sub ? `<small>${esc(sub)}</small>` : ""}${more}</div>`;
  const block = (title, sub, body, more) => `<section class="vc-plate st-block">${secH(title, sub, more)}${body}</section>`;

  function render(ctx, st, raw) {
    const panel = ctx.ui && ctx.ui.panel && ctx.ui.panel(); if (!panel) return;
    const NV = ctx.NV || {}, S = sections(st), on = checkOn(ctx.settings || {}), items = itemsOf(st);
    VNV = NV;
    const due = S.updates.filter(u => u.press === "update").length;
    const keys = S.keys.map((k, i) => {
      const a = st.keys[i].answer || {};
      const state = a.unchecked ? (st.online === false ? "not checked: the Store could not be reached" : a.why ? `not checked: ${a.why}` : "not checked yet") : a.ok ? `covers ${coversWords(a.items, st.catalogue)}` : String(a.why || "not accepted");
      return `<div class="st-key"><span class="st-k"><b>${esc(k.mask)}</b>${k.name ? ` ${esc(k.name)}` : ""}<span class="vc-sub">${esc(state)}${a.until ? ` · yearly to ${esc(a.until)}` : a.renews ? " · yearly, while it runs" : ""}${a.updates ? ` · add-on updates to ${esc(a.updates)}` : ""}</span></span>` +
        pressHtml("change key", "edit", { quiet: true, attrs: `data-st-press="key-change" data-st-i="${i}" aria-label="change the key ${esc(k.mask)}"` }) +
        pressHtml("remove", "delete", { quiet: true, warn: true, attrs: `data-st-press="key-remove" data-st-i="${i}" aria-label="remove the key ${esc(k.mask)}"` }) + `</div>`;
    }).join("");
    const edRec = (st.installed || []).find(r => r.kind === "edition") || null;
    const edItem = edRec ? items.find(i => i.id === edRec.id) : null;
    const edName = edRec ? (edItem && edItem.name) || edRec.name || edRec.id : "";
    const paid = items.find(i => i.kind === "edition" && !i.free);
    const core = paid ? row(paid, st) : null, short = core ? String(core.name).replace(/^Auriel\s+/, "") : "Plus";
    const freeItem = items.find(i => i.kind === "edition" && i.free), freeShort = freeItem ? String(freeItem.name).replace(/^Auriel\s+/, "") : "Basic";
    const haveCore = !!(core && core.have);
    const free = freeIds(items), held = new Set(items.filter(i => i.kind === "edition").flatMap(i => i.includes || []));
    const shownTheme = r => !!r.have || r.press === "install" || r.press === "update" || free.has(r.id) || (st.covered || []).includes(r.id) || held.has(r.id) || !!r.price || !!r.later;
    const passes = S.bundles.filter(r => r.yearly && wildcard(r)), lives = S.bundles.filter(r => !r.yearly && wildcard(r));
    const alone = S.bundles.filter(r => !wildcard(r)).concat(S.addons).filter(r => !r.have);
    const themes = S.themes.filter(shownTheme);
    const any = S.addons.length + S.themes.length + S.bundles.length;

    const onLite = !!S.vault.upgrade, keyedCore = onLite && !!core && !core.have && core.press === "install";
    const dot = S.offline ? "st-dot--off" : due ? "st-dot--due" : "";
    const status = S.offline ? `${esc(S.offline)}${st.why ? `: ${esc(st.why)}` : ""}` : `${esc(S.vault.line)}${st.why ? ` · <span class="st-why">${esc(st.why)}</span>` : st.readAt ? ` · the list as read on ${esc(spoken(new Date(st.readAt)))}` : ""}`;
    const sitsOn = passes.length && lives.length ? `A pass or ${lives[0].name}` : passes.length ? "A pass" : lives.length ? lives[0].name : "";
    const h1 = S.offline ? (st.local ? "The Store on this computer is not running." : "The Store could not be reached.")
      : keyedCore ? `Your key brings ${short}.` : onLite ? `Start with ${short}, add the rest.` : due ? `${due === 1 ? "One update is" : `${due} updates are`} ready.` : edRec ? `${edName}, up to date.` : "No edition is recorded in this vault.";
    const lede = keyedCore ? `Install ${short} in place of ${freeShort}: your notes stay as they are, and its themes come with it. The rest your key covers is offered here once ${short} is in, and each thing to come as it is out.`
      : onLite ? `${short} is paid once and is yours for good.${sitsOn ? ` ${sitsOn} sits on top of it, so nobody pays for ${short} twice${passes.length ? ": a pass is billed yearly and holds what is out while it runs, and you can cancel it any time" : ""}.` : ""} A key works in every vault you have, on every computer.`
      : haveCore ? `${core.name} is yours for good, with every update.${sitsOn ? " What comes next sits on top of it." : ""}` : "";
    const hero = `<header class="st-hero"><h1 class="st-title st-h1">${esc(h1)}</h1>${lede ? `<p class="st-lede">${esc(lede)}</p>` : ""}` +
      `<span class="st-status"><i class="st-dot ${dot}"></i><span>${status}</span></span>${pressHtml("Check again", "refresh", { cls: "st-again", attrs: 'data-st-press="again"' })}</header>`;
    const keyStrip = `<section class="st-keys"><span class="st-title">${S.keys.length > 1 ? "Keys" : "Key"}</span><div class="st-key-list">${keys ||
      `<span class="st-hint">The key comes by email when you buy. Only the key is sent to check it.</span>`}</div>` +
      `${pressHtml(S.keys.length ? "Add another key" : "Add a key", "key", { attrs: 'data-st-press="key-add"' })}</section>`;

    const offered = [core, ...S.bundles, ...S.addons, ...S.themes].filter((r, i, a) => r && r.offer && r.price && !r.later && r.press === "get" && a.findIndex(x => x && x.id === r.id) === i);
    const offers = [...new Set(offered.map(r => r.offer))];
    const band = offered.length ? `<p class="st-band"><span class="vc-tag vc-tag--hot">${esc(offers.length === 1 ? offers[0] : `${String(offers[0]).split(" · ")[0]} prices`)}</span>` +
      `<span>${esc(and(offered.map(r => r.name)))}, while the beta runs.</span></p>` : "";

    const g = { short, items, have: haveCore, open: ADDS_OPEN.has(panel) };
    const cards = [core ? coreHtml(core, g) : "", passes.length ? passesHtml(passes, g) : "", ...lives.map(r => lifeHtml(r, g))].filter(Boolean);
    const liteAbout = (freeItem || {}).about || "";
    const adds = core && (core.shows || []).length ? addsHtml(core, NV, { short, look: lookOf(panel, st), open: g.open, lite: liteAbout, freeShort }) : "";
    const lineup = core && any ? `<section class="st-lineup">${onLite ? "" : secH("Add the rest.", `On top of ${short}`)}<div class="st-offers">${cards.join("")}</div>${adds}</section>` +
      `<p class="st-assure"><span>Refunded if it does not work</span><span>Paid through Polar</span><span>Cancel a pass any time</span></p>` +
      (passes.length + lives.length ? holdsTable(core, passes, lives, g) : "") : "";
    const tiles = themes.length ? `<section class="st-themes">${secH("Themes", plural(themes.length, "theme"))}<div class="st-tiles">${themes.map(r => tileHtml(r, NV, st, { short, held, free, freeShort })).join("")}</div></section>` : "";
    const rest = alone.length ? `<section class="st-alone">${secH("On their own", `Each needs ${short}`)}${lines(alone.map(r => lineHtml(r, NV, st)).join(""))}</section>` : "";

    panel.innerHTML = `<div class="st-page" data-st-page>` + hero + keyStrip + band +
      (S.updates.length ? block("Updates", plural(due, "ready", "ready"), lines(S.updates.map(r => lineHtml(r, NV, st)).join("")),
        due >= 2 ? pressHtml(`Update all ${due}`, "refresh", { hot: true, attrs: 'data-st-press="update-all"' }) : "") : "") +
      (S.fresh.length ? block("New", st.lastOpened ? `since ${st.lastOpened}` : "in the last 30 days", lines(S.fresh.map(r => lineHtml(r, NV, st)).join(""))) : "") +
      (any ? lineup + tiles + rest
        : `<p class="vc-empty st-none">Nothing from the Store yet: <b>Check again</b> once this device is online.</p>`) +
      block("In this vault", plural(S.installed.length, "item"), S.installed.length ? lines(S.installed.map(r => lineHtml(r, NV, st, { installed: true })).join("")) : `<p class="vc-empty">Nothing is recorded as installed in this vault.</p>`) +
      `<div class="st-foot">${pressHtml(on ? "On" : "Off", on ? "bell" : "mute", { hot: on, attrs: `data-st-press="check" aria-pressed="${on}"` })}` +
      `<span class="st-foot-w">Check for new things when the Hall opens: at most once an hour, with no key sent</span>` +
      `<a class="st-site" href="${SITE}#prices">Prices and the small print, on auriel.me</a></div></div>`;
    panel.querySelectorAll("[data-st-press]").forEach(b => b.addEventListener("click", e => {
      if (e && e.preventDefault) e.preventDefault();
      return act(ctx, b.getAttribute("data-st-press"), b.getAttribute("data-st-id"), raw, b.getAttribute("data-st-i"));
    }));
    panel.querySelectorAll("[data-st-adds]").forEach(b => b.addEventListener("click", e => {
      if (e && e.preventDefault) e.preventDefault();
      const sec = panel.querySelector("[data-st-adds-sec]"); if (!sec) return;
      const open = !ADDS_OPEN.has(panel);
      if (open) ADDS_OPEN.add(panel); else ADDS_OPEN.delete(panel);
      sec.hidden = !open;
      b.setAttribute("aria-expanded", String(open));
      const w = b.querySelector(".vc-word"); if (w) w.textContent = addsWord(short, open);
      if (open && sec.scrollIntoView) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    }));
    wirePictures(panel);
    PAGES.set(panel, st);
  }
  function wirePictures(panel) {
    try {
      panel.querySelectorAll("[data-st-pic]").forEach(img => img.addEventListener("error", () => { const p = img.parentNode; if (p && p.classList) p.classList.add("st-pic--gone"); }));
    } catch (e) { }
  }

  async function draw(ctx, raw = {}) {
    const o = optsOf(ctx, raw), panel = ctx.ui && ctx.ui.panel && ctx.ui.panel();
    if (!panel) return;
    try {
      const st = await stateOf(ctx, o, { fresh: true });
      render(ctx, st, raw);
      keep(ctx.app, OPENED, { day: isoDay(o.now) });
      setCount(ctx, countFor({ ...st, lastOpened: isoDay(o.now) }));
    } catch (e) { panel.innerHTML = `<p class="vc-empty">The Store could not be drawn: ${esc(e.message)}</p>`; }
  }
  async function again(ctx, raw) {
    const o = optsOf(ctx, raw), st = await stateOf(ctx, o, { fresh: false });
    const was = ctx.ui && ctx.ui.panel && PAGES.get(ctx.ui.panel());
    if (was) { st.online = was.online; st.why = was.why; }
    render(ctx, st, raw);
    setCount(ctx, countFor({ ...st, lastOpened: isoDay(o.now) }));
    return st;
  }

  async function boot(ctx, raw = {}) {
    const o = optsOf(ctx, raw), app = ctx.app;
    if (checkOn(ctx.settings || {})) {
      const last = local(app, CHECKED);
      if (!last || !(o.now - new Date(last.at) < HOUR)) {
        keep(app, CHECKED, { at: new Date(o.now).toISOString() });
        try { const c = await call(o.ask, "/catalogue"); if (Array.isArray(c.items)) catalogueCache(app).write(c, o.now); } catch (e) { }
      }
    }
    if (!catalogueCache(app).read()) { setCount(ctx, 0); return 0; }
    const n = countFor(await stateOf(ctx, o, { fresh: false }));
    setCount(ctx, n);
    return n;
  }

  const figures = p => [`${plural(p.add.length, "file")} added`, `${p.replace.length} replaced`, `${p.keep.length} kept`]
    .concat(p.drop.length ? [`${p.drop.length} taken out`] : [])
    .concat(p.views.add.length || p.views.replace.length ? [`${plural(p.views.add.length, "view")} added, ${p.views.replace.length} replaced`] : []).join(", ");
  const refusedWords = why => /^refuses /.test(why) ? `The installer ${why}` : why.charAt(0).toUpperCase() + why.slice(1);

  let working = false;
  async function act(ctx, what, id, raw = {}, i = null) {
    const o = optsOf(ctx, raw), say = sayOf(ctx);
    if (working && what !== "again") { say("Still working on the last press"); return; }
    working = what !== "again";
    try {
      if (what === "again") { await draw(ctx, raw); return; }
      if (what === "check") return await checkSwitch(ctx, raw);
      if (/^key-/.test(what)) return await keyPress(ctx, what, Number(i), raw);
      const panel = ctx.ui && ctx.ui.panel && ctx.ui.panel();
      const st = await stateOf(ctx, o, { fresh: false }), was = panel && PAGES.get(panel);
      if (was) { st.online = was.online; st.covered = was.covered; }
      const items = (st.catalogue && st.catalogue.items) || [];
      const item = items.find(x => x.id === id), rec = st.records.find(r => r.id === id);
      const name = (item && item.name) || (rec && rec.name) || id;
      if (what === "remove") return await removeOne(ctx, st, rec, name, raw);
      if (what === "get") {
        const u = String((item && item.shop && item.shop.url) || (st.catalogue && st.catalogue.getIt) || "");
        if (!/^https:\/\/\S+$/.test(u)) { say(`${esc(name)} is not on sale yet`); return; }
        o.open(u); return;
      }
      if (what === "install" || what === "update") return await installMany(ctx, st, [item || { id, name }], raw);
      if (what === "update-all") return await installMany(ctx, st, sections(st).updates.filter(u => u.press === "update").map(u => items.find(x => x.id === u.id)).filter(Boolean), raw);
    } catch (e) { say(esc(e && e.message ? e.message : String(e))); }
    finally { if (what !== "again") working = false; }
  }

  async function installMany(ctx, st, items, raw) {
    const o = optsOf(ctx, raw), say = sayOf(ctx), keys = keysOf(ctx.settings || {});
    if (!items.length) return;
    if (st.online === false) { say("The Store could not be reached, so nothing can be installed just now"); return; }
    items = items.slice().sort((a, b) => (a.kind === "edition" ? 0 : 1) - (b.kind === "edition" ? 0 : 1));
    const got = [];
    for (const it of items) {
      const pkg = await call(o.ask, "/package", { keys, id: it.id });
      const p = await VAULT_INSTALL.plan(pkg, st.io);
      if (p.refused) { say(esc(refusedWords(p.refused))); return; }
      got.push({ it, pkg, p });
    }
    const one = got.length === 1, verb = one ? (got[0].p.from ? "Update" : "Install") : "Update";
    const title = one ? `${verb} ${got[0].it.name || got[0].pkg.name || got[0].pkg.id} ${got[0].pkg.version}` : `Update ${got.length} items`;
    const lines = got.map(g => `${one ? "" : `${g.it.name || g.pkg.id} ${g.p.from ? g.p.from + " → " : ""}${g.pkg.version}: `}${figures(g.p)}.`);
    const body = esc(lines.join(" ")) + (got.some(g => g.p.reload) ? " The Hall is drawn again afterwards." : "") +
      " Whatever is replaced or taken out is copied to .neurora/backups first.";
    if (!(await ctx.NV.modal({ title, body, confirmText: verb.toLowerCase() }))) return;
    const done = [];
    let failed = null;
    for (const g of got) {
      try { const r = await VAULT_INSTALL.apply(g.pkg, st.io, { now: o.now }); done.push({ ...g, backup: r.backup }); }
      catch (e) { failed = { g, why: String(e && e.message || e) }; break; }
    }
    const nm = g => g.it.name || g.pkg.name || g.pkg.id;
    const label = !done.length ? `<b>${esc(nm(failed.g))} ${esc(failed.g.pkg.version)}</b> was not ${failed.g.p.from ? "updated" : "installed"}`
      : done.length === 1 && one
        ? `<b>${esc(nm(done[0]))} ${esc(done[0].pkg.version)}</b> ${done[0].p.from ? "updated" : "installed"}: ${esc(figures(done[0].p))}`
        : `<b>${plural(done.length, "item")}</b> updated: ${esc(done.map(g => `${nm(g)} ${g.pkg.version}`).join(", "))}`;
    const said = done.filter(d => d.backup).map(d => `backed up to ${d.backup}`);
    if (failed) said.push(`${nm(failed.g)} ${failed.g.pkg.version} stopped partway: ${failed.why}. Its own files are as far as it got; Update tries it again`);
    const needs = await st.io.viewsNote();
    await ctx.NV.receipt(label + (needs ? `; ${needs}` : ""), done.length ? recordPath(done[0].pkg.id) : null, null, { lines: said });
    await again(ctx, raw);
  }

  async function removeOne(ctx, st, rec, name, raw) {
    const o = optsOf(ctx, raw), say = sayOf(ctx);
    if (!rec) { say(`${esc(name)} is not installed`); return; }
    if (rec.kind === "edition") { say(`${esc(name)} is this vault's edition, and an edition is not removed: another edition replaces it`); return; }
    if (rec.kind === "theme" && (!st.themeInUse || st.themeInUse === rec.id)) { say(`${esc(name)} is the theme in use: choose another in Settings before removing it`); return; }
    const owned = [];
    for (const f of rec.files) if (f.mode === "owned" && (await st.io.read(f.path)) != null) owned.push(f.path);
    const kept = rec.files.filter(f => f.mode !== "owned").length;
    const body = `${esc(plural(owned.length, "file"))} ${owned.length === 1 ? "goes" : "go"}` + (rec.views.length ? `, and ${esc(plural(rec.views.length, "view"))} ${rec.views.length === 1 ? "goes" : "go"}` : "") + "." +
      (kept ? ` ${esc(plural(kept, "note"))} you may have written in ${kept === 1 ? "stays" : "stay"}.` : "") + " What goes is copied to .neurora/backups first.";
    if (!(await ctx.NV.modal({ title: `Remove ${name}`, body, confirmText: "remove", danger: true }))) return;
    const r = await VAULT_INSTALL.remove(rec.id, st.io, { now: o.now });
    await ctx.NV.receipt(`${esc(name)} removed: ${esc(plural(r.removed.length, "file"))} gone, ${r.kept.length} kept` + (r.views.length ? `, ${esc(plural(r.views.length, "view"))} gone` : ""), null, null, { lines: r.backup ? [`backed up to ${r.backup}`] : [] });
    await again(ctx, raw);
  }

  async function writeSettings(ctx, patch, label) {
    const io = obsidianIO(ctx.app), path = (ctx.NV.settingsPath && ctx.NV.settingsPath()) || SETTINGS;
    const before = await io.read(path);
    if (!(await ctx.write(patch))) return false;
    await ctx.NV.receipt(label, path, before, {});
    return true;
  }
  async function checkSwitch(ctx, raw) {
    const on = checkOn(ctx.settings || {});
    if (await writeSettings(ctx, { store_check: on ? false : null }, on ? "The Store no longer checks when the Hall opens" : "The Store checks for new things when the Hall opens, at most once an hour"))
      await again(ctx, raw);
  }
  async function keyPress(ctx, what, i, raw) {
    const say = sayOf(ctx), keys = keysOf(ctx.settings || {});
    const tail = k => { const r = VAULT_KEYS.read(k); return maskKey(k, r.ok ? { id: String(r.payload.k) } : null); };
    let next;
    if (what === "key-remove") {
      if (!keys[i]) return;
      if (!(await ctx.NV.modal({ title: `Remove the key ${tail(keys[i])}`, body: "What it covers stays installed; an update to any of it asks for a key again.", confirmText: "remove", danger: true }))) return;
      next = keys.filter((_, j) => j !== i);
    } else {
      const change = what === "key-change" && keys[i] != null, first = !keys.length;
      const r = await ctx.NV.modal({ title: change ? `Change the key ${tail(keys[i])}` : first ? "Add a key" : "Add another key",
        body: first ? "Only your keys and the item asked for are sent to the Store, and never anything about this vault's notes." : "",
        fields: [{ value: change ? keys[i] : "", placeholder: "the key from your email" }], confirmText: change ? "change" : "add" });
      if (!r) return;
      const text = String(r[0] || "").replace(/\s+/g, "");
      const k = VAULT_KEYS.accepts(text);
      if (!k.ok) { say(`That ${esc(k.why)}`); return; }
      if (keys.includes(text)) { say("That key is here already"); return; }
      next = change ? keys.map((x, j) => j === i ? text : x) : keys.concat(text);
    }
    const label = what === "key-remove" ? "The key was removed from Vault Settings" : `The key ${esc(tail(next[what === "key-change" ? i : next.length - 1]))} was written to Vault Settings`;
    if (await writeSettings(ctx, { store_keys: next.length ? next : null }, label)) await draw(ctx, raw);
  }

  return { obsidianIO, sections, pressFor, countFor, maskKey, catalogueCache, draw, boot, act, install: VAULT_INSTALL, keys: VAULT_KEYS };
})();
```

```css
.st-page { max-width: 1120px; margin: 0 auto; padding: calc(8px * var(--c-scale)) 0 calc(40px * var(--c-scale));
  display: flex; flex-direction: column; gap: calc(34px * var(--c-scale)); }
.st-page .vc-plate { margin: 0; }
.st-lbl { font-family: var(--c-mono); font-size: var(--c-small); color: var(--c-dim); }
.st-ver { font-family: var(--c-mono); font-size: var(--c-small); color: var(--c-dim); }
.st-why { color: var(--c-dim); font-style: italic; }
.st-hint { font-size: var(--c-small); color: var(--c-fnt); }

.st-title { font-family: var(--f-title, var(--f-display)); font-style: italic; font-weight: var(--lp-pv-t-weight, 400);
  text-transform: var(--lp-pv-t-case, none); letter-spacing: var(--lp-pv-t-track, -.015em); line-height: 1.02; color: var(--c-bright); margin: 0; }

.st-hero { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 14px calc(28px * var(--c-scale)); align-items: end; }
.st-h1 { font-size: calc(var(--c-hero) * 1.32); text-wrap: balance; }
.st-lede { grid-column: 1; margin: 0; max-width: 60ch; font-size: calc(var(--c-body) * 1.08); line-height: 1.6; color: var(--c-dim); }
.st-status { grid-column: 1; display: flex; align-items: baseline; gap: 8px; font-size: var(--c-small); color: var(--c-dim); }
.st-again { grid-column: 2; grid-row: 1 / span 3; align-self: end; }
.st-dot { flex: none; width: 8px; height: 8px; border-radius: var(--r-pill); background: var(--c-green); transform: translateY(-1px);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--c-green) 22%, transparent); }
.st-dot--due { background: var(--c-a); box-shadow: 0 0 0 3px color-mix(in srgb, var(--c-a) 22%, transparent); }
.st-dot--off { background: var(--c-red); box-shadow: 0 0 0 3px color-mix(in srgb, var(--c-red) 22%, transparent); }

.st-keys { display: flex; align-items: center; flex-wrap: wrap; gap: 12px calc(22px * var(--c-scale)); padding: calc(16px * var(--c-scale)) calc(22px * var(--c-scale));
  border: var(--hair-w, 1px) dashed var(--c-border); border-radius: var(--r-focal); }
.st-keys > .st-title { font-size: var(--c-fig); flex: none; }
.st-key-list { display: flex; flex-direction: column; gap: 6px; flex: 1 1 320px; min-width: 0; }
.st-key { display: flex; align-items: center; flex-wrap: wrap; gap: 4px 12px; min-width: 0; }
.st-key .st-k { min-width: 0; flex: 1 1 auto; }
.st-key b { color: var(--c-bright); font-weight: 600; }
.st-key .vc-sub { display: block; font-size: var(--c-small); color: var(--c-dim); }
.st-keys .vc-ib { flex: 0 0 auto; }

.st-band { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 12px; margin: 0; font-size: var(--c-small); color: var(--c-dim); }
.st-band .vc-tag { padding: 3px 10px; border-radius: var(--r-pill); background: color-mix(in srgb, var(--c-a) 16%, transparent); color: var(--c-a); font-weight: 600; }

.st-sec-h { display: flex; align-items: baseline; flex-wrap: wrap; gap: 6px var(--c-gap); margin: 0 0 calc(16px * var(--c-scale)); }
.st-sec-h .st-title { font-size: calc(var(--c-fig) * 1.15); }
.st-sec-h small { font-size: var(--c-small); color: var(--c-fnt); }
.st-sec-h .vc-ib { margin-left: auto; align-self: center; }
.st-block .st-sec-h .st-title { font-size: var(--c-fig); }

.st-offers { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr)); gap: calc(18px * var(--c-scale)); align-items: stretch; }
.st-offer { position: relative; display: flex; flex-direction: column; gap: 10px; min-width: 0; padding: calc(24px * var(--c-scale)) calc(24px * var(--c-scale)) calc(22px * var(--c-scale));
  border-radius: var(--r-focal); border: var(--hair-w, 1px) solid var(--c-border); background: var(--c-plate); overflow: hidden; }
.st-offer > .st-title { font-size: var(--c-fig); padding-right: 96px; }
.st-tag { position: absolute; top: calc(22px * var(--c-scale)); right: calc(22px * var(--c-scale)); font-size: var(--c-small); font-weight: 600; color: var(--c-a); }
.st-tag--good { color: var(--c-green); }
.st-offer--rec { border: calc(var(--hair-w, 1px) * 1.5) solid color-mix(in srgb, var(--c-a) 65%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--c-a) 12%, transparent), 0 30px 70px -45px color-mix(in srgb, var(--c-a) 55%, transparent); }
.st-offer--passes { border-style: dashed; background: transparent; }
.st-offer--life { background:
  radial-gradient(90% 70% at 100% 0, color-mix(in srgb, var(--c-blue) 22%, transparent), transparent 70%),
  radial-gradient(80% 70% at 0 100%, color-mix(in srgb, var(--c-green) 16%, transparent), transparent 70%),
  radial-gradient(70% 60% at 30% 10%, color-mix(in srgb, var(--c-a) 18%, transparent), transparent 70%), var(--c-plate); }

.st-amt { display: flex; align-items: baseline; flex-wrap: wrap; gap: 0 8px; margin: 0; }
.st-amt b { font-family: var(--f-title, var(--f-display)); font-weight: 300; font-size: calc(var(--c-hero) * 1.4); line-height: .95; color: var(--c-bright); letter-spacing: -.02em; }
.st-amt .st-per { font-size: var(--c-body); color: var(--c-dim); }
.st-amt small { flex-basis: 100%; margin-top: 6px; font-size: var(--c-small); color: var(--c-fnt); }
.st-amt--have b { font-size: var(--c-hero); }
.st-once { margin: 0; font-size: var(--c-small); color: var(--c-dim); }
.st-ticks { list-style: none; margin: 4px 0 0; padding: 0; display: flex; flex-direction: column; gap: 9px; }
.st-ticks li { position: relative; padding-left: 28px; color: var(--c-tx); line-height: 1.4; }
.st-ticks li::before, .st-assure span::before { content: ""; position: absolute; left: 3px; top: .38em; width: 11px; height: 5.5px;
  border-left: 1.7px solid var(--c-a); border-bottom: 1.7px solid var(--c-a); transform: rotate(-45deg); }
.st-fine { margin: auto 0 0; padding-top: 6px; font-size: var(--c-small); line-height: 1.5; color: var(--c-fnt); }
.st-acts { display: flex; flex-direction: column; gap: 8px; margin-top: auto; padding-top: 10px; }
.st-acts .vc-ib { width: 100% !important; justify-content: center !important; }

.st-plist { list-style: none; margin: 4px 0 0; padding: 0; display: flex; flex-direction: column; }
.st-plist li { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 2px 14px; align-items: baseline; padding: 11px 0; border-top: var(--hair-w, 1px) solid var(--c-hair); }
.st-plist li:first-child { border-top: 0; padding-top: 4px; }
.st-plist b { font-weight: 600; color: var(--c-bright); }
.st-plist .vc-sub { grid-column: 1; font-size: var(--c-small); color: var(--c-dim); }
.st-plist .st-amt { grid-column: 2; grid-row: 1 / span 2; justify-content: flex-end; text-align: right; }
.st-plist .st-amt b { font-size: calc(var(--c-lead) * 1.25); font-weight: 400; }
.st-plist .st-amt .st-per { font-size: var(--c-small); }
.st-plist .st-amt small { margin-top: 0; }
.st-plist .vc-ib { grid-column: 1 / -1; justify-self: start; }

.st-assure { display: flex; justify-content: center; flex-wrap: wrap; gap: 8px 26px; margin: calc(-12px * var(--c-scale)) 0 0; font-size: var(--c-small); color: var(--c-dim); }
.st-assure span { position: relative; padding-left: 22px; }
.st-assure span::before { top: .45em; left: 2px; width: 9px; height: 4.5px; }

.st-cmp-w { overflow-x: auto; }
.st-cmp { width: 100%; min-width: 560px; border-collapse: collapse; font-size: var(--c-small); }
.st-cmp th, .st-cmp td { padding: 12px 10px; border-bottom: var(--hair-w, 1px) solid var(--c-hair); text-align: center; vertical-align: middle; }
.st-cmp thead th { font-weight: 600; color: var(--c-bright); border-bottom-color: var(--c-border); }
.st-cmp tbody th { text-align: left; font-weight: 500; color: var(--c-tx); width: 30%; }
.st-cmp .st-on { background: color-mix(in srgb, var(--c-a) 7%, transparent); }
.st-cmp td small { display: block; color: var(--c-fnt); }
.st-yes { display: inline-block; width: 12px; height: 6px; border-left: 1.8px solid var(--c-a); border-bottom: 1.8px solid var(--c-a); transform: translateY(-2px) rotate(-45deg); }
.st-no { color: var(--c-fnt); }

.st-pic { position: relative; display: block; width: 100%; height: 100%; min-height: 0; overflow: hidden;
  background: color-mix(in srgb, var(--c-tx) 5%, var(--c-bg)); }
.st-pic img { display: block; width: 100%; height: 100%; object-fit: cover; object-position: 0 0; transition: transform 1.2s cubic-bezier(.2, .7, .1, 1); }
.st-pic--gone img { display: none; }
.st-pic--none, .st-pic--gone {
  background: repeating-linear-gradient(135deg, transparent 0 12px, color-mix(in srgb, var(--c-tx) 5%, transparent) 12px 13px),
    radial-gradient(60% 80% at 50% 40%, color-mix(in srgb, var(--c-a) 9%, transparent), transparent 70%), var(--c-bg); }
.st-ph { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;
  color: var(--c-fnt); font-size: var(--c-small); }
.st-ph-mark { display: grid; place-items: center; width: 46px; height: 46px; border-radius: var(--r-pill); border: 1px dashed var(--c-border);
  background: color-mix(in srgb, var(--c-plate) 70%, transparent); }
.st-ph-mark svg { width: 20px; height: 20px; }

.st-tiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 250px), 1fr)); gap: calc(18px * var(--c-scale)); }
.st-tile { display: flex; flex-direction: column; min-width: 0; overflow: hidden; border-radius: var(--r-plate);
  border: var(--hair-w, 1px) solid var(--c-border); background: var(--c-plate); }
.st-tile.is-on { border-color: color-mix(in srgb, var(--c-a) 65%, transparent); }
.st-tile .st-shot { aspect-ratio: 16 / 9; border-bottom: var(--hair-w, 1px) solid var(--c-hair); }
.st-tile:hover .st-pic img { transform: scale(1.03); }
.st-tile-b { display: flex; align-items: center; flex-wrap: wrap; gap: 6px 10px; padding: calc(14px * var(--c-scale)) calc(16px * var(--c-scale)); }
.st-tile-b .st-title { font-size: var(--c-lead); flex: 1 1 auto; }
.st-tile-b .st-sub { flex-basis: 100%; font-size: var(--c-small); color: var(--c-dim); }
.st-tile-b .vc-ib { flex: 0 0 auto; }

.st-offer .st-seeadds { align-self: flex-start !important; }
.st-adds { margin-top: calc(26px * var(--c-scale)); }
.st-adds[hidden] { display: none !important; }
.st-adds-lite { margin: calc(-6px * var(--c-scale)) 0 calc(18px * var(--c-scale)); max-width: 75ch; font-size: var(--c-small); line-height: 1.55; color: var(--c-dim); }
.st-adds-lite b { color: var(--c-tx); font-weight: 600; }
.st-adds-g { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 420px), 1fr)); gap: calc(22px * var(--c-scale)); align-items: start; }
.st-add { display: flex; flex-direction: column; gap: 12px; min-width: 0; margin: 0; }
.st-add-shot { display: grid; gap: 8px; overflow: hidden; border-radius: var(--r-plate); box-shadow: 0 0 0 1px var(--c-hair); }
.st-add-shot--two { grid-template-columns: 1fr 1fr; }
.st-add-shot .st-pic { height: auto; }
.st-add-shot .st-pic img { height: auto; }
.st-add-shot--two .st-pic { aspect-ratio: 2 / 1; }
.st-add-shot--two .st-pic img { height: 100%; }
.st-add-shot--none .st-pic, .st-add-shot .st-pic--gone { aspect-ratio: 2 / 1; }
.st-add figcaption { display: flex; flex-direction: column; gap: 5px; }
.st-add figcaption .st-title { font-size: var(--c-lead); }
.st-add figcaption .vc-sub { font-size: var(--c-small); line-height: 1.5; color: var(--c-dim); }

.st-lines { border: var(--hair-w, 1px) solid var(--c-border); border-radius: var(--r-plate); overflow: hidden; }
.st-line { display: grid; grid-template-columns: 64px minmax(0, 1fr) auto auto; gap: 4px 18px; align-items: center; padding: 14px 18px; border-top: var(--hair-w, 1px) solid var(--c-hair); }
.st-line:first-child { border-top: 0; }
.st-line > .st-thumb { grid-row: 1 / span 2; }
.st-line .st-name { display: flex; align-items: baseline; flex-wrap: wrap; gap: 4px 10px; }
.st-line .st-name b { font-weight: 600; color: var(--c-bright); }
.st-line .vc-sub { grid-column: 2; font-size: var(--c-small); color: var(--c-dim); display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.st-line .st-end { grid-column: 3; grid-row: 1 / span 2; text-align: right; }
.st-line .st-end .st-amt { justify-content: flex-end; }
.st-line .st-end .st-amt b { font-size: var(--c-lead); font-weight: 400; }
.st-line .st-end .st-amt small { margin-top: 0; }
.st-line .st-when { display: block; font-size: var(--c-small); color: var(--c-a); }
.st-line > .vc-ib, .st-line > .vc-tag { grid-column: 4; grid-row: 1 / span 2; }
.st-thumb { width: 64px; aspect-ratio: 2 / 1; overflow: hidden; border-radius: var(--r-tight); box-shadow: 0 0 0 1px var(--c-hair); }
.st-thumb .st-ph-mark { width: 22px; height: 22px; border: 0; background: none; }
.st-thumb .st-ph-mark svg { width: 13px; height: 13px; }
.st-none { margin: 0; }

.st-foot { display: flex; align-items: center; flex-wrap: wrap; gap: 10px var(--c-gap); padding: 0 calc(6px * var(--c-scale)); color: var(--c-fnt); }
.st-foot-w { font-size: var(--c-small); }
.st-site { margin-left: auto; font-size: var(--c-small); color: var(--c-a); }

[data-cols="narrow"] .st-hero { grid-template-columns: minmax(0, 1fr); }
[data-cols="narrow"] .st-again { grid-column: 1; grid-row: auto; justify-self: start; }
[data-cols="narrow"] .st-h1 { font-size: var(--c-hero); }
[data-cols="narrow"] .st-offers { grid-template-columns: minmax(0, 1fr); }
[data-cols="narrow"] .st-offer > .st-amt b { font-size: var(--c-hero); }
[data-cols="narrow"] .st-line { grid-template-columns: minmax(0, 1fr) auto; }
[data-cols="narrow"] .st-line > .st-thumb { display: none; }
[data-cols="narrow"] .st-line .vc-sub, [data-cols="narrow"] .st-line .st-name { grid-column: 1; }
[data-cols="narrow"] .st-line .st-end { grid-column: 2; grid-row: 1; }
[data-cols="narrow"] .st-line > .vc-ib, [data-cols="narrow"] .st-line > .vc-tag { grid-column: 1 / -1; grid-row: auto; justify-self: start; }
[data-cols="narrow"] .st-keys { padding: 14px; }
```
