const PERMANENT = "01_Zettelkasten/Permanent";
const SKIP = /^(Daily|99_Meta|\.trash)\//;

const norm = s => String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const words = s => norm(s).split(" ").filter(w => w.length > 2);

function candidates(app, exceptPath) {
  return app.vault.getMarkdownFiles()
    .filter(f => !SKIP.test(f.path) && f.path !== exceptPath)
    .map(f => {
      const fm = app.metadataCache.getFileCache(f)?.frontmatter || {};
      const a = fm.aliases ?? fm.alias ?? [];
      const aliases = (Array.isArray(a) ? a : String(a).split(",")).map(x => String(x).trim()).filter(Boolean);
      const folder = f.parent && f.parent.path && f.parent.path !== "/" ? f.parent.path : "";
      return { file: f, name: f.basename, aliases, folder };
    });
}

function score(phrase, c) {
  const p = norm(phrase), pw = words(phrase);
  let best = { score: 0, via: "" };
  for (const [label, isAlias] of [[c.name, false], ...c.aliases.map(a => [a, true])]) {
    const l = norm(label);
    if (!l || !p) continue;
    let s = 0;
    if (l === p) s = 100;
    else if (l.length >= 3 && (l.startsWith(p) || p.startsWith(l))) s = 80;
    else if (l.length >= 3 && (l.includes(p) || p.includes(l))) s = 60;
    else {
      const lw = words(label), shared = pw.filter(w => lw.includes(w)).length;
      const union = new Set([...pw, ...lw]).size;
      if (shared && union) s = Math.round(50 * shared / union);
    }
    if (s > best.score) best = { score: s, via: isAlias ? label : "" };
  }
  return best;
}

function rank(phrase, cands) {
  return cands.map(c => ({ c, ...score(phrase, c) }))
    .sort((a, b) => b.score - a.score || a.c.name.length - b.c.name.length || a.c.name.localeCompare(b.c.name));
}

function titleOf(words) {
  return String(words)
    .replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, (_, t, a) => a)
    .replace(/\[\[([^\]]+)\]\]/g, (_, t) => t)
    .replace(/[#*"/\\<>:|[\]?^]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[. ]+$/, "")
    .slice(0, 120);
}

function choices(phrase, cands) {
  const ranked = rank(phrase, cands);
  const strong = ranked.filter(r => r.score >= 60), weak = ranked.filter(r => r.score > 0 && r.score < 60);
  const rest = ranked.filter(r => r.score === 0).sort((a, b) => a.c.name.localeCompare(b.c.name));
  const title = titleOf(phrase);
  const fresh = title && !cands.some(c => c.name.toLowerCase() === title.toLowerCase()) ? [{ isNew: true, title }] : [];
  return strong.length ? [...strong, ...fresh, ...weak, ...rest] : [...fresh, ...weak, ...rest];
}
const label = it => it.isNew
  ? `＋ New permanent note: ${it.title}`
  : `${it.c.name}${it.via ? `   ·  "${it.via}"` : ""}   ·  ${it.c.folder || "vault root"}`;

async function link(params) {
  const { app, quickAddApi } = params;
  const obs = params.obsidian || {};
  const Notice = obs.Notice || globalThis.Notice || function (m) { console.log(m); };
  const view = obs.MarkdownView ? app.workspace.getActiveViewOfType(obs.MarkdownView) : app.workspace.activeLeaf?.view;
  if (!view || !view.editor || (view.getMode && view.getMode() === "preview")) { new Notice("Link works in a note you are editing"); return; }
  const ed = view.editor;
  const sel = ed.getSelection();
  if (!sel.trim() || sel.includes("\n")) { new Notice("Select the words to link — on one line"); return; }
  if (/^\s*\[\[[^\]]*\]\]\s*$/.test(sel)) { new Notice("that is already a link"); return; }
  const phrase = sel.trim();
  const source = view.file ? view.file.path : "";

  const items = choices(phrase, candidates(app, source));
  const pick = await quickAddApi.suggester(items.map(label), items);
  if (!pick) return;

  let file = pick.isNew ? app.vault.getMarkdownFiles().find(f => f.basename.toLowerCase() === pick.title.toLowerCase()) : pick.c.file;
  let made = false;
  if (!file) {
    const now = window.moment();
    if (!app.vault.getAbstractFileByPath(PERMANENT)) await app.vault.createFolder(PERMANENT);
    file = await app.vault.create(`${PERMANENT}/${pick.title}.md`, [
      "---", `id: ${now.format("YYYYMMDDHHmmss")}`, `created: ${now.format("YYYY-MM-DD HH:mm")}`,
      "type: permanent", "tags:", "  - permanent", "---", `# ${pick.title}`, "", "",
    ].join("\n"));
    made = true;
  }
  const alias = phrase === file.basename ? undefined : phrase;
  const text = app.fileManager && app.fileManager.generateMarkdownLink
    ? app.fileManager.generateMarkdownLink(file, source, undefined, alias)
    : `[[${file.basename}${alias ? "|" + alias : ""}]]`;
  ed.replaceSelection(text);
  new Notice(made ? `new permanent note — ${file.basename}` : `linked to ${file.basename}`);
}

module.exports = link;
module.exports.candidates = candidates;
module.exports.score = score;
module.exports.rank = rank;
module.exports.choices = choices;
module.exports.titleOf = titleOf;
