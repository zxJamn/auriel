---
type: vault-chrome
---

# Vault Chrome

The shared design system for **every** custom view in this vault, not just the Nutrition Matrix.
Tabs, plates, buttons, rings, the disclosure marks, the mobile rules and the per-note accent
system all live here. A view declares what kind of note it is with `data-kind` and inherits the
rest.

Views load and inject this themselves at boot, the same way they load the engine -- one source, no
drift, nothing extra to install.

**Do not edit this block by hand.** It is replaced whole whenever the vault's code is updated, so
anything typed here is lost.

```css
.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy,
.vc-pop, .vc-cmd, .nm-swapov, .nm-modal, .fv-modal, .vc-toast, .fv-toast,
.nm-toast, .fv-cook, .dn-room, .dn-now-ov, .md-peek,
.vc-host,
.vc-scroller {
  --bg:         var(--lp-bg, #0c0a08);
  --bg-1:       var(--lp-bg-1, #120f0b);
  --bg-2:       var(--lp-bg-2, #14110d);
  --bg-3:       var(--lp-bg-3, #1f1913);
  --bg-4:       var(--lp-bg-4, #2b2219);
  --ink:        var(--lp-ink, #060503);
  --tx:         var(--lp-tx, #e8e0d2);
  --bright:     var(--lp-bright, #f6efe2);
  --dim:        var(--lp-dim, #a89a84);
  --fnt:        var(--lp-fnt, #857a6a);
  --light:      var(--lp-light, #fff0da);
  --a:          var(--lp-a, #cfa668);
  --a-hi:       var(--lp-a-hi, #e2c48d);
  --a-lo:       var(--lp-a-lo, #b98f52);
  --a-pale:     var(--lp-a-pale, #efdcb4);
  --on-a:       var(--lp-on-a, #141008);
  --lamp:       var(--lp-lamp, #cfa668);
  --a-kitchen:  var(--lp-a-kitchen, var(--lp-a, #cfa668));
  --eaten:      var(--lp-eaten, var(--a));
  --moon:       var(--lp-moon, #c4cfd2);
  --moon-hi:    var(--lp-moon-hi, #e4ebee);
  --moon-lo:    var(--lp-moon-lo, #8d9a9f);
  --planned:    var(--lp-planned, #93a8c9);
  --planned-lo: var(--lp-planned-lo, #4f6180);
  --reached:    var(--lp-reached, #94b184);
  --over:       var(--lp-over, #c07a72);
  --over-hi:    var(--lp-over-hi, #e8b7ae);
  --over-bg:    var(--lp-over-bg, #3a1512);
  --unsure:     var(--lp-unsure, #cca466);
  --water:      var(--lp-water, #7fb2d9);
  --water-hi:   var(--lp-water-hi, #9fd0ec);
  --water-lo:   var(--lp-water-lo, #5b93bd);
  --water-pale: var(--lp-water-pale, #c9d6ea);
  --drink-1:    var(--lp-drink-1, #a98cd9);
  --drink-2:    var(--lp-drink-2, #8fbf7a);
  --drink-3:    var(--lp-drink-3, #5cc2b6);
  --drink-4:    var(--lp-drink-4, #e0925f);
  --drink-5:    var(--lp-drink-5, #d97b93);
  --tint-dawn:  var(--lp-tint-dawn, #e0a878);
  --tint-day:   var(--lp-tint-day, var(--a));
  --tint-dusk:  var(--lp-tint-dusk, #cc8e58);
  --tint-night: var(--lp-tint-night, #b98189);
  --tint:       var(--a);
  --border:     color-mix(in srgb, var(--a) var(--lp-wash-border, 18%), transparent);
  --hair:       color-mix(in srgb, var(--a) var(--lp-wash-hair, 8%), transparent);
  --plate:      color-mix(in srgb, var(--a) var(--lp-wash-plate, 2.8%), transparent);
  --tile:       color-mix(in srgb, var(--a) var(--lp-wash-tile, 5%), transparent);
  --tile-hi:    color-mix(in srgb, var(--bright) var(--lp-wash-tile-hi, 6%), transparent);
  --af:         color-mix(in srgb, var(--a) var(--lp-wash-af, 10%), transparent);
  --glow:       0 0 var(--lp-glow-size, 18px) color-mix(in srgb, var(--a) var(--lp-wash-glow, 20%), transparent);

  --f-text:     var(--lp-f-text, "Satoshi", "Manrope", system-ui, "Segoe UI", sans-serif);
  --f-label:    var(--lp-f-label, "Satoshi", "Manrope", system-ui, "Segoe UI", sans-serif);
  --f-display:  var(--lp-f-display, "Fraunces", "Iowan Old Style", Georgia, serif);
  --f-title:    var(--lp-f-title, var(--f-display));
  --r-focal:    var(--lp-r-focal, 18px);
  --r-plate:    var(--lp-r-plate, 16px);
  --r-item:     var(--lp-r-item, 12px);
  --r-soft:     var(--lp-r-soft, 10px);
  --r:          var(--lp-r, 5px);
  --r-tight:    var(--lp-r-tight, 3px);
  --r-hair:     var(--lp-r-hair, 2px);
  --r-pill:     var(--lp-r-pill, 999px);
  --sh-1:       var(--lp-sh-1, 0 1px 2px rgba(0,0,0,.30), 0 6px 18px rgba(0,0,0,.20));
  --sh-2:       var(--lp-sh-2, 0 2px 5px rgba(0,0,0,.34), 0 14px 34px rgba(0,0,0,.34));
  --sh-3:       var(--lp-sh-3, 0 8px 18px rgba(0,0,0,.42), 0 30px 80px rgba(0,0,0,.62));
  --lit:        var(--lp-lit, inset 0 1px 0 var(--tile-hi));
  --hair-w:     var(--lp-hair-w, 1px);
  --label-case: var(--lp-label-case, none);
  --trk-label:  var(--lp-trk-label, .01em);
  --trk-head:   var(--lp-trk-head, .04em);
  --t:          var(--lp-t, 220ms cubic-bezier(.2,.8,.2,1));
  --slow:       var(--lp-slow, 900ms cubic-bezier(.2,.8,.3,1));
  --plate-art:  var(--lp-plate-art, none);
  --title-art:  var(--lp-title-art, none);
  --title-art-h: var(--lp-title-art-h, 0px);
  --title-art-gap: var(--lp-title-art-gap, 0px);
  --table-grain: var(--lp-table-grain, url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1600' height='900' viewBox='0 0 1600 900' preserveAspectRatio='none'><filter id='w' x='0' y='0' width='1' height='1'><feTurbulence type='fractalNoise' baseFrequency='.0024 .085' numOctaves='4' seed='11' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .80  0 0 0 0 .54  0 0 0 0 .33  .2 0 0 0 -.05'/></filter><rect width='100%' height='100%' filter='url(%23w)'/></svg>"));
  font-synthesis: var(--lp-f-synthesis, weight style small-caps);

  --c-bg: var(--bg); --c-a: var(--a); --c-tx: var(--tx); --c-bright: var(--bright);
  --c-dim: var(--dim); --c-fnt: var(--fnt);
  --c-red: var(--over); --c-green: var(--reached); --c-amber: var(--unsure); --c-blue: var(--planned);
  --c-border: var(--border); --c-hair: var(--hair); --c-plate: var(--plate);
  --c-serif: var(--f-text); --c-mono: var(--f-label); --c-t: var(--t); --c-slow: var(--slow);

  --c-scale:   1;
  --c-gap:     calc(14px * var(--c-scale));
  --c-row:     calc(9px * var(--c-scale));

  --c-nano:    calc(11px * var(--c-scale));
  --c-micro:   calc(12px * var(--c-scale));
  --c-small:   calc(14px * var(--c-scale));
  --c-body:    calc(16px * var(--c-scale));
  --c-lead:    calc(20px * var(--c-scale));
  --c-fig:     calc(31px * var(--c-scale));
  --c-hero:    calc(46px * var(--c-scale));
}

.nm-h1::after, .dn-date::after {
  content: ""; display: block; height: var(--title-art-h); margin-top: var(--title-art-gap);
  background: var(--title-art);
}

[data-hour="dawn"]  { --tint: var(--tint-dawn); }
[data-hour="day"]   { --tint: var(--tint-day); }
[data-hour="dusk"]  { --tint: var(--tint-dusk); }
[data-hour="night"] { --tint: var(--tint-night); }

[data-room="kitchen"] {
  --a: var(--a-kitchen); --a-hi: var(--lp-kitchen-a-hi, var(--lp-a-hi, #e2c48d));
  --tx: var(--lp-kitchen-tx, var(--lp-tx, #e8e0d2)); --bright: var(--lp-kitchen-bright, var(--lp-bright, #f6efe2));
  --dim: var(--lp-kitchen-dim, var(--lp-dim, #a89a84)); --fnt: var(--lp-kitchen-fnt, var(--lp-fnt, #857a6a));
  --bg-1: var(--lp-kitchen-bg-1, var(--lp-bg-1, #120f0b)); --bg-2: var(--lp-kitchen-bg-2, var(--lp-bg-2, #14110d));
  --bg-3: var(--lp-kitchen-bg-3, var(--lp-bg-3, #1f1913)); --bg-4: var(--lp-kitchen-bg-4, var(--lp-bg-4, #2b2219));
  --walnut: var(--lp-kitchen-walnut, #120d09);
  --water: var(--lp-kitchen-water, var(--lp-water, #7fb2d9));
  --border: color-mix(in srgb, var(--a) 22%, transparent);
  --hair:   color-mix(in srgb, var(--a) 10%, transparent);
  --tile:   color-mix(in srgb, var(--a) 6%, transparent);
  --plate:  color-mix(in srgb, var(--a) 3%, transparent);
}

[data-room="study"] {
  --a: var(--moon); --a-hi: var(--moon-hi); --a-lo: var(--moon-lo);
  --eaten: var(--lp-study-eaten, var(--lp-eaten, var(--lp-a, #cfa668)));
  --border: color-mix(in srgb, var(--a) 20%, transparent);
  --hair:   color-mix(in srgb, var(--a) 9%, transparent);
  --tile:   color-mix(in srgb, var(--a) 5%, transparent);
  --plate:  color-mix(in srgb, var(--a) 3%, transparent);
  --glow:   0 0 18px color-mix(in srgb, var(--eaten) 20%, transparent);
}

[data-room="picture-house"] {
  --a: var(--lp-house-a, var(--lp-a, #cfa668)); --a-hi: var(--lp-house-a-hi, var(--lp-a-hi, #e2c48d));
  --a-lo: var(--lp-house-a-lo, var(--lp-a-lo, #b98f52)); --a-pale: var(--lp-house-a-pale, var(--lp-a-pale, #efdcb4));
  --velvet: var(--lp-velvet, color-mix(in oklab, var(--over) 52%, var(--bg-3))); --velvet-hi: var(--lp-velvet-hi, var(--over));
  --velvet-lo: var(--lp-velvet-lo, color-mix(in oklab, var(--over) 22%, var(--bg)));
  --pool: color-mix(in srgb, var(--velvet) 28%, transparent);
  --bg: var(--lp-house-bg, var(--lp-bg, #0c0a08)); --bg-1: var(--lp-house-bg-1, var(--lp-bg-1, #120f0b)); --bg-2: var(--lp-house-bg-2, var(--lp-bg-2, #14110d));
  --bg-3: var(--lp-house-bg-3, var(--lp-bg-3, #1f1913)); --bg-4: var(--lp-house-bg-4, var(--lp-bg-4, #2b2219));
  --border: color-mix(in srgb, var(--a) 20%, transparent);
  --hair:   color-mix(in srgb, var(--a) 9%, transparent);
  --tile:   color-mix(in srgb, var(--a) 5.5%, transparent);
  --plate:  color-mix(in srgb, var(--a) 3%, transparent);
  --glow:   0 0 18px color-mix(in srgb, var(--a) 24%, transparent);
}

[data-room="small-screen"] {
  --a: var(--lp-house-a, var(--lp-a, #cfa668)); --a-hi: var(--lp-house-a-hi, var(--lp-a-hi, #e2c48d));
  --a-lo: var(--lp-house-a-lo, var(--lp-a-lo, #b98f52)); --a-pale: var(--lp-house-a-pale, var(--lp-a-pale, #efdcb4));
  --velvet: var(--lp-tube, color-mix(in oklab, var(--water) 46%, var(--bg-3))); --velvet-hi: var(--lp-tube-hi, var(--water));
  --velvet-lo: var(--lp-tube-lo, color-mix(in oklab, var(--water) 18%, var(--bg)));
  --pool: color-mix(in srgb, var(--velvet) 26%, transparent);
  --bg: var(--lp-house-bg, var(--lp-bg, #0c0a08)); --bg-1: var(--lp-house-bg-1, var(--lp-bg-1, #120f0b)); --bg-2: var(--lp-house-bg-2, var(--lp-bg-2, #14110d));
  --bg-3: var(--lp-house-bg-3, var(--lp-bg-3, #1f1913)); --bg-4: var(--lp-house-bg-4, var(--lp-bg-4, #2b2219));
  --border: color-mix(in srgb, var(--a) 20%, transparent);
  --hair:   color-mix(in srgb, var(--a) 9%, transparent);
  --tile:   color-mix(in srgb, var(--a) 5.5%, transparent);
  --plate:  color-mix(in srgb, var(--a) 3%, transparent);
  --glow:   0 0 18px color-mix(in srgb, var(--a) 24%, transparent);
}

[data-room="lecture-theatre"] {
  --slate: var(--lp-theatre-slate, color-mix(in oklab, var(--moon-lo) 45%, var(--bg-4))); --slate-hi: var(--lp-theatre-slate-hi, var(--moon));
  --slate-lo: var(--lp-theatre-slate-lo, color-mix(in oklab, var(--moon-lo) 12%, var(--bg)));
  --pool: color-mix(in srgb, var(--slate) 24%, transparent);
  --ruling: color-mix(in srgb, var(--slate-hi) 8%, transparent);
  --bg: var(--lp-theatre-bg, var(--lp-bg, #0c0a08)); --bg-1: var(--lp-theatre-bg-1, var(--lp-bg-1, #120f0b)); --bg-2: var(--lp-theatre-bg-2, var(--lp-bg-2, #14110d));
  --bg-3: var(--lp-theatre-bg-3, var(--lp-bg-3, #1f1913)); --bg-4: var(--lp-theatre-bg-4, var(--lp-bg-4, #2b2219));
  --pack-1: var(--lp-theatre-pack-1, #6fa89d); --pack-2: var(--lp-theatre-pack-2, #a98bc4); --pack-3: var(--lp-theatre-pack-3, #c48a98); --pack-4: var(--lp-theatre-pack-4, #7f9fcf); --pack-5: var(--lp-theatre-pack-5, #a9a86e);
  --pack-6: var(--lp-theatre-pack-6, #c79a6f); --pack-7: var(--lp-theatre-pack-7, #8e8fd4); --pack-8: var(--lp-theatre-pack-8, #5f9db5); --pack-9: var(--lp-theatre-pack-9, #c27f6c); --pack-10: var(--lp-theatre-pack-10, #86a98f);
}

.vc-now {
  display: flex; align-items: center; gap: calc(18px * var(--c-scale));
  padding: calc(13px * var(--c-scale)) calc(30px * var(--c-scale));
  border-bottom: var(--hair-w) solid var(--c-hair);
  background: linear-gradient(180deg, color-mix(in srgb, var(--a) 4.5%, transparent), transparent);
  position: relative; overflow: hidden;
}
.vc-now::before {
  content: ""; position: absolute; left: 0; top: 0; bottom: 0; width: 2px;
  background: var(--c-a); opacity: .5;
}
.vc-now--soon::before { opacity: .85; }
.vc-now--cook {
  background: linear-gradient(180deg, color-mix(in srgb, var(--a) 13%, transparent), color-mix(in srgb, var(--a) 2%, transparent));
  border-bottom-color: var(--c-border);
}
.vc-now--cook::before { width: 3px; opacity: 1; }
.vc-now--done::before { background: var(--c-green); }
.vc-now-lead {
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold;
  letter-spacing: var(--trk-head); text-transform:var(--label-case); color: var(--c-a);
  flex: 0 0 auto; padding-left: 2px;
}
.vc-now--done .vc-now-lead { color: var(--c-green); }
.vc-now-line {
  font-family: var(--f-display); font-style: italic; font-size: var(--c-lead);
  color: var(--c-bright); flex: 1 1 auto; min-width: 0;
  white-space: normal; line-height: 1.35;
}
.vc-now-meta {
  font-family: var(--c-mono); font-size: var(--c-micro);
  letter-spacing: .06em; color: var(--c-dim); flex: 0 0 auto;
}
.vc-now-go {
  border: var(--hair-w) solid var(--c-border) !important; background: transparent !important;
  box-shadow: none !important; outline: none !important; cursor: pointer;
  padding: calc(4px * var(--c-scale)) calc(13px * var(--c-scale)) calc(5px * var(--c-scale));
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-dim);
  transition: color var(--c-t), border-color var(--c-t); flex: 0 0 auto;
}
.vc-now-go:hover { color: var(--c-a); border-color: var(--c-a) !important; }
.vc-now-rest { display: flex; gap: 20px; flex: 0 0 auto; }
.vc-now-rest span {
  font-family: var(--c-mono); font-size: var(--c-micro);
  letter-spacing: var(--trk-label); color: var(--c-fnt); white-space: nowrap;
}
.vc-now-rest b { color: var(--c-dim); font-weight: normal; }
@media (max-width: 760px) {
  .vc-now { flex-wrap: wrap; gap: 8px 14px; padding-left: 20px; padding-right: 20px; }
  .vc-now-line { flex: 1 0 100%; white-space: normal; }
  .vc-now-rest { display: none; }
}

.vc-tabs { display: flex; flex-wrap: wrap; align-items: center; gap: 2px 4px; position: relative;
  border-bottom: var(--hair-w) solid var(--hair); }
.vc-tabs::-webkit-scrollbar { display: none; }
.vc-tabs--inline { border-bottom: 0; }
.vc-tab { position: relative; display: inline-flex !important; align-items: center; gap: 0; height: 46px !important; min-height: 0 !important;
  padding: 0 11px !important; margin: 0 !important; border: 0 !important; border-radius: 0 !important; background: transparent !important;
  box-shadow: none !important; outline: none; cursor: pointer; white-space: nowrap; color: var(--fnt); transition: color var(--t); }
.vc-tab .vc-ic { display: block; flex: none; width: 20px; height: 20px; transition: color var(--t), filter var(--t); }
.vc-tab .vc-word { font-family: var(--f-display); font-style: italic; font-size: 16px; line-height: 1.25; }
.vc-tab:hover { color: var(--tx); }
.vc-tabs > .vc-tab:first-child { padding-inline-start: 2px !important; }
.vc-tabs > .vc-tab:first-child::after { left: 0; }
.vc-tab:is([aria-current="page"], [aria-selected="true"], .vc-tab--on) { color: var(--bright); }
.vc-tab:is([aria-current="page"], [aria-selected="true"], .vc-tab--on) .vc-ic { color: var(--a); filter: drop-shadow(0 0 5px color-mix(in srgb, var(--a) 45%, transparent)); }
.vc-tab:is([aria-current="page"], [aria-selected="true"], .vc-tab--on)::after { content: ""; position: absolute; inset: auto 6px -1px; height: 2px; border-radius: 2px 2px 0 0;
  background: linear-gradient(90deg, transparent, var(--a) 18%, var(--a-hi) 50%, var(--a) 82%, transparent);
  box-shadow: 0 0 12px color-mix(in srgb, var(--a) 55%, transparent); pointer-events: none; }
.vc-tab:focus-visible { outline: none !important; color: var(--bright); text-shadow: 0 0 14px color-mix(in srgb, var(--a) 55%, transparent); }
.vc-tab-n { align-self: flex-start; margin: 10px 0 0 3px; font-family: var(--f-label); font-style: normal; font-size: 11px; line-height: 1;
  letter-spacing: var(--trk-label); color: var(--fnt); font-variant-numeric: tabular-nums; }
.vc-tab-n:empty { display: none; }
.vc-tab-n--hot { color: var(--a); }
.vc-tab-n--warn { color: var(--over); }
.vc-tabs-r { margin-left: auto; display: flex; align-items: center; gap: 12px; flex: 0 0 auto; }
.vc-tabline { display: none !important; }


.vc-b {
  border: var(--hair-w) solid var(--c-border) !important; background: transparent !important;
  box-shadow: none !important; outline: none !important; cursor: pointer;
  padding: calc(6px * var(--c-scale)) calc(15px * var(--c-scale)) calc(7px * var(--c-scale));
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-dim);
  transition: color var(--c-t), border-color var(--c-t), background var(--c-t);
}
.vc-b:hover { color: var(--c-a); border-color: var(--c-a) !important; }
.vc-b--hot { color: var(--c-a); }
.vc-b--hot:hover { color: var(--on-a); background: var(--c-a) !important; }
.vc-b--warn:hover { color: var(--c-red); border-color: var(--c-red) !important; }
.vc-b--sm { padding: 3px 10px 4px; font-size: var(--c-nano); letter-spacing: var(--trk-label); }
.vc-b--bare { border-color: transparent !important; }
.vc-b--bare:hover { border-color: var(--c-border) !important; }
.vc-b[disabled] { opacity: .4; cursor: default; }

.vc-ic {
  width: 1.2em; height: 1.2em; flex: none; display: inline-block; vertical-align: -.22em;
  fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round;
  overflow: visible; pointer-events: none; transition: filter var(--c-t), transform var(--c-t);
}
.vc-ic .f { fill: currentColor; stroke: none; }
.vc-ic .d { stroke-dasharray: 1.4 1.9; }
:is(button, a, summary):hover > .vc-ic, :is(button, a, summary):focus-visible > .vc-ic {
  filter: drop-shadow(0 0 5px color-mix(in srgb, currentColor 50%, transparent));
}
.vc-ib {
  display: inline-grid !important; place-items: center; flex: none; position: relative;
  width: 30px !important; height: 30px !important; min-width: 0 !important; min-height: 0 !important;
  padding: 0 !important; margin: 0; border: 0 !important; border-radius: 50% !important;
  background: transparent !important; box-shadow: none !important; outline: none;
  color: var(--c-fnt); cursor: pointer; font-size: 16px; line-height: 1 !important;
  transition: color var(--c-t), background var(--c-t);
}
.vc-ib.vc-ib { width: 30px !important; height: 30px !important; min-height: 0 !important; line-height: 1 !important; }
.vc-ib .vc-ic { width: 17px; height: 17px; vertical-align: 0; }
.vc-ib:hover, .vc-ib:focus-visible {
  color: var(--bright); background: color-mix(in srgb, var(--light) 7%, transparent) !important;
}
.vc-ib.vc-ib--sm { width: 24px !important; height: 24px !important; }
.vc-ib--sm .vc-ic { width: 14px; height: 14px; }
.vc-ib--warn:hover, .vc-ib--warn.is-armed { color: var(--over); }
.vc-ib.vc-ib--ring {
  width: 40px !important; height: 40px !important; color: var(--dim);
  box-shadow: inset 0 0 0 var(--hair-w) var(--border) !important;
}
.vc-ib.vc-ib--ring .vc-ic { width: 19px; height: 19px; }
.vc-ib.vc-ib--ring:hover, .vc-ib.vc-ib--ring:focus-visible { color: var(--a-hi); box-shadow: inset 0 0 0 var(--hair-w) var(--a) !important; }
.vc-ib.vc-ib--hot { color: var(--a); box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--a) 55%, transparent) !important; }
.vc-ib.vc-ib--hot:hover, .vc-ib.vc-ib--hot:focus-visible { color: var(--on-a); background: var(--a) !important; }
.vc-ib.vc-ib--gold { color: var(--eaten); box-shadow: inset 0 0 0 var(--hair-w) color-mix(in srgb, var(--eaten) 45%, transparent) !important; }
.vc-ib.vc-ib--gold:hover, .vc-ib.vc-ib--gold:focus-visible, .vc-ib.vc-ib--gold.is-on { color: var(--on-a); background: var(--eaten) !important; }
.vc-ib.is-armed {
  width: auto !important; padding: 0 10px !important; border-radius: var(--r-pill) !important;
  color: var(--over); font-family: var(--f-label); font-size: 11px; letter-spacing: var(--trk-label); text-transform: var(--label-case);
  background: color-mix(in srgb, var(--over) 10%, transparent) !important;
}
.vc-ib[disabled] { opacity: .35; pointer-events: none; }
.vc-ib[aria-pressed="true"] { color: var(--a); background: color-mix(in srgb, var(--a) 12%, transparent) !important; }
.vc-ib.vc-ib[hidden] { display: none !important; }
@media (pointer: coarse) { .vc-ib.vc-ib:not(.vc-ib--ring):not(.is-armed):not(.vc-ib--word) { width: 36px !important; height: 36px !important; } }

.vc-word {
  display: inline-block; max-width: 0; opacity: 0; margin-inline-start: 0;
  overflow: hidden; white-space: nowrap; vertical-align: middle;
  transition: max-width .4s cubic-bezier(.2,.8,.2,1), opacity .28s ease, margin .4s cubic-bezier(.2,.8,.2,1);
}
:is([aria-current="page"], [aria-selected="true"], [aria-pressed="true"], .is-on) .vc-word {
  max-width: 14em; opacity: 1; margin-inline-start: .5em; padding-inline-end: .2em;
}
@keyframes vc-word-in { from { max-width: 0; opacity: 0; margin-inline-start: 0; } }
.vc-arrive .vc-word { animation: vc-word-in .44s cubic-bezier(.2,.8,.2,1); }
.vc-ib.vc-ib--word {
  display: inline-flex !important; align-items: center; justify-content: flex-start;
  width: auto !important; min-width: 30px; padding: 0 6.5px !important; border-radius: var(--r-pill) !important;
  transition: color var(--c-t), background var(--c-t), padding .4s cubic-bezier(.2,.8,.2,1);
}
.vc-ib.vc-ib--word .vc-word {
  font-family: var(--f-label); font-size: 11px; line-height: 1; letter-spacing: var(--trk-label); text-transform: var(--label-case);
}
.vc-ib.vc-ib--word:is([aria-pressed="true"], .is-on) { padding: 0 12px 0 7px !important; }
.vc-ib.vc-ib--sm.vc-ib--word { min-width: 24px; padding: 0 5px !important; }
.vc-ib.vc-ib--sm.vc-ib--word:is([aria-pressed="true"], .is-on) { padding: 0 10px 0 5px !important; }
.vc-ib.vc-ib--sm.vc-ib--word .vc-word { font-size: 10px; }
.vc-ib.vc-ib--ring.vc-ib--word { min-width: 40px; padding: 0 10.5px !important; }
.vc-ib.vc-ib--ring.vc-ib--word:is([aria-pressed="true"], .is-on) { padding: 0 16px 0 10.5px !important; }
@media (pointer: coarse) { .vc-ib.vc-ib--word:not(.vc-ib--ring) { min-width: 36px; height: 36px !important; } }
@media (prefers-reduced-motion: reduce) {
  .vc-word, .vc-ib.vc-ib--word { transition: none; }
  .vc-arrive .vc-word { animation: none; }
}

.vc-plate {
  background: var(--plate-art), var(--c-plate); border: var(--hair-w) solid var(--c-hair);
  padding: calc(20px * var(--c-scale)) calc(24px * var(--c-scale)) calc(24px * var(--c-scale));
  margin-bottom: calc(26px * var(--c-scale));
}
.vc-label {
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-head); text-transform:var(--label-case); color: var(--c-a);
  padding-bottom: calc(11px * var(--c-scale)); margin-bottom: calc(15px * var(--c-scale));
  border-bottom: var(--hair-w) solid var(--c-hair);
  display: flex; align-items: baseline; gap: 12px;
}
.vc-label small {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-small);
  letter-spacing: 0; text-transform: none; color: var(--c-fnt); font-weight: normal; margin-left: auto;
}
.vc-label[data-coll] { cursor: pointer; user-select: none; }
.vc-label[data-coll]::after {
  content: "−"; font-family: var(--c-mono); font-size: var(--c-small); color: var(--c-fnt);
  margin-left: 12px; transition: color var(--c-t);
}
.vc-label--closed::after { content: "+"; }
.vc-label--closed { opacity: .55; }
.vc-label--closed + .vc-body { display: none; }

.vc-row {
  display: flex; align-items: baseline; gap: var(--c-gap);
  padding: var(--c-row) 0; border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 5%, transparent);
  transition: padding var(--c-t), background var(--c-t);
}
.vc-row:last-child { border-bottom: none; }
.vc-row:hover { background: color-mix(in srgb, var(--a) 2.2%, transparent); padding-left: 6px; }
.vc-row-k { font-family: var(--c-serif); font-size: var(--c-body); color: var(--c-tx); flex: 1; min-width: 0; }
.vc-row-v { font-family: var(--c-mono); font-size: var(--c-small); color: var(--c-dim); flex: 0 0 auto; }
.vc-row-v b { color: var(--c-a); font-weight: bold; }
.vc-sub {
  display: block; font-family: var(--c-mono); font-size: var(--c-micro);
  letter-spacing: .05em; color: var(--c-fnt); margin-top: 4px;
}
.vc-tag {
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); border: 1px solid currentColor;
  padding: 1px 6px 2px; color: var(--c-fnt); vertical-align: middle;
}
.vc-tag--good { color: var(--c-green); } .vc-tag--warn { color: var(--c-red); }
.vc-tag--note { color: var(--c-blue); }  .vc-tag--hot  { color: var(--c-a); }
.vc-rule { height: 1px; background: var(--c-hair); margin: calc(20px * var(--c-scale)) 0; }
.vc-orn {
  text-align: center; font-family: var(--c-serif); font-style: italic;
  color: var(--c-fnt); font-size: var(--c-body); margin: 26px 0; letter-spacing: .5em;
}

.vc-num { transition: color var(--c-t); }

@keyframes vc-shim { 0% { background-position: -280px 0; } 100% { background-position: 280px 0; } }
.vc-skel {
  height: 11px; margin: 12px 0; border-radius:var(--r-hair);
  background: linear-gradient(90deg, color-mix(in srgb, var(--a) 4%, transparent) 0%, color-mix(in srgb, var(--a) 11%, transparent) 50%, color-mix(in srgb, var(--a) 4%, transparent) 100%);
  background-size: 560px 100%; animation: vc-shim 1.5s linear infinite;
}
.vc-skel--w70 { width: 70%; } .vc-skel--w45 { width: 45%; } .vc-skel--w88 { width: 88%; }
.vc-skel--tall { height: 34px; }
.vc-skel-ring {
  width: 118px; height: 118px; border-radius:50%;
  border: 3px solid color-mix(in srgb, var(--a) 7%, transparent); border-top-color: color-mix(in srgb, var(--a) 22%, transparent);
  animation: vc-spin 1.15s linear infinite;
}
@keyframes vc-spin { to { transform: rotate(360deg); } }

.vc-empty {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  line-height: 1.75; color: var(--c-fnt); padding: calc(16px * var(--c-scale)) 0;
}
.vc-empty b { color: var(--c-a); font-style: normal; }
.vc-empty-a { margin-top: 12px; display: flex; gap: 10px; flex-wrap: wrap; }

.vc-cmd {
  position: fixed; inset: 0; z-index: 2147483000; display: none;
  background: color-mix(in srgb, var(--ink) 82%, transparent); backdrop-filter: blur(4px);
  align-items: flex-start; justify-content: center; padding: 12vh 24px 24px;
}
.vc-cmd.on { display: flex; }
.vc-cmd-card {
  width: min(680px, 100%); max-height: 68vh; display: flex; flex-direction: column;
  background: var(--c-bg); border: var(--hair-w) solid var(--c-border);
  box-shadow: var(--sh-3);
}
.vc-cmd-in {
  width: 100%; background: transparent !important; border: none !important;
  border-bottom: var(--hair-w) solid var(--c-hair) !important; border-radius:0 !important;
  box-shadow: none !important; outline: none !important; color: var(--c-bright);
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-lead); padding: 20px 24px;
}
.vc-cmd-in::placeholder { color: var(--c-fnt); }
.vc-cmd-list { overflow-y: auto; padding: 6px 0 10px; }
.vc-cmd-g {
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold; letter-spacing: var(--trk-head);
  text-transform:var(--label-case); color: var(--c-a); opacity: .6; padding: 12px 24px 6px;
}
.vc-cmd-r {
  display: flex; align-items: baseline; gap: 14px; padding: 9px 24px; cursor: pointer;
  transition: background var(--c-t);
}
.vc-cmd-r:hover, .vc-cmd-r.on { background: color-mix(in srgb, var(--a) 7%, transparent); }
.vc-cmd-r.on { box-shadow: inset 2px 0 0 var(--c-a); }
.vc-cmd-t { font-family: var(--f-display); font-style: italic; font-size: var(--c-lead); color: var(--c-bright); flex: 0 0 auto; }
.vc-cmd-s {
  font-family: var(--c-mono); font-size: var(--c-micro); letter-spacing: .04em; color: var(--c-fnt);
  flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: right;
}
.vc-cmd-hint {
  padding: 10px 24px; border-top: var(--hair-w) solid var(--c-hair);
  font-family: var(--c-mono); font-size: var(--c-nano); letter-spacing: var(--trk-label);
  text-transform:var(--label-case); color: var(--c-fnt); display: flex; gap: 18px;
}
.vc-cmd-hint b { color: var(--c-dim); }
.vc-cmd-empty { padding: 30px 24px; font-family: var(--c-serif); font-style: italic; color: var(--c-fnt); }

.vc-recent { display: flex; gap: 8px; flex-wrap: wrap; padding: 4px 24px 12px; }
.vc-recent-i {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body); color: var(--c-dim);
  border: var(--hair-w) solid var(--c-hair); padding: 3px 11px 4px; cursor: pointer; transition: all var(--c-t);
}
.vc-recent-i:hover { color: var(--c-a); border-color: var(--c-border); }

.nm-how-card {
  width: min(780px, 100%); height: min(660px, 86vh);
  display: flex; flex-direction: column; padding: 0; overflow: hidden;
  background: var(--c-bg); border: var(--hair-w) solid var(--c-border);
  box-shadow: var(--sh-3);
}

.nm-how-mast {
  position: relative; flex: 0 0 auto; padding: 22px 26px 18px;
  border-bottom: var(--hair-w) solid var(--c-border);
}
.nm-how-mast::before {
  content: ""; position: absolute; inset: 0 0 auto 0; height: 1px;
  background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--a) 38%, transparent) 18%,
    color-mix(in srgb, var(--a) 38%, transparent) 82%, transparent);
}
.nm-how-mast::after {
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background: radial-gradient(120% 150% at 12% 0%, color-mix(in srgb, var(--a) 7%, transparent), transparent 62%);
}
.nm-how-eyebrow {
  position: relative; display: block; font-family: var(--c-mono);
  font-size: var(--c-nano); font-weight: bold; letter-spacing: var(--trk-head);
  text-transform:var(--label-case); color: var(--c-a); opacity: .6; margin-bottom: 7px;
}
.nm-how-title {
  position: relative; display: block; font-family: var(--f-display);
  font-size: var(--c-fig); line-height: 1; color: var(--c-bright); letter-spacing: -.015em;
}
.nm-how-x {
  position: absolute; top: 16px; right: 16px; z-index: 2;
  width: 28px; height: 28px; line-height: 1; cursor: pointer;
  background: transparent !important; border: 1px solid transparent !important;
  box-shadow: none !important; outline: none !important; border-radius:0 !important;
  font-family: var(--c-serif); font-size: var(--c-lead); color: var(--c-fnt);
  transition: color var(--c-t), border-color var(--c-t);
}
.nm-how-x:hover { color: var(--c-a); border-color: var(--c-border) !important; }

.nm-how-body { flex: 1 1 auto; min-height: 0; display: flex; }
.nm-how-rail {
  flex: 0 0 168px; min-width: 0; display: flex; flex-direction: column; gap: 1px;
  padding: 14px 0; border-right: var(--hair-w) solid var(--c-hair);
  background: color-mix(in srgb, var(--a) 2%, transparent);
}
.nm-how-nav {
  display: flex; align-items: baseline; gap: 8px; width: 100%; text-align: left;
  padding: 10px 16px 10px 18px; cursor: pointer;
  background: transparent !important; border: none !important; border-radius:0 !important;
  box-shadow: none !important; outline: none !important;
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-head); text-transform:var(--label-case); color: var(--c-fnt);
  transition: color var(--c-t), background var(--c-t);
}
.nm-how-nav:hover { color: var(--c-dim); background: color-mix(in srgb, var(--a) 4.5%, transparent) !important; }
.nm-how-nav.on {
  color: var(--c-a); background: color-mix(in srgb, var(--a) 6%, transparent) !important;
  box-shadow: inset 2px 0 0 var(--c-a) !important;
}
.nm-how-nav i {
  margin-left: auto; font-style: normal; font-weight: normal;
  letter-spacing: var(--trk-label); color: var(--c-fnt); opacity: .8;
}
.nm-how-nav.on i { color: var(--c-a); opacity: .7; }

.nm-how-pane {
  display: none; flex: 1 1 auto; min-width: 0; overflow-y: auto;
  padding: 22px 26px 26px;
  scrollbar-width: thin; scrollbar-color: var(--c-border) transparent;
}
.nm-how-pane.on { display: block; }
.nm-how-pane::-webkit-scrollbar { width: 7px; }
.nm-how-pane::-webkit-scrollbar-track { background: transparent; }
.nm-how-pane::-webkit-scrollbar-thumb { background: var(--c-border); border-radius:var(--r-tight); }

.nm-how-lede {
  font-family: var(--c-serif); font-size: var(--c-lead); line-height: 1.62;
  color: var(--c-tx); margin: 0 0 14px; letter-spacing: .005em;
}
.nm-how-lede em { font-style: italic; color: var(--c-a); }
.nm-how-p {
  font-family: var(--c-serif); font-size: var(--c-body); line-height: 1.7;
  color: var(--c-dim); margin: 0 0 14px;
}
.nm-how-note {
  font-family: var(--c-serif); font-size: var(--c-small); font-style: italic;
  line-height: 1.7; color: var(--c-fnt); margin: 0 0 16px;
}
.nm-how-lbl {
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-head); text-transform:var(--label-case); color: var(--c-a);
  padding-bottom: 8px; border-bottom: var(--hair-w) solid var(--c-hair); margin: 22px 0 12px;
}
.nm-how-src {
  display: flex; align-items: baseline; gap: 14px;
  padding: 9px 12px 10px; margin-bottom: 6px;
  background: var(--c-plate); border-left: 2px solid var(--c-border);
}
.nm-how-src-k {
  flex: 0 0 108px; font-family: var(--c-mono); font-size: var(--c-micro);
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-a); opacity: .85;
}
.nm-how-src-v {
  flex: 1 1 auto; min-width: 0; font-family: var(--c-serif);
  font-size: var(--c-body); line-height: 1.55; color: var(--c-dim);
}
.nm-how-src-v i {
  display: block; font-family: var(--c-serif); font-style: italic;
  font-size: var(--c-small); color: var(--c-fnt); margin-top: 2px;
}

.nm-how-steps { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 1px; }
.nm-how-step {
  display: flex; align-items: baseline; gap: 16px; width: 100%;
  text-align: left; cursor: pointer; padding: 11px 12px 11px 4px;
  background: transparent !important; border: none !important; border-radius:0 !important;
  box-shadow: none !important; outline: none !important;
  border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 5%, transparent) !important;
  transition: background var(--c-t);
}
.nm-how-steps li:last-child .nm-how-step { border-bottom: none !important; }
.nm-how-step:hover { background: color-mix(in srgb, var(--a) 4.5%, transparent) !important; }
.nm-how-step:focus-visible { outline: var(--hair-w) solid var(--c-border) !important; outline-offset: -2px; }
.nm-how-num {
  flex: 0 0 30px; font-family: var(--f-display); font-style: italic;
  font-size: var(--c-fig); line-height: 1; color: var(--c-a); opacity: .32;
  text-align: right; transition: opacity var(--c-t);
}
.nm-how-step:hover .nm-how-num { opacity: .85; }
.nm-how-txt { flex: 1 1 auto; min-width: 0; }
.nm-how-name {
  font-family: var(--f-display); font-style: italic; font-size: var(--c-lead);
  color: var(--c-bright); margin-right: 9px;
}
.nm-how-do { font-family: var(--c-serif); font-size: var(--c-body); color: var(--c-dim); }
.nm-how-is {
  display: block; font-family: var(--c-serif); font-size: var(--c-small);
  letter-spacing: 0; color: var(--c-fnt); margin-top: 5px; line-height: 1.55;
}
.nm-how-go {
  flex: 0 0 auto; align-self: center; font-family: var(--c-mono); font-size: var(--c-small);
  color: var(--c-fnt); opacity: 0; transform: translateX(-4px);
  transition: opacity var(--c-t), transform var(--c-t);
}
.nm-how-step:hover .nm-how-go { opacity: 1; transform: none; color: var(--c-a); }

.nm-how-pane--words.on { display: flex; flex-direction: column; overflow: hidden; padding-bottom: 0; }
.nm-how-find-wrap { flex: 0 0 auto; padding: 0 0 14px; }
.nm-how-scroll {
  flex: 1 1 auto; min-height: 0; overflow-y: auto; padding-bottom: 26px;
  scrollbar-width: thin; scrollbar-color: var(--c-border) transparent;
}
.nm-how-scroll::-webkit-scrollbar { width: 7px; }
.nm-how-scroll::-webkit-scrollbar-track { background: transparent; }
.nm-how-scroll::-webkit-scrollbar-thumb { background: var(--c-border); border-radius:var(--r-tight); }
.nm-how-find {
  width: 100%; background: transparent !important; color: var(--c-bright);
  border: none !important; border-bottom: var(--hair-w) solid var(--c-hair) !important;
  border-radius:0 !important; box-shadow: none !important; outline: none !important;
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  padding: 7px 2px 9px; transition: border-color var(--c-t);
}
.nm-how-find:focus { border-bottom-color: var(--c-border) !important; }
.nm-how-find::placeholder { color: var(--c-fnt); }
.nm-how-gloss { display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 10px; margin: 0; }
.nm-how-jar {
  background: var(--c-plate); border: var(--hair-w) solid var(--c-hair);
  padding: 12px 14px 13px; transition: border-color var(--c-t);
}
.nm-how-jar:hover { border-color: var(--c-border); }
.nm-how-jar dt {
  font-family: var(--f-display); font-style: italic; font-size: var(--c-lead);
  line-height: 1.15; color: var(--c-bright); margin: 0 0 8px; padding-bottom: 7px;
  border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 12%, transparent);
}
.nm-how-jar dt::before {
  content: "❧"; font-style: normal; font-size: .5em; color: var(--c-a);
  opacity: .5; margin-right: 7px; vertical-align: .22em;
}
.nm-how-jar:hover dt { color: var(--c-a); }
.nm-how-jar:hover dt::before { opacity: 1; }
.nm-how-jar dd { margin: 0; font-family: var(--c-serif); font-size: var(--c-small); line-height: 1.66; color: var(--c-dim); }
.nm-how-jar dd code { font-family: var(--c-mono); font-size: var(--c-micro); color: var(--c-fnt); }
.nm-how-none {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  color: var(--c-fnt); padding: 20px 2px;
}
.nm-how-none b { color: var(--c-dim); font-weight: normal; }

.nm-how-foot {
  flex: 0 0 auto; display: flex; align-items: center; gap: 12px;
  padding: 14px 26px 15px; border-top: var(--hair-w) solid var(--c-border);
  background: color-mix(in srgb, var(--a) 2%, transparent);
}
.nm-how-esc {
  margin-right: auto; font-family: var(--c-mono); font-size: var(--c-nano);
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-fnt);
}
.nm-how-esc b { color: var(--c-dim); font-weight: normal; }

@media (max-width: 720px) {
  .nm-how-card { height: min(680px, 90vh); }
  .nm-how-body { flex-direction: column; }
  .nm-how-rail {
    flex: 0 0 auto; flex-direction: row; padding: 0;
    border-right: none; border-bottom: var(--hair-w) solid var(--c-hair);
  }
  .nm-how-nav { flex: 1 1 0; justify-content: center; padding: 11px 8px; letter-spacing: var(--trk-label); }
  .nm-how-nav.on { box-shadow: inset 0 -2px 0 var(--c-a) !important; }
  .nm-how-nav i { margin-left: 0; }
  .nm-how-gloss { grid-template-columns: minmax(0,1fr); }
  .nm-how-mast, .nm-how-pane, .nm-how-foot { padding-left: 18px; padding-right: 18px; }
  .nm-how-num { flex-basis: 22px; font-size: var(--c-lead); }
}

.nm-hyd-vt, .nm-how-step, .nm-how-txt, .nm-how-nav { white-space: normal; }

.vc-crumb {
  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  padding: 10px calc(30px * var(--c-scale));
  border-bottom: var(--hair-w) solid var(--c-hair);
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-fnt);
}
.vc-crumb a, .vc-crumb button {
  border: none !important; background: transparent !important; box-shadow: none !important;
  outline: none !important; cursor: pointer; padding: 0; color: var(--c-dim);
  font: inherit; letter-spacing: inherit; text-transform: inherit;
  text-decoration: none !important; transition: color var(--c-t);
}
.vc-crumb a:hover, .vc-crumb button:hover { color: var(--c-a); }
.vc-crumb-sep { opacity: .4; }
.vc-crumb-now { color: var(--c-a); }
.vc-crumb-r { margin-left: auto; display: flex; gap: 14px; }

.vc-link {
  color: var(--c-a) !important; text-decoration: none !important;
  border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 22%, transparent); transition: border-color var(--c-t);
  cursor: pointer;
}
.vc-link:hover { border-bottom-color: var(--c-a); }

.vc-toast {
  position: fixed; right: 24px; bottom: 24px; z-index: 2147483001; display: none;
  align-items: center; gap: 20px; background: color-mix(in srgb, var(--bg) 97%, transparent);
  border: var(--hair-w) solid var(--c-border); padding: 13px 20px;
  box-shadow: var(--sh-3); overflow: hidden;
  opacity: 0; transform: translateY(14px);
  transition: opacity .2s ease, transform .2s ease;
}
.vc-toast.on { display: flex; opacity: 1; transform: none; }
.vc-toast-x { font-family: var(--c-serif); font-style: italic; font-size: var(--c-body); color: var(--c-tx); }
.vc-toast-x b { color: var(--c-a); font-weight: normal; }
.vc-toast-bar { position: absolute; left: 0; bottom: 0; height: 2px; background: var(--c-a); opacity: .5; }
.vc-toast:has(.vc-toast-l) { flex-wrap: wrap; row-gap: 6px; max-width: min(560px, calc(100vw - 48px)); }
.vc-toast-l { order: 9; flex: 1 0 100%; display: flex; flex-direction: column; gap: 2px; }
.vc-toast .vc-toast-l code { font: 400 12px/1.45 ui-monospace, "Cascadia Mono", Consolas, monospace !important; color: var(--c-dim) !important;
  overflow-wrap: anywhere; background: none !important; padding: 0 !important; border-radius: 0 !important; }
.vc-toast .vc-b.vc-b--sm { font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold; letter-spacing: var(--trk-label); text-transform: var(--label-case);
  padding: 3px 10px 4px; color: var(--c-dim); line-height: 1.4 !important; }
.vc-toast .vc-b.vc-b--sm:hover { color: var(--c-a); }

@media (max-width: 900px) {
  .vc-plate { padding: 16px 16px 18px; }
  .vc-cmd { padding-top: 6vh; }
  .vc-toast { left: 16px; right: 16px; bottom: 16px; }
}

.dn-ev--routine .dn-ev-node { background: var(--c-bg); border-color: var(--c-blue); }
.dn-ev--routine .dn-ev-name { color: var(--c-blue); }
.dn-rt { margin-top: 6px; }
.dn-rt-step {
  display: flex; align-items: baseline; gap: 14px; padding: 8px 0;
  border-bottom: var(--hair-w) solid color-mix(in srgb, var(--a) 4%, transparent); cursor: pointer;
  transition: padding 220ms cubic-bezier(.2,.8,.2,1), background 220ms;
}
.dn-rt-step:last-child { border-bottom: none; }
.dn-rt-step:hover { background: color-mix(in srgb, var(--planned) 4%, transparent); padding-left: 8px; }
.dn-rt-n {
  flex: 0 0 20px; font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  color: var(--c-blue); opacity: .7;
}
.dn-rt-name {
  flex: 0 0 130px; font-family: var(--c-mono); font-size: var(--c-micro); letter-spacing: var(--trk-label);
  text-transform:var(--label-case); color: var(--c-dim);
}
.dn-rt-p {
  flex: 1; font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  color: var(--c-tx); transition: color 220ms;
}
.dn-rt-step:hover .dn-rt-p { color: var(--c-a); }
.dn-rt-why {
  font-family: var(--c-serif); font-size: var(--c-body); font-style: italic; line-height: 1.75;
  color: var(--c-fnt); margin-top: 12px; padding-top: 10px;
  border-top: var(--hair-w) solid var(--c-hair); max-width: 76ch;
}

[data-kind="food"]     { --c-a: var(--a); --c-accent2: var(--reached); --c-orn: "❧"; }
[data-kind="day"]      { --c-a: var(--lp-kind-day, #c9a06a); --c-accent2: var(--planned); --c-orn: "§"; }
[data-kind="movie"]    { --c-a: var(--lp-kind-movie, #d4a03c); --c-accent2: var(--lp-velvet-hi, #a8524e); --c-orn: "▤"; }
[data-kind="study"]    { --c-a: var(--lp-kind-study, #9db4c0); --c-accent2: var(--eaten); --c-orn: "✒"; }
[data-kind="training"] { --c-a: var(--lp-kind-training, #c08a5e); --c-accent2: var(--reached); --c-orn: "⌇"; }
[data-kind="finance"]  { --c-a: var(--lp-kind-finance, #a8a06a); --c-accent2: var(--reached); --c-orn: "⛁"; }
[data-kind="recipe"]   { --c-a: var(--a); --c-accent2: var(--a-kitchen); --c-orn: "✿"; }

.vc-mark::before {
  content: var(--c-orn, "❧"); font-family: var(--c-serif);
  color: var(--c-a); opacity: .55; margin-right: 10px; font-style: normal;
}
.vc-rule--orn {
  display: flex; align-items: center; gap: 16px; margin: 30px 0;
  font-family: var(--c-serif); color: var(--c-a); opacity: .4;
}
.vc-rule--orn::before, .vc-rule--orn::after {
  content: ""; flex: 1; height: 1px; background: var(--c-hair);
}
.vc-rule--orn::after { content: ""; }

.vc-why {
  display: inline-flex; align-items: center; justify-content: center;
  width: 13px; height: 13px; margin-left: 8px; cursor: help;
  border: var(--hair-w) solid var(--c-hair); border-radius:50%;
  font-family: var(--c-mono); font-size: var(--c-nano); color: var(--c-fnt);
  vertical-align: middle; transition: color 220ms, border-color 220ms;
  position: relative; flex: 0 0 auto;
}
.vc-why:hover { color: var(--c-a); border-color: var(--c-a); }
.vc-why::after {
  content: attr(data-why);
  position: absolute; bottom: calc(100% + 9px); left: 50%; transform: translateX(-50%);
  width: max-content; max-width: 40ch; padding: 11px 14px;
  background: var(--bg); border: var(--hair-w) solid var(--c-border); border-radius:var(--r);
  box-shadow: var(--sh-3);
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  line-height: 1.7; letter-spacing: 0; text-transform: none;
  color: var(--c-tx); text-align: left;
  opacity: 0; pointer-events: none; transition: opacity 160ms; z-index: 300;
}
.vc-why:hover::after { opacity: 1; }
.vc-why--left::after { left: auto; right: 0; transform: none; }
.vc-why--right::after { left: 0; right: auto; transform: none; }
.vc-why--down::after { bottom: auto; top: calc(100% + 9px); }

.vc-fold { cursor: pointer; }
.vc-fold-body { display: none; }
.vc-fold--open > .vc-fold-body, .vc-fold-body--open { display: block; }
.vc-more {
  border: none !important; background: transparent !important; box-shadow: none !important;
  outline: none !important; cursor: pointer; padding: 6px 0 0;
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-fnt);
  border-bottom: 1px solid transparent !important; transition: color 220ms;
}
.vc-more:hover { color: var(--c-a); border-bottom-color: var(--c-border) !important; }

.vc-sum {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  color: var(--c-dim); line-height: 1.7;
}
.vc-sum b { color: var(--c-a); font-style: normal; }
.vc-sum-warn { color: var(--c-red); }

.vc-hov { opacity: 0; transition: opacity 220ms; }
*:hover > .vc-hov, *:focus-within > .vc-hov { opacity: 1; }
@media (hover: none) { .vc-hov { opacity: 1; } }

.vc-filter { display: flex; gap: 2px; margin-left: auto; }
.vc-filter button {
  border: var(--hair-w) solid var(--c-hair) !important; background: transparent !important;
  box-shadow: none !important; outline: none !important; cursor: pointer;
  padding: 3px 10px 4px; font-family: var(--c-mono); font-size: var(--c-nano);
  font-weight: bold; letter-spacing: var(--trk-label); text-transform:var(--label-case);
  color: var(--c-fnt); transition: all 220ms;
}
.vc-filter button:hover { color: var(--c-a); border-color: var(--c-border) !important; }
.vc-filter button.on { color: var(--on-a); background: var(--c-a) !important; border-color: var(--c-a) !important; }

.dn-tab-bar, .dn-tabs {
  display: flex; align-items: stretch; gap: 0; padding: 0;
  border-bottom: none; overflow: visible; flex-wrap: wrap; position: relative;
}
.dn-tab-bar { padding: 0 calc(30px * var(--c-scale)); border-bottom: var(--hair-w) solid var(--c-border); }
.dn-tab {
  border: none !important; background: transparent !important; box-shadow: none !important;
  outline: none !important; cursor: pointer; white-space: nowrap; position: relative;
  padding: 0 calc(17px * var(--c-scale)); min-height: calc(54px * var(--c-scale));
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-body);
  color: var(--c-dim); transition: color 220ms;
  display: inline-flex; align-items: center; gap: 8px; line-height: normal;
}
.dn-tab:first-child { padding-left: 0; }
.dn-tab:hover { color: var(--c-tx); }
.dn-tab--active { color: var(--c-a); }
.dn-tab--active::after {
  content: ""; position: absolute; left: calc(17px * var(--c-scale));
  right: calc(17px * var(--c-scale)); bottom: 12px; height: 1px; background: var(--c-a);
}
.dn-tab:first-child.dn-tab--active::after { left: 0; }
.dn-tabline { display: none !important; }

.dn-label, .fv-label, .nm-label {
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-head); text-transform:var(--label-case); color: var(--c-a);
  padding-bottom: calc(11px * var(--c-scale)); margin-bottom: calc(15px * var(--c-scale));
  border-bottom: var(--hair-w) solid var(--c-hair);
  display: flex; align-items: baseline; gap: 12px;
}
.dn-label small, .fv-label small, .nm-label small {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-small);
  letter-spacing: 0; text-transform: none; color: var(--c-fnt);
  font-weight: normal; margin-left: auto;
}
.dn-sec, .nm-plate {
  background: var(--c-plate); border: var(--hair-w) solid var(--c-hair);
  padding: calc(20px * var(--c-scale)) calc(24px * var(--c-scale)) calc(24px * var(--c-scale));
  margin-bottom: calc(26px * var(--c-scale));
}
.dn-btn-text, .fv-btn, .nm-btn {
  border: var(--hair-w) solid var(--c-border) !important; background: transparent !important;
  box-shadow: none !important; outline: none !important; cursor: pointer;
  padding: calc(6px * var(--c-scale)) calc(15px * var(--c-scale)) calc(7px * var(--c-scale));
  font-family: var(--c-mono); font-size: var(--c-micro); font-weight: bold;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-dim);
  transition: color 220ms, border-color 220ms, background 220ms;
}
.dn-btn-text:hover, .fv-btn:hover, .nm-btn:hover { color: var(--c-a); border-color: var(--c-a) !important; }
.fv-btn--hot, .nm-btn--hot, .dn-btn-text { color: var(--c-a); }
.fv-btn--hot:hover, .nm-btn--hot:hover { color: var(--on-a); background: var(--c-a) !important; }

@media (hover: none), (pointer: coarse) {
  .vc-why { width: 22px; height: 22px; font-size: var(--c-micro); margin-left: 10px; }
  .vc-why:hover::after { opacity: 0; }
  .vc-why.on::after { opacity: 1; pointer-events: auto; }
  .vc-why.on {
    color: var(--on-a); background: var(--c-a); border-color: var(--c-a);
  }
  .vc-why::after {
    position: fixed; left: 12px; right: 12px; bottom: 12px; top: auto;
    transform: none; width: auto; max-width: none;
    font-size: var(--c-body); padding: 18px 20px;
    box-shadow: 0 -10px 50px rgba(0,0,0,.8);
  }
  .vc-hov, .fv-ing-acts, .nm-it-a, .fv-comp-a, .fv-step-acts,
  .dn-tedit, .dn-topen, .dn-tdel, .nm-nm-acts, .dn-nm-acts { opacity: 1 !important; }
}

@media (max-width: 760px) {
  .vc-b, .fv-btn, .nm-btn, .dn-btn-text, .nm-mini, .fv-mini,
  .vc-filter button, .nm-hyd-v, .fv-comp-o, .vc-more {
    min-height: 40px; display: inline-flex; align-items: center; justify-content: center;
  }
  .nm-mini, .fv-mini, .vc-filter button { min-height: 36px; padding-left: 14px; padding-right: 14px; }
  .dn-task-box, .nm-hyd-d {
    min-width: 26px; min-height: 26px;
  }
  .nm-hyd-d { width: 22px; height: 22px; }
  .fv-ing-del, .fv-comp-b, .dn-nm-btn { min-width: 34px; min-height: 34px; }

  .fv-body, .fv-hero-bottom, .nm-grid, .dn-grid, .dn-j, .dn-meals,
  .dn-fin-grid, .dn-fin-entry, .nm-sparks, .dn-sparks, .fv-panel-grid,
  .nm-pot-key, .nm-cyc-g { grid-template-columns: 1fr !important; }
  .fv-hero-bottom { display: block; }
  .fv-rings { justify-content: flex-start; gap: 12px; }
  .vc-now { padding-left: 16px; padding-right: 16px; }
  .vc-plate, .dn-sec, .nm-plate { padding: 16px 15px 18px; margin-bottom: 18px; }

  .vc-row, .nm-it, .fv-ing, .nm-sup, .nm-load, .nm-rel, .nm-arc-r, .nm-pot-r {
    flex-wrap: wrap; gap: 8px 12px;
  }
  .nm-arc-k, .nm-load-k, .nm-rel-k, .nm-pot-k, .fv-micro-name { flex-basis: 100%; }
  .nm-arc-bar, .nm-load-bar, .nm-rel-bar, .fv-micro-bar { flex: 1 1 60%; }
  .fv-ing-name, .nm-it-b { flex: 1 1 100%; }
  .fv-ing-kcal, .fv-ing-g { flex: 0 0 auto; }

  .vc-cmd, .nm-swapov, .nm-modal, .fv-modal {
    align-items: flex-end !important; padding: 0 !important;
  }
  .vc-cmd-card, .nm-modal-card, .fv-modal-card, .fv-ingedit-card {
    width: 100% !important; max-width: none !important; max-height: 88vh;
    border-left: none !important; border-right: none !important;
    border-bottom: none !important; overflow-y: auto;
    border-radius:0; padding: 22px 18px calc(22px + env(safe-area-inset-bottom));
  }
  .vc-toast, .fv-toast, .dn-toast { left: 12px; right: 12px; bottom: 12px; }

  .fv-title { font-size: clamp(26px, 8vw, 34px); }
  .dn-date { font-size: clamp(24px, 7vw, 32px); }
  .nm-pot-n, .nm-hyd-n { font-size: var(--c-fig); }
  .fv-stat { flex-basis: 46%; }

  .nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy { overflow-x: hidden; }
  .nm-week-grid, .dn-fin-table, .fv-ing-fields { max-width: 100%; overflow-x: auto; }
}

@media (max-width: 420px) {
  .fv-stat { flex-basis: 100%; }
  .vc-now-meta { flex: 1 0 100%; }
}
.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy { padding-bottom: env(safe-area-inset-bottom); }
body.is-mobile .hd { overflow: clip !important; }
body.is-mobile :is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, .vc-scroller) { overscroll-behavior-x: none; }
body.is-mobile :is(.hd, .vc-scroller) { touch-action: pan-y; }

.vc-scroller { background: var(--bg) !important; scrollbar-width: thin; scrollbar-color: color-mix(in srgb, var(--a) 24%, var(--bg)) transparent; }
.vc-scroller::-webkit-scrollbar { width: 8px; height: 8px; background: transparent; }
.vc-scroller::-webkit-scrollbar-track { background: transparent; }
.vc-scroller::-webkit-scrollbar-thumb { background: color-mix(in srgb, var(--a) 24%, var(--bg)); border: 0; border-radius: 4px; }
.vc-scroller::-webkit-scrollbar-thumb:hover { background: color-mix(in srgb, var(--a) 45%, var(--bg)); }
.vc-scroller::-webkit-scrollbar-corner { background: transparent; }

.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy {
  --c-fnt: color-mix(in srgb, var(--fnt) 75%, var(--tx));
  --c-dim: color-mix(in srgb, var(--dim) 80%, var(--tx));
}
.nm :focus-visible, .dn :focus-visible, .fv :focus-visible, .hd :focus-visible, .md :focus-visible, .mv :focus-visible,
.sd :focus-visible, .sv :focus-visible, .lt :focus-visible, .gy :focus-visible,
body > .nm-modal :focus-visible, body > .fv-modal :focus-visible,
body > .nm-swapov :focus-visible, body > .vc-cmd :focus-visible {
  outline: var(--hair-w) solid color-mix(in srgb, var(--c-a) 55%, transparent) !important;
  outline-offset: 2px !important;
}
:is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, body > .nm-modal, body > .fv-modal, body > .nm-swapov, body > .vc-cmd)
  :is(input:not([type="checkbox"]):not([type="radio"]):not([type="range"]), textarea, [contenteditable="true"]):focus-visible {
  outline: none !important;
}

.vc-tag--warn::before, .nm-load.over .nm-load-v::before,
.fv-micro-pct.over::before, .nm-pot-r.stuck .nm-pot-v::before { content: "⚠ "; }
.vc-tag--good::before, .fv-micro-pct.full::before,
.nm-arc-p.on::before, .nm-blk-c.on::before { content: "✓ "; }

body[data-perf="light"] :is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, .vc-pop, .vc-toast, .vc-cmd),
body[data-perf="light"] :is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, .vc-pop, .vc-toast, .vc-cmd) :is(*, *::before, *::after),
body[data-perf="light"] :is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, .vc-pop)::before, body[data-perf="light"] :is(.nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy, .vc-pop)::after {
  animation: none !important; transition: none !important; filter: none !important; -webkit-backdrop-filter: none !important; backdrop-filter: none !important;
  mix-blend-mode: normal !important; text-shadow: none !important; }
body[data-perf="light"] .hd::before, body[data-perf="light"] .hd::after, body[data-perf="light"] .hd-ground::before, body[data-perf="light"] .hd-ground::after { display: none !important; }
body[data-perf="light"] :is(.fv-glow, .nm-stage-glow, .sd-stage-glow, .md-stage .md-back, .md-premiere .md-back, .sd-prem-back, .lt .halo, .lt .glint),
body[data-perf="light"] :is(.lt .cover.sm.pic, .lt .tile-pic.tall)::before { display: none !important; }

@media (prefers-reduced-motion: reduce) {
  .nm *, .dn *, .fv *, .hd *, .vc-cmd, .vc-toast {
    animation-duration: 0.001ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.001ms !important;
    scroll-behavior: auto !important;
  }
}
@media (prefers-contrast: more) {
  .nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy { --c-fnt: color-mix(in srgb, var(--fnt) 55%, var(--tx)); --c-hair: color-mix(in srgb, var(--a) 22%, transparent); --c-border: color-mix(in srgb, var(--a) 40%, transparent); }
}
.vc-sr {
  position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px;
  overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0;
}

.vc-ring { position: relative; display: inline-flex; align-items: center;
  justify-content: center; flex: 0 0 auto; }
.vc-ring svg { width: 100%; height: 100%; transform: rotate(-90deg); display: block; }
.vc-ring--xl { width: 158px; height: 158px; }
.vc-ring--lg { width: 110px; height: 110px; }
.vc-ring--sm { width: 88px;  height: 88px;  }
.vc-ring-bg { fill: none; stroke: color-mix(in srgb, var(--a) 11%, transparent); stroke-width: 5; }
.vc-ring-ghost { fill: none; stroke: var(--c-a); stroke-width: 5; opacity: .24;
  stroke-dasharray: 3 4; }
.vc-ring-fg { fill: none; stroke: var(--c-a); stroke-width: 5; stroke-linecap: round;
  transition: stroke-dashoffset 1s cubic-bezier(.2,.8,.2,1), stroke .5s ease; }
.vc-ring-n { position: absolute; font-family: var(--c-serif); font-style: italic;
  color: var(--c-bright); line-height: 1; }
.vc-ring--xl .vc-ring-n { font-size: var(--c-hero); }
.vc-ring--lg .vc-ring-n { font-size: var(--c-fig); }
.vc-ring--sm .vc-ring-n { font-size: var(--c-lead); }
.vc-ring-c { position: absolute; bottom: -14px; left: 50%; transform: translateX(-50%);
  font-family: var(--c-mono); font-size: var(--c-nano); font-weight: bold; letter-spacing: var(--trk-label);
  text-transform:var(--label-case); color: var(--c-fnt); white-space: nowrap; }

.vc-tween { font-variant-numeric: tabular-nums; }

@media print {
  .nm, .dn, .fv, .hd, .md, .mv, .sd, .sv, .lt, .gy {
    background: #fff !important; color: #111 !important;
    --c-a: #6b5528; --c-tx: #111; --c-dim: #333; --c-fnt: #555;
    --c-border: #999; --c-hair: #ccc; --c-plate: transparent; --c-bg: #fff;
  }
  .nm *, .dn *, .fv *, .hd * { background: transparent !important; color: inherit !important;
    box-shadow: none !important; text-shadow: none !important; }
  .vc-tabs, .dn-tab-bar, .vc-now, .vc-cmd, .vc-toast, .fv-toast,
  .vc-filter, .nm-arrange, .vc-hov, .nm-it-a, .fv-ing-acts, .dn-mini,
  .vc-more, .vc-why, .fv-actions, .nm-errbar, .dn-errbar,
  .nm-hyd-vars, .fv-swapbar, .fv-paste, .nm-fixbar { display: none !important; }
  .nm-panel, .dn-panel { display: block !important; page-break-before: always; }
  .nm-panel:first-of-type, .dn-panel:first-of-type { page-break-before: avoid; }
  .vc-plate, .dn-sec, .nm-plate { border: 1px solid #ccc !important;
    page-break-inside: avoid; margin-bottom: 14px; }
  .vc-label, .dn-label, .fv-label, .nm-label { border-bottom: 1px solid #999 !important; }
  .vc-fold-body, .fv-notes-rest { display: block !important; }
  a { text-decoration: none !important; }
  .vc-why[data-why]::before {
    content: " (" attr(data-why) ")"; display: inline;
    font-style: italic; font-size: var(--c-small); color: #555;
  }
  @page { margin: 16mm; }
}

.nm-how-task {
  padding: 15px 0 16px;
  border-bottom: var(--hair-w) solid var(--c-hair);
}
.nm-how-task:last-child { border-bottom: none; }
.nm-how-q {
  font-family: var(--f-display);
  font-size: var(--c-lead);
  color: var(--c-bright);
  margin-bottom: 6px;
  line-height: 1.3;
}
.nm-how-a {
  font-family: var(--c-serif);
  font-size: var(--c-body);
  line-height: 1.62;
  color: var(--c-tx);
  white-space: normal;
  max-width: 62ch;
}
.nm-how-a b { color: var(--c-bright); font-weight: 600; }
.nm-how-a em { color: var(--c-dim); }
.nm-how-a code {
  font-family: var(--c-mono);
  font-size: .86em;
  color: var(--c-a);
  background: color-mix(in srgb, var(--a) 9%, transparent);
  padding: 1px 5px;
  border-radius:var(--r-hair);
}
.nm-how-goto { margin-top: 9px; }

.nm-how-state {
  display: block;
  font-family: var(--c-mono);
  font-size: var(--c-small);
  letter-spacing: .04em;
  color: var(--c-a);
  margin-top: 5px;
  white-space: normal;
}
.nm-how-step.done .nm-how-num {
  color: var(--c-green);
  font-family: var(--c-serif);
}
.nm-how-step.done .nm-how-name { color: var(--c-dim); }
.nm-how-step.done .nm-how-state { color: var(--c-green); }

.vc-pop {
  position: fixed; z-index: 2147483000; display: none;
  min-width: 300px; max-width: min(520px, calc(100vw - 32px));
  flex-direction: column; gap: 11px;
  padding: 13px 16px 14px;
  background: var(--bg-2); border: var(--hair-w) solid var(--c-border); border-radius:var(--r-soft);
  box-shadow: var(--sh-3);
  font-family: var(--c-serif); color: var(--c-tx);
}
.vc-pop.on { display: flex; }
.vc-pop-h {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-small);
  color: var(--c-fnt); display: flex; align-items: center; gap: 8px;
  padding-bottom: 9px; border-bottom: var(--hair-w) solid var(--c-hair);
}
.vc-pop-list {
  max-height: min(46vh, 420px); overflow-x: hidden; overflow-y: auto;
  scrollbar-width: thin; scrollbar-color: var(--c-border) transparent;
}
.vc-pop-list::-webkit-scrollbar { width: 7px; }
.vc-pop-list::-webkit-scrollbar-track { background: transparent; }
.vc-pop-list::-webkit-scrollbar-thumb { background: var(--c-border); border-radius:var(--r-tight); }

.vc-pop-row {
  display: flex; align-items: center; gap: 14px; width: 100%;
  padding: 10px 6px 11px; text-align: left; cursor: pointer;
  background: transparent !important; border: 0 !important;
  border-bottom: var(--hair-w) solid var(--c-hair) !important;
  border-radius:0 !important; box-shadow: none !important;
  outline: none !important;
  height: auto !important; min-height: 0 !important; line-height: normal !important;
  font-size: var(--c-body) !important; white-space: normal !important;
}
.vc-pop-row:last-child { border-bottom: 0 !important; }
.vc-pop-row:hover { background: color-mix(in srgb, var(--a) 7%, transparent) !important; }
.vc-pop-row:focus-visible { background: color-mix(in srgb, var(--a) 10%, transparent) !important; }
.vc-pop-b { flex: 1 1 auto; min-width: 0; }
.vc-pop-t {
  display: block; font-family: var(--c-serif); font-style: italic;
  font-size: var(--c-body); color: var(--c-bright); line-height: 1.25;
}
.vc-pop-again {
  font-family: var(--c-mono); font-size: var(--c-nano); font-style: normal;
  letter-spacing: var(--trk-label); text-transform:var(--label-case); color: var(--c-fnt);
  border: var(--hair-w) solid var(--c-hair); padding: 1px 5px 2px; margin-left: 7px;
  white-space: nowrap;
}
.vc-pop-why {
  display: block; font-family: var(--c-serif); font-size: var(--c-small);
  color: var(--c-green); margin-top: 3px;
}
.vc-pop-cost { color: var(--c-dim); font-style: italic; }
.vc-pop-m {
  flex: 0 0 auto; font-family: var(--c-mono); font-size: var(--c-small);
  color: var(--c-dim); white-space: nowrap;
}
.vc-pop-m b { color: var(--c-tx); font-weight: bold; }

.nm-nc { display: flex; flex-direction: column; min-width: 296px; }
.nm-nc-h {
  display: flex; align-items: baseline; justify-content: space-between;
  gap: 14px; padding-bottom: 9px; border-bottom: var(--hair-w) solid var(--c-hair);
}
.nm-nc-name {
  font-family: var(--c-serif); font-size: var(--c-body); color: var(--c-bright);
  letter-spacing: var(--trk-label); text-transform:var(--label-case);
}
.nm-nc-need {
  font-family: var(--c-mono); font-size: var(--c-nano); color: var(--c-fnt);
  white-space: nowrap;
}
.nm-nc-rows { display: flex; flex-direction: column; padding: 4px 0 2px; }
.nm-nc-r { display: flex; align-items: center; gap: 10px; padding: 5px 0; }
.nm-nc-r i {
  flex: 0 0 auto; width: 7px; height: 7px; border-radius:var(--r-hair); align-self: center;
}
.nm-nc-r i.have { background: var(--a); }
.nm-nc-r i.food { background: var(--planned); }
.nm-nc-r i.supp {
  background: repeating-linear-gradient(135deg, var(--a) 0 2px, transparent 2px 4px);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--a) 45%, transparent);
}
.nm-nc-r i.gap { background: color-mix(in srgb, var(--tx) 13%, transparent); }
.nm-nc-l {
  flex: 1 1 auto; min-width: 0; font-family: var(--c-serif);
  font-size: var(--c-small); color: var(--c-dim); line-height: 1.2;
}
.nm-nc-l em {
  display: block; font-style: italic; font-size: var(--c-nano); color: var(--c-fnt);
}
.nm-nc-a {
  flex: 0 0 auto; font-family: var(--c-mono); font-size: var(--c-small);
  color: var(--c-tx); font-weight: bold; text-align: right; min-width: 64px;
}
.nm-nc-p {
  flex: 0 0 auto; font-family: var(--c-mono); font-size: var(--c-small);
  color: var(--c-fnt); text-align: right; min-width: 44px;
}
.nm-nc-dorm {
  font-family: var(--c-serif); font-size: var(--c-small); color: var(--c-amber, var(--unsure));
  line-height: 1.35; margin-top: 4px; padding: 8px 10px 9px;
  background: color-mix(in srgb, var(--unsure) 6%, transparent); border-left: 2px solid color-mix(in srgb, var(--unsure) 40%, transparent);
  border-radius:0 var(--r-tight) var(--r-tight) 0;
}
.nm-nc-dorm b { color: var(--c-bright); font-weight: normal; font-style: italic; }
.nm-nc-foot {
  font-family: var(--c-serif); font-size: var(--c-small); color: var(--c-dim);
  line-height: 1.35; padding-top: 9px; border-top: var(--hair-w) solid var(--c-hair);
}
.nm-nc-why {
  font-family: var(--c-serif); font-style: italic; font-size: var(--c-small);
  color: var(--c-fnt); line-height: 1.35; padding-top: 6px;
}
.nm-nc-go {
  margin-top: 11px; width: 100%; cursor: pointer;
  font-family: var(--c-mono) !important; font-size: var(--c-nano) !important;
  letter-spacing: var(--trk-label); text-transform:var(--label-case);
  color: var(--c-a) !important; background: transparent !important;
  border: var(--hair-w) solid var(--c-border) !important; border-radius:var(--r-tight) !important;
  padding: 7px 9px 8px !important; text-align: center !important;
  height: auto !important; min-height: 0 !important; line-height: normal !important;
  box-shadow: none !important;
}
.nm-nc-go:hover { background: color-mix(in srgb, var(--a) 9%, transparent) !important; }
```
