---
type: vault-module
---

# Vault-Store

The Store: the Hall's page that shows what this vault has and what its keys cover, and installs,
updates and removes add-ons and themes. The first block holds the keys' check, the installer and the
page, in that order; the second is the page's stylesheet. It is loaded the first time the page opens.

**Do not edit these blocks by hand.** They are read by this note's name and replaced whole whenever
the vault's code is updated, so anything typed here is lost.

```js
const VAULT_KEYS = (() => {
  const FORMAT = "NEU1";
  const enc = new TextEncoder(), dec = new TextDecoder();

  const toB64u = bytes => { let s = ""; for (const b of bytes) s += String.fromCharCode(b); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); };
  function fromB64u(s) {
    if (!/^[A-Za-z0-9_-]*$/.test(s)) throw new Error("not base64url");
    const t = s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4);
    const bin = atob(t), out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  const encode = payload => toB64u(enc.encode(JSON.stringify(payload)));

  function read(text) {
    if (typeof text !== "string") return { ok: false, why: "is not an Auriel key" };
    const t = text.replace(/\s+/g, "");
    if (!t.startsWith(FORMAT + ".")) return { ok: false, why: "is not an Auriel key" };
    const parts = t.split(".");
    if (parts.length !== 3 || !parts[1] || !parts[2]) return { ok: false, why: "is cut short: a key has three parts" };
    try {
      const payload = JSON.parse(dec.decode(fromB64u(parts[1])));
      if (!payload || typeof payload !== "object" || !Array.isArray(payload.i) || !payload.k) return { ok: false, why: "cannot be read" };
      return { ok: true, payload, body: parts[1], sig: parts[2] };
    } catch (e) { return { ok: false, why: "cannot be read" }; }
  }

  async function verify(text, publicJwk, subtle = globalThis.crypto && globalThis.crypto.subtle) {
    const r = read(text);
    if (!r.ok || !publicJwk || !subtle) return false;
    try {
      const pub = await subtle.importKey("jwk", publicJwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      return await subtle.verify({ name: "ECDSA", hash: "SHA-256" }, pub, fromB64u(r.sig), enc.encode(r.body));
    } catch (e) { return false; }
  }

  const ISO = /^\d{4}-\d{2}-\d{2}$/;
  function covers(payload, item) {
    if (!payload || !item) return false;
    const names = payload.i || [];
    const named = names.includes(item.id) || names.includes("*") || (item.kind === "theme" && names.includes("*theme"));
    if (!named) return false;
    if (payload.a && item.kind === "addon" && !(ISO.test(String(item.date || "")) && String(item.date) <= String(payload.a))) return false;
    if (!payload.u) return true;
    return ISO.test(String(item.date || "")) && String(item.date) <= String(payload.u);
  }
  function names(payload, items) {
    const byId = new Map((items || []).map(it => [it.id, it]));
    const out = new Set(), made = payload && ISO.test(String(payload.d || "")) ? String(payload.d) : "";
    const add = (id, by) => {
      const it = byId.get(id);
      if (by && it && it.kind !== "bundle" && String(it.first || it.date || "") > by) return;
      if (out.has(id)) return;
      out.add(id);
      if (!it) return;
      if (it.kind !== "bundle") return (it.includes || []).forEach(x => add(x, ""));
      const cut = it.asBought && made && (!by || made < by) ? made : by;
      (it.items || []).forEach(x => add(x, cut));
    };
    ((payload && payload.i) || []).forEach(x => add(x, ""));
    return { ...payload, i: [...out] };
  }
  const coveredIds = (payloads, items) => {
    const named = payloads.map(p => names(p, items));
    return items.filter(it => it.kind !== "bundle" && named.some(p => covers(p, it))).map(it => it.id);
  };

  const SHOP_SHAPE = /^[A-Za-z0-9][A-Za-z0-9_-]{7,99}$/;
  function accepts(text) {
    const t = String(text == null ? "" : text).trim();
    if (!t.startsWith(FORMAT + ".") && SHOP_SHAPE.test(t)) return { ok: true, shop: true };
    return read(t);
  }

  return { FORMAT, read, accepts, verify, covers, coveredIds, names, encode };
})();

const VAULT_INSTALL = (() => {
  const RECORDS = "99_Meta/Store";
  const FENCE = "`".repeat(3);
  const BACKUPS = ".neurora/backups";
  const HIDDEN_OK = [/^\.obsidian\/themes\/Lamplit\/[^/]+$/, /^\.obsidian\/plugins\/vault-later\/(?:main\.js|manifest\.json)$/];

  const pathWhy = p => {
    if (typeof p !== "string" || !p) return "it is no path";
    if (p.includes("\\")) return "it holds a backslash";
    if (/^[A-Za-z]:/.test(p)) return "it names a drive";
    if (p.startsWith("/")) return "it starts at the root";
    if (p.split("/").some(s => s === "" || s === "." || s === "..")) return "it steps outside the vault";
    if (p === RECORDS || p.startsWith(RECORDS + "/")) return "the Store's records are the Store's";
    if (p.split("/").some(s => s.startsWith(".")) && !HIDDEN_OK.some(r => r.test(p))) return "it is a hidden file the Store does not write";
    return null;
  };

  const nums = v => String(v).replace(/^[\^~=v ]+/, "").split(".").map(n => parseInt(n, 10) || 0);
  function meets(range, version) {
    const want = nums(range), have = nums(version);
    if (have[0] !== want[0]) return false;
    for (let i = 1; i < Math.max(want.length, have.length); i++) { if ((have[i] || 0) !== (want[i] || 0)) return (have[i] || 0) > (want[i] || 0); }
    return true;
  }

  const two = n => String(n).padStart(2, "0");
  const stamp = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())} ${two(d.getHours())}-${two(d.getMinutes())}-${two(d.getSeconds())}`;
  const recordPath = id => `${RECORDS}/${id}.md`;
  const nameOf = pkg => pkg.name || pkg.id;

  function recordText(pkg) {
    const body = { id: pkg.id, kind: pkg.kind, name: nameOf(pkg), version: pkg.version, date: pkg.date || "",
      files: (pkg.files || []).map(f => ({ path: f.path, mode: f.mode })), views: (pkg.views || []).map(v => v.id), includes: (pkg.includes || []).slice() };
    return `---\nid: ${pkg.id}\nkind: ${pkg.kind}\nversion: "${pkg.version}"\ndate: ${pkg.date || ""}\ntype: vault-store-record\n---\n\n` +
      `${nameOf(pkg)} ${pkg.version} is installed. The Store keeps this note to know what it installed; deleting it makes the Store treat ${nameOf(pkg)} as not installed.\n\n` +
      FENCE + "json\n" + JSON.stringify(body, null, 1) + "\n" + FENCE + "\n";
  }

  async function installed(io) {
    const out = [];
    for (const p of await io.list(RECORDS)) {
      if (!p.endsWith(".md")) continue;
      const text = await io.read(p);
      const m = /`{3}json\r?\n([\s\S]*?)\r?\n`{3}/.exec(text || "");
      if (!m) continue;
      let r = null;
      try { r = JSON.parse(m[1]); } catch (e) { continue; }
      if (!r || !r.id || !r.kind || !Array.isArray(r.files)) continue;
      if (r.files.some(f => !f || pathWhy(f.path))) continue;
      out.push({ views: [], includes: [], ...r });
    }
    return out;
  }

  async function plan(pkg, io) {
    const p = { id: pkg && pkg.id, kind: pkg && pkg.kind, version: pkg && pkg.version, from: null, add: [], replace: [], keep: [], drop: [],
      views: { add: [], replace: [] }, reload: false, refused: null };
    const refuse = why => { p.refused = why; return p; };
    if (!pkg || !pkg.id || !pkg.kind || !pkg.version || !Array.isArray(pkg.files)) return refuse("refuses this package: it says no id, kind, version or files");
    if (pkg.kind === "bundle") return refuse("refuses this package: a bundle is installed as its items");
    for (const f of pkg.files) { const why = pathWhy(f.path); if (why) return refuse(`refuses ${f.path || "a file with no path"}: ${why}`); }
    const records = await installed(io);
    const edition = records.find(r => r.kind === "edition");
    const need = pkg.requires && pkg.requires.core;
    if (need && pkg.kind !== "edition") {
      if (!edition) return refuse(`${nameOf(pkg)} needs Core`);
      if (!meets(need, edition.version)) return refuse(`${nameOf(pkg)} needs Core ${String(need).replace(/^\^/, "")} or later; this vault has ${edition.version}`);
    }
    const before = records.filter(r => r.id === pkg.id || (pkg.kind === "edition" && r.kind === "edition"));
    const same = before.find(r => r.id === pkg.id);
    p.from = same ? same.version : null;
    const paths = new Set(pkg.files.map(f => f.path));
    for (const f of pkg.files) {
      const there = (await io.read(f.path)) != null;
      if (f.mode === "seeded") (there ? p.keep : p.add).push(f.path);
      else (there ? p.replace : p.add).push(f.path);
    }
    for (const r of before) for (const f of r.files)
      if (f.mode === "owned" && !paths.has(f.path) && !p.drop.includes(f.path) && (await io.read(f.path)) != null) p.drop.push(f.path);
    const have = new Set((await io.views()).map(v => v.id));
    for (const v of pkg.views || []) (have.has(v.id) ? p.views.replace : p.views.add).push(v.id);
    p.reload = (pkg.views || []).some(v => v.id === "core-hall");
    return p;
  }

  async function backUp(io, now, paths, viewsToo) {
    if (!paths.length && !viewsToo) return null;
    let dir = `${BACKUPS}/${stamp(now)}`;
    for (let n = 2; (await io.list(dir)).length; n++) dir = `${BACKUPS}/${stamp(now)} (${n})`;
    for (const path of paths) { const text = await io.read(path); if (text != null) await io.write(`${dir}/${path}`, text); }
    if (viewsToo) await io.write(`${dir}/views.json`, JSON.stringify(await io.views(), null, 1));
    return dir;
  }

  async function apply(pkg, io, { now = new Date() } = {}) {
    const p = await plan(pkg, io);
    if (p.refused) throw new Error(p.refused);
    const records = await installed(io);
    const others = records.filter(r => r.id !== pkg.id && pkg.kind === "edition" && r.kind === "edition");
    const backup = await backUp(io, now, [...p.replace, ...p.drop, ...others.map(r => recordPath(r.id))], p.replace.length + p.drop.length + p.views.replace.length > 0);
    for (const f of pkg.files) if (!(f.mode === "seeded" && p.keep.includes(f.path))) await io.write(f.path, f.text);
    for (const path of p.drop) await io.remove(path);
    if ((pkg.views || []).length) {
      const fresh = new Map(pkg.views.map(v => [v.id, v]));
      const current = await io.views();
      const merged = current.map(v => fresh.has(v.id) ? fresh.get(v.id) : v);
      for (const v of pkg.views) if (!current.some(x => x.id === v.id)) merged.push(v);
      await io.setViews(merged);
    }
    for (const r of others) await io.remove(recordPath(r.id));
    await io.write(recordPath(pkg.id), recordText(pkg));
    return { plan: p, backup };
  }

  async function remove(id, io, { now = new Date() } = {}) {
    const r = (await installed(io)).find(x => x.id === id);
    if (!r) throw new Error(`${id} is not installed`);
    if (r.kind === "edition") throw new Error("an edition is not removed");
    const owned = [];
    for (const f of r.files) if (f.mode === "owned" && (await io.read(f.path)) != null) owned.push(f.path);
    const kept = r.files.filter(f => f.mode !== "owned").map(f => f.path);
    const backup = await backUp(io, now, [...owned, recordPath(id)], r.views.length > 0);
    for (const path of owned) await io.remove(path);
    if (r.views.length) { const gone = new Set(r.views); await io.setViews((await io.views()).filter(v => !gone.has(v.id))); }
    await io.remove(recordPath(id));
    return { removed: owned, kept, views: r.views.slice(), backup };
  }

  return { plan, apply, remove, installed, recordText, meets };
})();

const VAULT_STORE = (() => {
  const CV = ".obsidian/plugins/custom-views/data.json";
  const norm = p => String(p == null ? "" : p).replace(/\\/g, "/").replace(/^\/+/, "");
  const parentOf = p => p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
  const parse = t => { try { return JSON.parse(t); } catch (e) { return null; } };
  const copy = o => JSON.parse(JSON.stringify(o));

  function obsidianIO(app) {
    const A = app.vault.adapter;
    const plugin = () => (app.plugins && app.plugins.plugins && app.plugins.plugins["custom-views"]) || null;
    async function ensure(dir) {
      if (!dir || (await A.exists(dir))) return;
      await ensure(parentOf(dir));
      await A.mkdir(dir);
    }
    const UNREAD = "the Custom Views store could not be read, so its views are not changed";
    async function held() {
      const pl = plugin();
      if (pl && pl.settings) {
        if (!Array.isArray(pl.settings.views) || typeof pl.saveSettings !== "function") throw new Error(UNREAD);
        return { pl, views: pl.settings.views };
      }
      const text = await io.read(CV);
      if (text == null) return { pl: null, file: {}, views: [] };
      const d = parse(text);
      if (!d || typeof d !== "object" || (d.views != null && !Array.isArray(d.views))) throw new Error(UNREAD);
      return { pl: null, file: d, views: d.views || [] };
    }
    const io = {
      name: typeof app.vault.getName === "function" ? app.vault.getName() : "this vault",
      reloadNeeded: false,
      async read(p) {
        p = norm(p);
        try { return (await A.exists(p)) ? await A.read(p) : null; } catch (e) { return null; }
      },
      async write(p, text) { p = norm(p); await ensure(parentOf(p)); await A.write(p, text); },
      async remove(p) { p = norm(p); if (await A.exists(p)) await A.remove(p); },
      async list(dir) {
        const out = [];
        const walk = async d => {
          if (d && !(await A.exists(d))) return;
          const r = await A.list(d || "/");
          out.push(...(r.files || []).map(norm));
          for (const f of r.folders || []) await walk(norm(f));
        };
        await walk(norm(dir).replace(/\/+$/, ""));
        return out;
      },
      async views() { return copy((await held()).views); },
      async setViews(list) {
        const h = await held();
        if (h.pl) {
          h.pl.settings.views = copy(list);
          await h.pl.saveSettings();
          if (typeof h.pl.refreshAllViews === "function") h.pl.refreshAllViews();
          return;
        }
        await io.write(CV, JSON.stringify({ ...h.file, views: copy(list) }, null, 2));
        io.reloadNeeded = true;
      },
      async viewsNote() {
        if (!io.reloadNeeded) return null;
        const installed = (app.plugins && app.plugins.manifests && app.plugins.manifests["custom-views"]) || (await io.read(".obsidian/plugins/custom-views/manifest.json")) != null;
        return installed ? "turn Custom Views on in Settings, Community plugins (or reload Obsidian if it is on) for the views to show"
          : "the views show once Custom Views is installed and turned on, from Settings, Community plugins";
      },
    };
    return io;
  }

  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const two = n => String(n).padStart(2, "0");
  const isoDay = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
  const spoken = d => `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${two(d.getHours())}:${two(d.getMinutes())}`;
  function newer(a, b) {
    const x = String(a || "0").split(".").map(Number), y = String(b || "0").split(".").map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  }
  const maskKey = (text, answer) => "••••" + String((answer && answer.id) || text || "").slice(-4);
  const itemsOf = st => (st.catalogue && Array.isArray(st.catalogue.items) ? st.catalogue.items : []);
  const recordOf = (st, id) => (st.installed || []).find(r => r.id === id) || null;
  function freeIds(items) {
    const s = new Set();
    for (const it of items) if (it.free) { s.add(it.id); for (const x of it.includes || []) s.add(x); }
    return s;
  }
  function endedFor(item, st) {
    const items = itemsOf(st);
    for (const k of st.keys || []) {
      const a = k.answer || {};
      if (!a.ok || !(a.until || a.updates)) continue;
      const named = VAULT_KEYS.names({ i: a.items || [] }, items);
      if (!VAULT_KEYS.covers(named, { id: item.id, kind: item.kind, date: item.date })) continue;
      if (a.until && String(item.date || "") > a.until) return `your yearly ended on ${a.until}; this version came after`;
      if (a.updates && item.kind === "addon" && String(item.date || "") > a.updates) return `your updates ended on ${a.updates}; this version came after`;
    }
    return null;
  }
  const removable = (item, st) => item.kind === "addon" || (item.kind === "theme" && !!st.themeInUse && item.id !== st.themeInUse);

  function pressFor(item, st) {
    if (item.kind === "bundle") return "get";
    const have = recordOf(st, item.id);
    const cover = freeIds(itemsOf(st)).has(item.id) || (st.covered || []).includes(item.id);
    if (!have && item.kind === "edition") {
      const ed = (st.installed || []).find(r => r.kind === "edition");
      if (ed && (item.free || !freeIds(itemsOf(st)).has(ed.id))) return null;
    }
    if (!have) return cover ? "install" : "get";
    if (newer(item.version, have.version)) return cover ? "update" : endedFor(item, st) ? null : "get";
    return removable(item, st) ? "remove" : null;
  }
  const onFree = st => { const ed = (st.installed || []).find(r => r.kind === "edition"); return !!ed && freeIds(itemsOf(st)).has(ed.id); };
  const coreOnly = item => item.kind === "theme" || item.kind === "addon"
    || (item.kind === "bundle" && !(item.items || []).some(i => i === "*" || i === "core"));
  function row(item, st) {
    const have = recordOf(st, item.id);
    let press = pressFor(item, st), why = null;
    if (!have && coreOnly(item) && onFree(st) && !freeIds(itemsOf(st)).has(item.id)) {
      const core = itemsOf(st).find(i => i.kind === "edition" && !i.free);
      press = null; why = `needs ${(core && core.name) || "Core"}`;
    }
    if (press === null && have && newer(item.version, have.version)) why = endedFor(item, st);
    if (st.online === false && (press === "install" || press === "update")) { press = null; why = "this needs the Store, which could not be reached"; }
    return { id: item.id, name: item.name || item.id, kind: item.kind, version: item.version, have: have ? have.version : null, press, why,
      about: item.about || "", price: item.price || "" };
  }
  function sections(st) {
    const items = itemsOf(st), now = st.now || new Date();
    const edRec = (st.installed || []).find(r => r.kind === "edition") || null;
    const edItem = edRec ? items.find(i => i.id === edRec.id) || { id: edRec.id, name: edRec.name || edRec.id } : null;
    const updates = items.filter(i => i.kind !== "bundle" && recordOf(st, i.id) && newer(i.version, recordOf(st, i.id).version)).map(i => row(i, st));
    const due = updates.filter(u => u.press === "update").length;
    const since = st.lastOpened || isoDay(new Date(now.getTime() - 30 * 864e5));
    const fresh = items.filter(i => i.kind !== "bundle" && i.kind !== "edition" && !recordOf(st, i.id) && i.first && i.first > since).map(i => row(i, st));
    const paid = items.find(i => i.kind === "edition" && !i.free);
    return {
      vault: {
        line: edRec ? `${edItem.name} ${edRec.version} · ${due ? `${due} update${due === 1 ? "" : "s"}` : "up to date"}` : "No edition is recorded in this vault",
        upgrade: edItem && freeIds(items).has(edItem.id) && paid ? row(paid, st) : null,
      },
      offline: st.online === false ? `${st.local ? "The Store on this computer is not running" : "The Store could not be reached"}${st.readAt ? `: the list as read on ${spoken(new Date(st.readAt))}` : ", and no list has been read on this device yet"}` : null,
      keys: (st.keys || []).map(k => ({ mask: maskKey(k.text, k.answer), ok: !!(k.answer && k.answer.ok), why: (k.answer && k.answer.why) || null,
        name: (k.answer && k.answer.name) || "", covers: (k.answer && k.answer.items) || [], until: (k.answer && k.answer.until) || null, updates: (k.answer && k.answer.updates) || null })),
      updates, fresh,
      addons: items.filter(i => i.kind === "addon").map(i => row(i, st)),
      themes: items.filter(i => i.kind === "theme").map(i => row(i, st)),
      bundles: items.filter(i => i.kind === "bundle").map(i => row(i, st)),
      installed: (st.installed || []).map(r => { const it = items.find(i => i.id === r.id) || { id: r.id, name: r.name || r.id, kind: r.kind, version: r.version };
        return { ...row(it, st), press: removable(it, st) ? "remove" : null, why: null }; }),
    };
  }
  const countFor = st => { const s = sections(st); return s.updates.filter(u => u.press === "update").length + s.fresh.length; };

  const CACHE = "neurora-store-catalogue";
  function catalogueCache(app) {
    return {
      read() { try { const v = app.loadLocalStorage(CACHE); const o = typeof v === "string" ? parse(v) : v; return o && o.catalogue ? { catalogue: o.catalogue, at: o.at } : null; } catch (e) { return null; } },
      write(catalogue, at = new Date()) { try { app.saveLocalStorage(CACHE, JSON.stringify({ catalogue, at: new Date(at).toISOString() })); } catch (e) { } },
    };
  }

  const HOUR = 36e5;
  const DEFAULT_URL = "https://store.jamn.workers.dev";
  const OPENED = "neurora-store-opened", COVERS = "neurora-store-covers", CHECKED = "neurora-store-checked";
  const SETTINGS = "99_Meta/Vault Settings.md";
  const recordPath = id => `99_Meta/Store/${id}.md`;
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const KIND_WORD = { edition: "edition", addon: "add-on", theme: "theme", bundle: "bundle" };
  const PRESS_WORD = { install: "Install", update: "Update", get: "Get it", remove: "Remove" };
  const plural = (n, one, many = one + "s") => `${n} ${n === 1 ? one : many}`;
  const keysOf = s => [].concat(s.store_keys || []).map(k => String(k).replace(/\s+/g, "")).filter(Boolean);
  const checkOn = s => !(s.store_check === false || String(s.store_check).trim().toLowerCase() === "false");
  const baseOf = s => String(s.store_url || DEFAULT_URL).trim().replace(/\/+$/, "");
  const local = (app, k) => { try { const v = app.loadLocalStorage(k); return typeof v === "string" ? parse(v) : v || null; } catch (e) { return null; } };
  const keep = (app, k, v) => { try { app.saveLocalStorage(k, v == null ? null : JSON.stringify(v)); } catch (e) { } };

  function asker(settings) {
    const base = baseOf(settings);
    return async (route, body) => {
      let req = null;
      try { const o = require("obsidian"); if (o && o.requestUrl) req = o.requestUrl; } catch (e) { }
      try { if (!req && window.requestUrl) req = window.requestUrl; } catch (e) { }
      const post = body !== undefined;
      if (req) {
        const r = await req({ url: base + route, method: post ? "POST" : "GET", contentType: "application/json", body: post ? JSON.stringify(body) : undefined, headers: { Accept: "application/json" }, throw: false });
        let json = null; try { json = r.json; } catch (e) { }
        return { status: r.status, json, text: r.text };
      }
      const r = await fetch(base + route, { method: post ? "POST" : "GET", body: post ? JSON.stringify(body) : undefined, headers: post ? { Accept: "application/json", "content-type": "application/json" } : { Accept: "application/json" } });
      const text = await r.text();
      return { status: r.status, json: parse(text), text };
    };
  }
  async function call(ask, route, body) {
    const r = await ask(route, body);
    let j = r && r.json != null ? r.json : r && typeof r.text === "string" ? parse(r.text) : null;
    if (!r || !j || typeof j !== "object") throw new Error(`the Store answered ${r && r.status ? r.status : "nothing"}, not with its own reply`);
    if (!(r.status >= 200 && r.status < 300)) { const e = new Error(String(j.why || `the Store answered ${r.status}`)); e.refused = true; throw e; }
    return j;
  }
  const unreached = e => e && (e.refused || /^the Store answered/.test(String(e.message))) ? String(e.message) : null;
  const optsOf = (ctx, o = {}) => ({ ask: o.ask || asker(ctx.settings || {}), now: o.now || new Date(), open: o.open || (u => { try { window.open(u); } catch (e) { } }) });
  const sayOf = ctx => label => { try { (ctx.ui && ctx.ui.toast ? ctx.ui.toast : ctx.NV.toast)(label); } catch (e) { } };
  const PAGES = new WeakMap();

  async function stateOf(ctx, o, { fresh }) {
    const app = ctx.app, s = ctx.settings || {}, io = obsidianIO(app), cache = catalogueCache(app), keys = keysOf(s);
    const records = await VAULT_INSTALL.installed(io);
    let catalogue = null, readAt = null, online = true, why = null, answer = null;
    if (fresh) {
      try {
        const c = await call(o.ask, "/catalogue");
        if (!Array.isArray(c.items)) throw new Error("the Store's list holds no items");
        cache.write(c, o.now); catalogue = c; readAt = new Date(o.now).toISOString();
        keep(app, CHECKED, { at: readAt });
      } catch (e) { online = false; why = unreached(e); }
      if (online && keys.length) {
        try { answer = await call(o.ask, "/covers", { keys }); keep(app, COVERS, { keys, answer }); }
        catch (e) { if (e.refused) why = `the keys could not be checked: ${e.message}`; else { online = false; why = unreached(e); } }
      }
    }
    if (!catalogue) { const c = cache.read(); catalogue = c ? c.catalogue : { items: [] }; readAt = c ? c.at : null; }
    if (!answer) { const c = local(app, COVERS); answer = c && JSON.stringify(c.keys) === JSON.stringify(keys) ? c.answer : null; }
    const shown = keys.map((text, i) => {
      const a = answer && Array.isArray(answer.keys) ? answer.keys[i] : null, r = VAULT_KEYS.read(text), p = r.ok ? r.payload : {};
      return { text, answer: a || { ok: false, unchecked: true, id: p.k ? String(p.k) : "", name: p.n ? String(p.n) : "", items: (p.i || []).map(String), until: p.u ? String(p.u) : undefined, updates: p.a ? String(p.a) : undefined } };
    });
    const opened = local(app, OPENED);
    return { io, records, catalogue, readAt, online: fresh ? online : !!(answer || local(app, CHECKED)), local: /^https?:\/\/(127\.|localhost|\[::1\])/.test(baseOf(s)), why, keys: shown,
      covered: answer && Array.isArray(answer.covered) ? answer.covered.map(String) : [],
      installed: records.map(r => ({ id: r.id, kind: r.kind, version: r.version, name: r.name })), themeInUse: String(s.style || "").trim().toLowerCase() || null,
      lastOpened: opened && opened.day ? opened.day : null, now: o.now };
  }

  function setCount(ctx, n) {
    try { const t = ctx.ui && ctx.ui.tab && ctx.ui.tab(), b = t && t.querySelector(".vc-tab-n"); if (b) b.textContent = n ? String(n) : ""; } catch (e) { }
  }

  function coversWords(items, catalogue) {
    const byId = new Map(((catalogue && catalogue.items) || []).map(i => [i.id, i.name]));
    const words = (items || []).map(x => x === "*" ? "everything" : x === "*theme" ? "every theme" : byId.get(x) || x);
    return words.length ? words.join(", ") : "nothing yet";
  }

  function rowHtml(r) {
    const ver = r.have && r.version && r.have !== r.version ? `${esc(r.have)} → ${esc(r.version)}` : esc(r.version || r.have || "");
    const cls = r.press === "install" || r.press === "update" ? " vc-b--hot" : r.press === "remove" ? " vc-b--warn" : "";
    const btn = r.press ? `<button class="vc-b vc-b--sm${cls}" data-st-press="${r.press}" data-st-id="${esc(r.id)}" aria-label="${esc(PRESS_WORD[r.press] + " " + r.name)}">${PRESS_WORD[r.press]}</button>` : "";
    const done = !r.press && !r.why && r.have ? `<span class="vc-tag vc-tag--good">installed</span>` : "";
    const price = r.press === "get" && r.price ? `<span class="vc-row-v">${esc(r.price)}</span>` : "";
    return `<div class="vc-row st-row" data-st-row="${esc(r.id)}"><span class="vc-row-k"><b>${esc(r.name)}</b> <span class="st-ver">${ver}</span>` +
      `<span class="vc-sub">${esc(r.about || KIND_WORD[r.kind] || "")}</span>${r.why ? `<span class="vc-sub st-why">${esc(r.why)}</span>` : ""}</span>${price}${done}${btn}</div>`;
  }
  const block = (title, sub, body) => `<div class="vc-plate st-block"><div class="vc-label">${esc(title)}${sub ? `<small>${esc(sub)}</small>` : ""}</div>${body}</div>`;

  function render(ctx, st, raw) {
    const panel = ctx.ui && ctx.ui.panel && ctx.ui.panel(); if (!panel) return;
    const S = sections(st), on = checkOn(ctx.settings || {});
    const due = S.updates.filter(u => u.press === "update").length;
    const keys = S.keys.map((k, i) => {
      const a = st.keys[i].answer || {};
      const state = a.unchecked ? (st.online === false ? "not checked: the Store could not be reached" : a.why ? `not checked: ${a.why}` : "not checked yet") : a.ok ? `covers ${coversWords(a.items, st.catalogue)}` : String(a.why || "not accepted");
      return `<div class="vc-row st-key"><span class="vc-row-k"><b>${esc(k.mask)}</b>${k.name ? ` ${esc(k.name)}` : ""}<span class="vc-sub">${esc(state)}${a.until ? ` · yearly to ${esc(a.until)}` : a.renews ? " · yearly, while it runs" : ""}${a.updates ? ` · add-on updates to ${esc(a.updates)}` : ""}</span></span>` +
        `<button class="vc-b vc-b--sm vc-b--bare" data-st-press="key-change" data-st-i="${i}" aria-label="change the key ${esc(k.mask)}">change key</button>` +
        `<button class="vc-b vc-b--sm vc-b--bare vc-b--warn" data-st-press="key-remove" data-st-i="${i}" aria-label="remove the key ${esc(k.mask)}">remove</button></div>`;
    }).join("");
    const list = rows => rows.length ? rows.map(rowHtml).join("") : `<p class="vc-empty">None in the Store's list.</p>`;
    const up = S.vault.upgrade;
    panel.innerHTML = `<div class="st-page" data-st-page>` +
      `<div class="vc-plate st-block st-vault"><div class="st-head"><div class="st-meta"><span class="st-line">${esc(S.vault.line)}</span>` +
      (S.offline ? `<span class="vc-sub st-off">${esc(S.offline)}${st.why ? `: ${esc(st.why)}` : ""}</span>` : st.why ? `<span class="vc-sub st-why">${esc(st.why)}</span>` : st.readAt ? `<span class="vc-sub">the list as read on ${esc(spoken(new Date(st.readAt)))}</span>` : "") +
      `</div><button class="vc-b vc-b--sm" data-st-press="again">Check again</button></div>` +
      (up ? `<div class="st-up">${rowHtml({ ...up, about: `Upgrade to ${up.name}` })}</div>` : "") + `</div>` +
      block("Keys", S.keys.length ? plural(S.keys.length, "key") : "none yet", keys + `<div class="vc-empty-a"><button class="vc-b vc-b--sm" data-st-press="key-add">${S.keys.length ? "Add another key" : "Add a key"}</button></div>`) +
      (S.updates.length ? block("Updates", "", S.updates.map(rowHtml).join("") + (due >= 2 ? `<div class="vc-empty-a"><button class="vc-b vc-b--sm vc-b--hot" data-st-press="update-all">Update all ${due}</button></div>` : "")) : "") +
      (S.fresh.length ? block("New", st.lastOpened ? `since ${st.lastOpened}` : "in the last 30 days", S.fresh.map(rowHtml).join("")) : "") +
      (S.addons.length + S.themes.length + S.bundles.length ? block("Add-ons", "", list(S.addons)) + block("Themes", "", list(S.themes)) + block("Bundles", "", list(S.bundles))
        : `<p class="vc-empty st-none">Nothing from the Store yet: <b>Check again</b> once this device is online.</p>`) +
      block("Installed", plural(S.installed.length, "item"), S.installed.length ? S.installed.map(rowHtml).join("") : `<p class="vc-empty">Nothing is recorded as installed in this vault.</p>`) +
      `<div class="st-foot"><button class="vc-b vc-b--sm${on ? " vc-b--hot" : ""}" data-st-press="check" aria-pressed="${on}">${on ? "On" : "Off"}</button>` +
      `<span class="st-foot-w">Check for new things when the Hall opens: at most once an hour, with no key sent</span></div></div>`;
    panel.querySelectorAll("[data-st-press]").forEach(b => b.addEventListener("click", e => {
      if (e && e.preventDefault) e.preventDefault();
      return act(ctx, b.getAttribute("data-st-press"), b.getAttribute("data-st-id"), raw, b.getAttribute("data-st-i"));
    }));
    PAGES.set(panel, st);
  }

  async function draw(ctx, raw = {}) {
    const o = optsOf(ctx, raw), panel = ctx.ui && ctx.ui.panel && ctx.ui.panel();
    if (!panel) return;
    try {
      const st = await stateOf(ctx, o, { fresh: true });
      render(ctx, st, raw);
      keep(ctx.app, OPENED, { day: isoDay(o.now) });
      setCount(ctx, countFor({ ...st, lastOpened: isoDay(o.now) }));
    } catch (e) { panel.innerHTML = `<p class="vc-empty">The Store could not be drawn: ${esc(e.message)}</p>`; }
  }
  async function again(ctx, raw) {
    const o = optsOf(ctx, raw), st = await stateOf(ctx, o, { fresh: false });
    const was = ctx.ui && ctx.ui.panel && PAGES.get(ctx.ui.panel());
    if (was) { st.online = was.online; st.why = was.why; }
    render(ctx, st, raw);
    setCount(ctx, countFor({ ...st, lastOpened: isoDay(o.now) }));
    return st;
  }

  async function boot(ctx, raw = {}) {
    const o = optsOf(ctx, raw), app = ctx.app;
    if (checkOn(ctx.settings || {})) {
      const last = local(app, CHECKED);
      if (!last || !(o.now - new Date(last.at) < HOUR)) {
        keep(app, CHECKED, { at: new Date(o.now).toISOString() });
        try { const c = await call(o.ask, "/catalogue"); if (Array.isArray(c.items)) catalogueCache(app).write(c, o.now); } catch (e) { }
      }
    }
    if (!catalogueCache(app).read()) { setCount(ctx, 0); return 0; }
    const n = countFor(await stateOf(ctx, o, { fresh: false }));
    setCount(ctx, n);
    return n;
  }

  const figures = p => [`${plural(p.add.length, "file")} added`, `${p.replace.length} replaced`, `${p.keep.length} kept`]
    .concat(p.drop.length ? [`${p.drop.length} taken out`] : [])
    .concat(p.views.add.length || p.views.replace.length ? [`${plural(p.views.add.length, "view")} added, ${p.views.replace.length} replaced`] : []).join(", ");
  const refusedWords = why => /^refuses /.test(why) ? `The installer ${why}` : why.charAt(0).toUpperCase() + why.slice(1);

  let working = false;
  async function act(ctx, what, id, raw = {}, i = null) {
    const o = optsOf(ctx, raw), say = sayOf(ctx);
    if (working && what !== "again") { say("Still working on the last press"); return; }
    working = what !== "again";
    try {
      if (what === "again") { await draw(ctx, raw); return; }
      if (what === "check") return await checkSwitch(ctx, raw);
      if (/^key-/.test(what)) return await keyPress(ctx, what, Number(i), raw);
      const panel = ctx.ui && ctx.ui.panel && ctx.ui.panel();
      const st = await stateOf(ctx, o, { fresh: false }), was = panel && PAGES.get(panel);
      if (was) { st.online = was.online; st.covered = was.covered; }
      const items = (st.catalogue && st.catalogue.items) || [];
      const item = items.find(x => x.id === id), rec = st.records.find(r => r.id === id);
      const name = (item && item.name) || (rec && rec.name) || id;
      if (what === "remove") return await removeOne(ctx, st, rec, name, raw);
      if (what === "get") {
        const u = String((item && item.shop && item.shop.url) || (st.catalogue && st.catalogue.getIt) || "");
        if (!/^https:\/\/\S+$/.test(u)) { say(`${esc(name)} is not on sale yet`); return; }
        o.open(u); return;
      }
      if (what === "install" || what === "update") return await installMany(ctx, st, [item || { id, name }], raw);
      if (what === "update-all") return await installMany(ctx, st, sections(st).updates.filter(u => u.press === "update").map(u => items.find(x => x.id === u.id)).filter(Boolean), raw);
    } catch (e) { say(esc(e && e.message ? e.message : String(e))); }
    finally { if (what !== "again") working = false; }
  }

  async function installMany(ctx, st, items, raw) {
    const o = optsOf(ctx, raw), say = sayOf(ctx), keys = keysOf(ctx.settings || {});
    if (!items.length) return;
    if (st.online === false) { say("The Store could not be reached, so nothing can be installed just now"); return; }
    items = items.slice().sort((a, b) => (a.kind === "edition" ? 0 : 1) - (b.kind === "edition" ? 0 : 1));
    const got = [];
    for (const it of items) {
      const pkg = await call(o.ask, "/package", { keys, id: it.id });
      const p = await VAULT_INSTALL.plan(pkg, st.io);
      if (p.refused) { say(esc(refusedWords(p.refused))); return; }
      got.push({ it, pkg, p });
    }
    const one = got.length === 1, verb = one ? (got[0].p.from ? "Update" : "Install") : "Update";
    const title = one ? `${verb} ${got[0].it.name || got[0].pkg.name || got[0].pkg.id} ${got[0].pkg.version}` : `Update ${got.length} items`;
    const lines = got.map(g => `${one ? "" : `${g.it.name || g.pkg.id} ${g.p.from ? g.p.from + " → " : ""}${g.pkg.version}: `}${figures(g.p)}.`);
    const body = esc(lines.join(" ")) + (got.some(g => g.p.reload) ? " The Hall is drawn again afterwards." : "") +
      " Whatever is replaced or taken out is copied to .neurora/backups first.";
    if (!(await ctx.NV.modal({ title, body, confirmText: verb.toLowerCase() }))) return;
    const done = [];
    let failed = null;
    for (const g of got) {
      try { const r = await VAULT_INSTALL.apply(g.pkg, st.io, { now: o.now }); done.push({ ...g, backup: r.backup }); }
      catch (e) { failed = { g, why: String(e && e.message || e) }; break; }
    }
    const nm = g => g.it.name || g.pkg.name || g.pkg.id;
    const label = !done.length ? `<b>${esc(nm(failed.g))} ${esc(failed.g.pkg.version)}</b> was not ${failed.g.p.from ? "updated" : "installed"}`
      : done.length === 1 && one
        ? `<b>${esc(nm(done[0]))} ${esc(done[0].pkg.version)}</b> ${done[0].p.from ? "updated" : "installed"}: ${esc(figures(done[0].p))}`
        : `<b>${plural(done.length, "item")}</b> updated: ${esc(done.map(g => `${nm(g)} ${g.pkg.version}`).join(", "))}`;
    const said = done.filter(d => d.backup).map(d => `backed up to ${d.backup}`);
    if (failed) said.push(`${nm(failed.g)} ${failed.g.pkg.version} stopped partway: ${failed.why}. Its own files are as far as it got; Update tries it again`);
    const needs = await st.io.viewsNote();
    await ctx.NV.receipt(label + (needs ? `; ${needs}` : ""), done.length ? recordPath(done[0].pkg.id) : null, null, { lines: said });
    await again(ctx, raw);
  }

  async function removeOne(ctx, st, rec, name, raw) {
    const o = optsOf(ctx, raw), say = sayOf(ctx);
    if (!rec) { say(`${esc(name)} is not installed`); return; }
    if (rec.kind === "edition") { say(`${esc(name)} is this vault's edition, and an edition is not removed: another edition replaces it`); return; }
    if (rec.kind === "theme" && (!st.themeInUse || st.themeInUse === rec.id)) { say(`${esc(name)} is the theme in use: choose another in Settings before removing it`); return; }
    const owned = [];
    for (const f of rec.files) if (f.mode === "owned" && (await st.io.read(f.path)) != null) owned.push(f.path);
    const kept = rec.files.filter(f => f.mode !== "owned").length;
    const body = `${esc(plural(owned.length, "file"))} ${owned.length === 1 ? "goes" : "go"}` + (rec.views.length ? `, and ${esc(plural(rec.views.length, "view"))} ${rec.views.length === 1 ? "goes" : "go"}` : "") + "." +
      (kept ? ` ${esc(plural(kept, "note"))} you may have written in ${kept === 1 ? "stays" : "stay"}.` : "") + " What goes is copied to .neurora/backups first.";
    if (!(await ctx.NV.modal({ title: `Remove ${name}`, body, confirmText: "remove", danger: true }))) return;
    const r = await VAULT_INSTALL.remove(rec.id, st.io, { now: o.now });
    await ctx.NV.receipt(`${esc(name)} removed: ${esc(plural(r.removed.length, "file"))} gone, ${r.kept.length} kept` + (r.views.length ? `, ${esc(plural(r.views.length, "view"))} gone` : ""), null, null, { lines: r.backup ? [`backed up to ${r.backup}`] : [] });
    await again(ctx, raw);
  }

  async function writeSettings(ctx, patch, label) {
    const io = obsidianIO(ctx.app), path = (ctx.NV.settingsPath && ctx.NV.settingsPath()) || SETTINGS;
    const before = await io.read(path);
    if (!(await ctx.write(patch))) return false;
    await ctx.NV.receipt(label, path, before, {});
    return true;
  }
  async function checkSwitch(ctx, raw) {
    const on = checkOn(ctx.settings || {});
    if (await writeSettings(ctx, { store_check: on ? false : null }, on ? "The Store no longer checks when the Hall opens" : "The Store checks for new things when the Hall opens, at most once an hour"))
      await again(ctx, raw);
  }
  async function keyPress(ctx, what, i, raw) {
    const say = sayOf(ctx), keys = keysOf(ctx.settings || {});
    const tail = k => { const r = VAULT_KEYS.read(k); return maskKey(k, r.ok ? { id: String(r.payload.k) } : null); };
    let next;
    if (what === "key-remove") {
      if (!keys[i]) return;
      if (!(await ctx.NV.modal({ title: `Remove the key ${tail(keys[i])}`, body: "What it covers stays installed; an update to any of it asks for a key again.", confirmText: "remove", danger: true }))) return;
      next = keys.filter((_, j) => j !== i);
    } else {
      const change = what === "key-change" && keys[i] != null, first = !keys.length;
      const r = await ctx.NV.modal({ title: change ? `Change the key ${tail(keys[i])}` : first ? "Add a key" : "Add another key",
        body: first ? "Only your keys and the item asked for are sent to the Store, and never anything about this vault's notes." : "",
        fields: [{ value: change ? keys[i] : "", placeholder: "the key from your email" }], confirmText: change ? "change" : "add" });
      if (!r) return;
      const text = String(r[0] || "").replace(/\s+/g, "");
      const k = VAULT_KEYS.accepts(text);
      if (!k.ok) { say(`That ${esc(k.why)}`); return; }
      if (keys.includes(text)) { say("That key is here already"); return; }
      next = change ? keys.map((x, j) => j === i ? text : x) : keys.concat(text);
    }
    const label = what === "key-remove" ? "The key was removed from Vault Settings" : `The key ${esc(tail(next[what === "key-change" ? i : next.length - 1]))} was written to Vault Settings`;
    if (await writeSettings(ctx, { store_keys: next.length ? next : null }, label)) await draw(ctx, raw);
  }

  return { obsidianIO, sections, pressFor, countFor, maskKey, catalogueCache, draw, boot, act, install: VAULT_INSTALL, keys: VAULT_KEYS };
})();
```

```css
.st-page { max-width: 760px; margin: 0 auto; padding: calc(8px * var(--c-scale)) 0 calc(28px * var(--c-scale)); }
.st-head { display: flex; align-items: flex-start; gap: var(--c-gap); }
.st-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.st-line { font-family: var(--c-serif); font-size: var(--c-body); color: var(--c-tx); }
.st-off { color: var(--c-dim); }
.st-up { margin-top: calc(14px * var(--c-scale)); }
.st-row, .st-key { align-items: center; }
.st-row .vc-b, .st-key .vc-b { flex: 0 0 auto; }
.st-ver { font-family: var(--c-mono); font-size: var(--c-small); color: var(--c-dim); }
.st-why { color: var(--c-dim); font-style: italic; }
.st-foot { display: flex; align-items: center; gap: var(--c-gap); padding: 0 calc(24px * var(--c-scale)); color: var(--c-fnt); }
.st-foot-w { font-family: var(--c-serif); font-style: italic; font-size: var(--c-small); }
[data-cols="narrow"] .st-head { flex-direction: column; }
[data-cols="narrow"] .st-row, [data-cols="narrow"] .st-key { flex-wrap: wrap; }
.st-none { margin: 0 0 calc(26px * var(--c-scale)); }
```
