---
type: vault-module
---

# Vault-Long

Trends: the Hall's page that reads back what the daily notes have recorded over weeks and months, the
habits' year, a review written as a note, the starred lines and tags, and a month exported as one page.
The first block is the page; the second is its stylesheet. It is loaded the first time the page opens.

**Do not edit these blocks by hand.** They are read by this note's name and replaced whole whenever
the vault's code is updated, so anything typed here is lost.

```js
const VAULT_LONG = (() => {
  const VERSION = "1.0.0";
  const V = typeof VAULT_MODULE !== "undefined" ? VAULT_MODULE : null;
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const icon = (n, w) => (V && V.icon ? V.icon(n, w) : "");

  const pad = n => String(n).padStart(2, "0");
  const isoOf = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const atNoon = iso => new Date(iso + "T12:00:00");
  const shift = (iso, n) => { const d = atNoon(iso); d.setDate(d.getDate() + n); return isoOf(d); };
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const dayWords = iso => { const d = atNoon(iso); return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };
  const dayShort = iso => { const d = atNoon(iso); return `${d.getDate()} ${MONTHS[d.getMonth()].slice(0, 3)}`; };
  const isWeekend = iso => { const g = atNoon(iso).getDay(); return g === 0 || g === 6; };
  const isos = (from, to) => { const out = []; for (let d = from; d <= to; d = shift(d, 1)) out.push(d); return out; };

  const num = v => { if (v == null || v === "" || typeof v === "boolean") return null; const n = Number(String(v).replace(",", ".")); return Number.isFinite(n) ? n : null; };
  const mean = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : null;
  const plural = (n, w, ws) => `${n} ${n === 1 ? w : ws || w + "s"}`;
  const hm = h => { if (h == null) return "—"; const m = Math.round(h * 60); return `${Math.floor(m / 60)}h ${pad(m % 60)}m`; };
  const clock = m => m == null ? "—" : `${pad(Math.floor(m / 60) % 24)}:${pad(Math.round(m % 60))}`;
  const minsOf = s => { const m = String(s || "").trim().match(/^(\d{1,2})[:.](\d{2})/); return m ? +m[1] * 60 + +m[2] : null; };
  const signed = (d, k = 1) => Math.abs(d) < 0.5 * Math.pow(10, -k) ? "±0" : `${d > 0 ? "+" : "−"}${Math.abs(d).toFixed(k)}`;

  const TEXT = new Map();
  const folderOf = ctx => { try { return V.dailyFolder(ctx.app, ctx.settings); } catch (e) { return ""; } };
  function fileAt(ctx, folder, iso) { return ctx.app.vault.getAbstractFileByPath(`${folder ? folder + "/" : ""}${iso}.md`); }
  const fmOf = (ctx, f) => { try { return (f && (ctx.app.metadataCache.getFileCache(f) || {}).frontmatter) || {}; } catch (e) { return {}; } };
  async function textOf(ctx, f) {
    if (!f) return "";
    const k = f.path, m = (f.stat && f.stat.mtime) || 0, was = TEXT.get(k);
    if (was && was.m === m) return was.t;
    let t = ""; try { t = await ctx.app.vault.cachedRead(f); } catch (e) { t = ""; }
    TEXT.set(k, { m, t }); return t;
  }
  async function record(ctx, from, to, withText) {
    const folder = folderOf(ctx), out = [];
    for (const iso of isos(from, to)) {
      const file = fileAt(ctx, folder, iso), day = { iso, file, fm: fmOf(ctx, file), text: "" };
      if (file && withText) day.text = await textOf(ctx, file);
      out.push(day);
    }
    return out;
  }
  function allDays(ctx) {
    const folder = folderOf(ctx);
    return (ctx.app.vault.getMarkdownFiles() || []).filter(f => /^\d{4}-\d{2}-\d{2}$/.test(f.basename) && (!folder || f.path.startsWith(folder + "/")))
      .sort((a, b) => a.basename < b.basename ? 1 : -1);
  }

  const FOCUS_RE = /^-\s*focus::\s*(\d+)\s*(?:·\s*(\d{1,2}:\d{2}))?\s*(?:·\s*(.*))?$/;
  const ENTRY_RE = /^\*\*(\d{1,2}:\d{2})\*\*\s+—\s?(.*)$/;
  function focusOf(text) {
    const out = [];
    String(text || "").split("\n").forEach(l => { const m = l.trim().match(FOCUS_RE); if (m) out.push({ min: +m[1], what: String(m[3] || "").trim() }); });
    return out;
  }
  function entriesOf(text) {
    const L = String(text || "").replace(/\r/g, "").split("\n"), out = [];
    const h = L.findIndex(l => /^##\s+Journal\s*$/.test(l)); if (h < 0) return out;
    for (let i = h + 1; i < L.length && !/^#{1,2}\s/.test(L[i]); i++) {
      const m = L[i].match(ENTRY_RE); if (!m) continue;
      let first = m[2]; const star = /%%star%%/.test(first), tags = (first.match(/(?:^|\s)#([\w-]+)/g) || []).map(t => t.trim().slice(1));
      const mood = (first.match(/%%m:(\d)%%/) || [])[1];
      first = first.replace(/\s*%%m:\d%%/g, "").replace(/\s*%%star%%/g, "").replace(/(?:^|\s)#[\w-]+/g, "").trim();
      const more = []; for (let j = i + 1; j < L.length && L[j].trim() && !ENTRY_RE.test(L[j]) && !/^#|^%%|^>/.test(L[j]); j++) more.push(L[j].trim());
      out.push({ time: m[1], text: [first, ...more].join(" ").trim(), star, tags, mood: mood ? +mood : null, line: i });
    }
    return out;
  }
  const wakeOf = fm => minsOf(fm.wake != null ? fm.wake : fm.wake_time);
  const trained = fm => { const t = String(fm.training || "").trim().toLowerCase(); return !!t && t !== "rest" && t !== "none" && t !== "false"; };
  const MOODS = ["Locked in", "Energised", "Focused", "Steady", "Calm", "Slow start", "Foggy", "Tired", "Low"];
  const moodRank = w => { const i = MOODS.findIndex(m => m.toLowerCase() === String(w || "").trim().toLowerCase()); return i < 0 ? null : i; };

  const habitList = ctx => (Array.isArray(ctx.settings.habits) ? ctx.settings.habits : []).filter(h => h && h.id);
  function keeper(ctx, hs, recs) {
    const H = ctx.NV && typeof ctx.NV.habitsRead === "function" ? ctx.NV.habitsRead() : null;
    return (h, day) => H ? !!H.kept(h, Object.assign({}, (recs && recs[day.iso]) || {}, { fm: day.fm, text: day.text })) : day.fm["habit_" + h.id] === true;
  }
  async function habitRecs(ctx, hs, list) {
    const H = ctx.NV && typeof ctx.NV.habitsRead === "function" ? ctx.NV.habitsRead() : null;
    if (!H || !hs.length || !H.wants(hs).size || typeof ctx.NV.habitRecords !== "function") return null;
    try { return await ctx.NV.habitRecords(list, hs, { today: ctx.iso, read: f => textOf(ctx, f) }); } catch (e) { return null; }
  }

  const W = 520, PADL = 34, PADR = 8;
  function scaleOf(vals, h, pad = 0.08) {
    const v = vals.filter(x => x != null); if (!v.length) return null;
    let lo = Math.min(...v), hi = Math.max(...v); if (hi === lo) { lo -= 1; hi += 1; }
    const s = (hi - lo) * pad; lo -= s; hi += s;
    return { lo, hi, y: x => 12 + (h - 30) * (1 - (x - lo) / (hi - lo)) };
  }
  const xOf = (i, n) => PADL + (W - PADL - PADR) * (n <= 1 ? 0.5 : i / (n - 1));
  const axis = (sc, h, fmt) => `<g class="lv-ax">${[sc.hi, (sc.hi + sc.lo) / 2, sc.lo].map(v => `<text x="2" y="${sc.y(v) + 4}">${esc(fmt(v))}</text><line x1="${PADL}" x2="${W - PADR}" y1="${sc.y(v)}" y2="${sc.y(v)}"/>`).join("")}</g>`;
  const foot = (days, h) => `<g class="lv-ax">${[0, Math.floor((days.length - 1) / 2), days.length - 1].map((i, k) => `<text x="${xOf(i, days.length)}" y="${h - 4}" text-anchor="${["start", "middle", "end"][k]}">${esc(dayShort(days[i].iso))}</text>`).join("")}</g>`;
  function dotsChart(days, vals, fmt, h = 180, line = true) {
    const sc = scaleOf(vals, h); if (!sc) return "";
    const n = days.length, dots = vals.map((v, i) => v == null ? "" : `<circle class="lv-dot${i === n - 1 ? " lv-today" : ""}" cx="${xOf(i, n).toFixed(1)}" cy="${sc.y(v).toFixed(1)}" r="${n > 120 ? 1.8 : 3}"/>`).join("");
    let path = "";
    if (line) { const pts = vals.map((v, i) => { const w = vals.slice(Math.max(0, i - 6), i + 1).filter(x => x != null); return w.length ? [xOf(i, n), sc.y(mean(w))] : null; }).filter(Boolean);
      if (pts.length > 1) path = `<path class="lv-line" d="M${pts.map(p => p[0].toFixed(1) + "," + p[1].toFixed(1)).join("L")}"/>`; }
    return `<svg class="lv-ch" viewBox="0 0 ${W} ${h}" role="img">${axis(sc, h, fmt)}${path}${dots}${foot(days, h)}</svg>`;
  }
  function barsChart(days, vals, fmt, h = 180) {
    const v = vals.filter(x => x != null); if (!v.length) return "";
    const top = Math.max(...v) * 1.1, n = days.length, bw = Math.max(1, (W - PADL - PADR) / n - (n > 120 ? 0.5 : 2));
    const y = x => 12 + (h - 30) * (1 - x / top), m = mean(v);
    const bars = vals.map((x, i) => x == null ? "" : `<rect class="lv-bar" x="${(xOf(i, n) - bw / 2).toFixed(1)}" y="${y(x).toFixed(1)}" width="${bw.toFixed(1)}" height="${(h - 18 - y(x)).toFixed(1)}"/>`).join("");
    return `<svg class="lv-ch" viewBox="0 0 ${W} ${h}" role="img">${axis({ hi: top, lo: 0, y }, h, fmt)}${bars}<line class="lv-mean" x1="${PADL}" x2="${W - PADR}" y1="${y(m)}" y2="${y(m)}"/>${foot(days, h)}</svg>`;
  }
  function stackChart(weeks, keys, h = 180) {
    const tot = weeks.map(w => keys.reduce((s, k) => s + (w.by[k] || 0), 0)), top = Math.max(1, ...tot) * 1.1, n = weeks.length;
    const y = x => 12 + (h - 30) * (1 - x / top), bw = Math.max(2, (W - PADL - PADR) / n - 4);
    const bars = weeks.map((w, i) => { let acc = 0; return keys.map((k, j) => { const v = w.by[k] || 0; if (!v) return ""; const y0 = y(acc), y1 = y(acc + v); acc += v;
      return `<rect class="lv-st lv-st${j}" x="${(xOf(i, n) - bw / 2).toFixed(1)}" y="${y1.toFixed(1)}" width="${bw.toFixed(1)}" height="${(y0 - y1).toFixed(1)}"/>`; }).join(""); }).join("");
    return `<svg class="lv-ch" viewBox="0 0 ${W} ${h}" role="img">${axis({ hi: top, lo: 0, y }, h, v => `${Math.round(v)}h`)}${bars}<g class="lv-ax">${[0, n - 1].map((i, k) => `<text x="${xOf(i, n)}" y="${h - 4}" text-anchor="${k ? "end" : "start"}">${esc(dayShort(weeks[i].from))}</text>`).join("")}</g></svg>`;
  }
  function yearGrid(days, vals, label, kept) {
    const v = vals.filter(x => x != null), lo = v.length ? Math.min(...v) : 0, hi = v.length ? Math.max(...v) : 1;
    const lead = (atNoon(days[0].iso).getDay() + 6) % 7;
    const cells = Array(lead).fill(`<i class="lv-yc lv-pad"></i>`).concat(days.map((d, i) => {
      const x = vals[i]; if (x == null) return `<i class="lv-yc" title="${esc(dayWords(d.iso))} · nothing written"></i>`;
      const k = kept ? 1 : hi === lo ? 0.6 : (x - lo) / (hi - lo);
      return `<i class="lv-yc lv-on" style="--k:${(0.18 + 0.82 * k).toFixed(2)}" title="${esc(dayWords(d.iso))} · ${esc(label(x))}"></i>`;
    }));
    return `<div class="lv-year" role="img">${cells.join("")}</div>`;
  }

  const SPANS = [[14, "2 weeks"], [91, "3 months"], [365, "A year"]];
  const TABS = [["trends", "Trends", "graph"], ["year", "The habits' year", "repeat"], ["review", "Review", "diary"], ["starred", "Starred and tags", "star"], ["export", "Export a month", "export"]];
  const words = v => Array.isArray(v) ? v.map(x => String(x).trim()).filter(Boolean) : String(v || "").split(/[,\s]+/).filter(Boolean);
  const spanOf = s => { const n = Number(s.trends_span); return SPANS.some(x => x[0] === n) ? n : 91; };
  const compareOn = s => !(s.trends_compare === false || String(s.trends_compare).toLowerCase() === "false");

  const OWN_SKIP = /^(weight|sleep_hours|energy|mood|wake|wake_time|sleep|bed|habit_.*|.*_start|.*_end|day_sealed.*|training|id|type|tags|aliases|created|cssclasses?)$/i;
  function ownNumbers(days) {
    const n = {};
    days.forEach(d => Object.entries(d.fm).forEach(([k, v]) => { if (OWN_SKIP.test(k) || typeof v === "boolean" || num(v) == null || /^\d{1,2}:\d{2}$/.test(String(v))) return; n[k] = (n[k] || 0) + 1; }));
    return Object.entries(n).sort((a, b) => b[1] - a[1]);
  }
  function weeksOf(days) {
    const out = []; for (let i = 0; i < days.length; i += 7) out.push(days.slice(i, i + 7));
    return out.filter(w => w.length);
  }
  function pair(days, split, of, sayA, sayB, fmt, lead) {
    const a = [], b = [];
    days.forEach((d, i) => { const s = split(d, i); if (s == null) return; const v = of(d, i); if (v == null) return; (s ? a : b).push(v); });
    if (a.length < 10 || b.length < 10) return null;
    const ma = mean(a), mb = mean(b), top = Math.max(ma, mb) || 1;
    return `<div class="lv-pair"><p>${lead(`<b>${esc(fmt(ma))}</b>`, `<b>${esc(fmt(mb))}</b>`)}</p>
      <div class="lv-pb"><span>${esc(sayA)}</span><span class="lv-pt"><i style="width:${(ma / top * 100).toFixed(0)}%"></i></span><em>${esc(fmt(ma))}</em></div>
      <div class="lv-pb"><span>${esc(sayB)}</span><span class="lv-pt"><i class="lv-lo" style="width:${(mb / top * 100).toFixed(0)}%"></i></span><em>${esc(fmt(mb))}</em></div>
      <small>${esc(plural(a.length, "day"))} and ${esc(plural(b.length, "day"))}</small></div>`;
  }
  async function trendsHtml(ctx, st) {
    const s = ctx.settings, N = spanOf(s), cmp = compareOn(s), to = ctx.iso, from = shift(to, -(N - 1)), pfrom = shift(from, -N), pto = shift(from, -1);
    const days = await record(ctx, from, to, true), prev = cmp ? await record(ctx, pfrom, pto, true) : [];
    const had = days.filter(d => d.file).length, spanWord = SPANS.find(x => x[0] === N)[1].toLowerCase();
    const hs = habitList(ctx), recs = await habitRecs(ctx, hs, days.concat(prev).map(d => d.iso)), kept = keeper(ctx, hs, recs);
    const col = (D, f) => D.map(d => d.file ? f(d) : null);
    const W8 = col(days, d => num(d.fm.weight)), SL = col(days, d => num(d.fm.sleep_hours)), EN = col(days, d => num(d.fm.energy)), WK = col(days, d => wakeOf(d.fm));
    const FO = col(days, d => focusOf(d.text).reduce((a, x) => a + x.min, 0) || null);
    const share = D => { const n = D.filter(d => d.file).length * hs.length; return n ? D.filter(d => d.file).reduce((a, d) => a + hs.filter(h => kept(h, d)).length, 0) / n : null; };
    const got = a => a.filter(x => x != null);
    const fig = (label, now, was, fmt, n, unit, k = 1) => {
      const said = now == null ? "nothing written" : cmp && was != null ? `${signed(now - was, k)} against ${fmt(was)}` : "";
      return `<div class="lv-fig"><span class="lv-lbl">${esc(label)}</span><b>${now == null ? "—" : esc(fmt(now))}${unit ? `<i>${esc(unit)}</i>` : ""}</b><small>${esc(said)}${said && n ? " · " : ""}${n ? esc(n) : ""}</small></div>`;
    };
    const pw = cmp ? got(col(prev, d => num(d.fm.weight))) : [], ps = cmp ? got(col(prev, d => num(d.fm.sleep_hours))) : [], pe = cmp ? got(col(prev, d => num(d.fm.energy))) : [];
    const pf = cmp ? prev.filter(d => d.file).reduce((a, d) => a + focusOf(d.text).reduce((x, y) => x + y.min, 0), 0) : 0;
    const lastW = got(W8).slice(-1)[0], weekH = got(FO).reduce((a, x) => a + x, 0) / 60 / (N / 7), pweekH = cmp && prev.some(d => d.file) ? pf / 60 / (N / 7) : null;
    const hNow = share(days), hWas = cmp ? share(prev) : null;
    const figs = [
      fig("weight", lastW ?? null, pw.length ? pw[pw.length - 1] : null, v => v.toFixed(1), plural(got(W8).length, "morning"), "kg"),
      fig("slept, a night", mean(got(SL)), mean(ps), v => hm(v), plural(got(SL).length, "night"), ""),
      fig("energy", mean(got(EN)), mean(pe), v => v.toFixed(1), plural(got(EN).length, "morning"), "/10"),
      fig("focus, a week", got(FO).length ? weekH : null, pweekH, v => hm(v), plural(got(FO).length, "day"), ""),
      fig("habits kept", hs.length && hNow != null ? hNow * 100 : null, hWas != null ? hWas * 100 : null, v => `${Math.round(v)}%`, hs.length ? plural(hs.length, "habit") : "no habits named", "", 0),
    ].join("");
    const card = (title, aside, body, wide) => `<section class="hd-plate lv-card${wide ? " lv-wide" : ""}"><div class="hd-plate-h"><span class="hd-sc">${esc(title)}</span>${aside ? `<span class="lv-aside">${esc(aside)}</span>` : ""}</div>${body}</section>`;
    const none = w => `<p class="lv-none">${esc(w)}</p>`;
    const cards = [];
    {
      const v = got(W8);
      cards.push(card("Weight", plural(v.length, "morning") + " weighed", v.length ? `<p class="lv-said">From <b>${v[0].toFixed(1)}</b> to <b>${v[v.length - 1].toFixed(1)} kg</b>, ${esc(signed(v[v.length - 1] - v[0]))} kg.</p>${dotsChart(days, W8, x => x.toFixed(1))}<div class="lv-key"><span><i class="lv-k-dot"></i>a morning</span><span><i class="lv-k-line"></i>the mean of the seven days to it</span></div>` : none("no weight written in these " + spanWord)));
    }
    {
      const v = got(SL), m = mean(v);
      cards.push(card("Sleep", plural(v.length, "night"), v.length ? `<p class="lv-said">A mean of <b>${esc(hm(m))}</b> a night; the longest <b>${esc(hm(Math.max(...v)))}</b>, the shortest <b>${esc(hm(Math.min(...v)))}</b>.</p>${barsChart(days, SL, x => `${Math.round(x)}h`)}<div class="lv-key"><span><i class="lv-k-bar"></i>a night</span><span><i class="lv-k-mean"></i>the mean, ${esc(hm(m))}</span></div>` : none("no sleep written in these " + spanWord)));
    }
    {
      const v = got(EN), moods = days.map(d => d.file ? d.fm.mood : null), mk = moods.filter(Boolean);
      const cells = mk.length ? `<div class="lv-moods">${days.map(d => { const r = moodRank(d.fm.mood); return `<i class="lv-mc${r == null ? (d.fm.mood ? " lv-mother" : "") : ""}" style="${r == null ? "" : `--k:${(1 - r / (MOODS.length - 1)).toFixed(2)}`}" title="${esc(dayWords(d.iso))}${d.fm.mood ? " · " + esc(d.fm.mood) : ""}"></i>`; }).join("")}</div>` : "";
      const count = {}; mk.forEach(w => count[w] = (count[w] || 0) + 1); const most = Object.entries(count).sort((a, b) => b[1] - a[1])[0];
      cards.push(card("Energy and mood", plural(v.length, "morning"), v.length || mk.length ? `<p class="lv-said">${v.length ? `Energy a mean of <b>${mean(v).toFixed(1)}</b> of 10.` : ""}${most ? ` The word most said: <b>${esc(most[0])}</b>, on ${esc(plural(most[1], "morning"))}.` : ""}</p>${dotsChart(days, EN, x => x.toFixed(0), 120)}${cells}` : none("no energy or mood written in these " + spanWord)));
    }
    {
      const v = got(WK), wd = days.map((d, i) => isWeekend(d.iso) ? null : WK[i]), we = days.map((d, i) => isWeekend(d.iso) ? WK[i] : null);
      const chart = v.length ? (() => { const sc = scaleOf(WK, 200); const n = days.length;
        const dots = (arr, c) => arr.map((x, i) => x == null ? "" : `<circle class="lv-dot ${c}" cx="${xOf(i, n).toFixed(1)}" cy="${sc.y(x).toFixed(1)}" r="${n > 120 ? 1.8 : 3}"/>`).join("");
        return `<svg class="lv-ch lv-flip" viewBox="0 0 ${W} 200" role="img">${axis(sc, 200, clock)}${dots(wd, "")}${dots(we, "lv-we")}${foot(days, 200)}</svg>`; })() : "";
      cards.push(card("Waking", plural(v.length, "wake"), v.length ? `<p class="lv-said">A mean of <b>${esc(clock(mean(got(wd)) ?? mean(v)))}</b> on weekdays${got(we).length ? ` and <b>${esc(clock(mean(got(we))))}</b> at the weekend` : ""}.</p>${chart}<div class="lv-key"><span><i class="lv-k-dot"></i>a weekday</span><span><i class="lv-k-dot lv-we"></i>a weekend</span></div>` : none("no wake written in these " + spanWord)));
    }
    {
      const wk = weeksOf(days), whats = {};
      days.forEach(d => focusOf(d.text).forEach(x => { const w = x.what || "focus"; whats[w] = (whats[w] || 0) + x.min; }));
      const top = Object.entries(whats).sort((a, b) => b[1] - a[1]).map(x => x[0]), keys = top.slice(0, 3).concat(top.length > 3 ? ["the rest"] : []);
      const weeks = wk.map(w => { const by = {}; w.forEach(d => focusOf(d.text).forEach(x => { const k0 = x.what || "focus", k = keys.includes(k0) ? k0 : "the rest"; by[k] = (by[k] || 0) + x.min / 60; })); return { from: w[0].iso, by }; });
      cards.push(card("Focus", "a week a bar", top.length ? `<p class="lv-said"><b>${esc(hm(weekH))}</b> a week, ${esc(plural(got(FO).length, "day"))} with focus written.</p>${stackChart(weeks, keys)}<div class="lv-key">${keys.map((k, j) => `<span><i class="lv-k-st lv-st${j}"></i>${esc(k)}</span>`).join("")}</div>` : none("no focus written in these " + spanWord)));
    }
    {
      const wk = weeksOf(days).filter(w => w.some(d => d.file));
      const rows = hs.map((h, k) => { const D = days.filter(d => d.file), n = D.filter(d => kept(h, d)).length;
        return `<div class="lv-hab" style="--c:var(--hb-${k % 6 + 1})"><b>${esc(h.label || h.id)}</b><span class="lv-hw">${wk.map(w => { const W0 = w.filter(d => d.file); const p = W0.length ? W0.filter(d => kept(h, d)).length / W0.length : 0; return `<i style="--p:${p.toFixed(2)}" title="${esc(dayShort(w[0].iso))} · ${Math.round(p * 100)}%"></i>`; }).join("")}</span><em>${D.length ? Math.round(n / D.length * 100) : 0}%</em></div>`; }).join("");
      cards.push(card("Habits", "a week a bar", hs.length ? `<p class="lv-said">Kept on <b>${Math.round((hNow || 0) * 100)}%</b> of habit-days${cmp && hWas != null ? `, against ${Math.round(hWas * 100)}% the ${esc(spanWord)} before` : ""}.</p>${rows}` : none("name a habit on the daily note's day page and it is counted here")));
    }
    {
      const next = i => days[i + 1] && days[i + 1].file ? days[i + 1] : null;
      const P = [
        pair(days, d => { const x = num(d.fm.sleep_hours); return x == null ? null : x >= 7 ? true : x < 6 ? false : null; }, d => num(d.fm.energy), "7h or more", "under 6h", v => v.toFixed(1),
          (a, b) => `After a night of 7 hours or more, the morning's energy was ${a}; after under 6 hours, ${b}.`),
        pair(days, d => { const w = wakeOf(d.fm); return w == null ? null : w < 420; }, d => { const m = focusOf(d.text).reduce((a, x) => a + x.min, 0); return d.file ? m / 60 : null; }, "before 07:00", "07:00 or later", v => hm(v),
          (a, b) => `On days you woke before 07:00 you focused ${a}; on later ones, ${b}.`),
        pair(days, d => d.file ? trained(d.fm) : null, (d, i) => { const n = next(i); return n ? num(n.fm.energy) : null; }, "after training", "after rest", v => v.toFixed(1),
          (a, b) => `The morning after a day you trained, energy was ${a}; after a rest day, ${b}.`),
      ].filter(Boolean);
      cards.push(card("Read together", `what moved with what, in these ${spanWord}`, (P.length ? `<div class="lv-pairs">${P.join("")}</div>` : none("Not enough days yet: a pair is shown once each side of it has 10 days.")) +
        `<p class="lv-caveat">Read from your notes as they are. Two things that moved together did not have to cause each other, and a pair resting on fewer than 10 days a side is not shown.</p>`, true));
    }
    {
      const own = words(s.trends_own), keys = [["energy", "energy"], ["sleep_hours", "sleep"], ["weight", "weight"], ["mood", "mood"], ["focus", "focus"], ...own.map(k => [k, k])];
      const key = keys.some(x => x[0] === s.trends_year_key) ? s.trends_year_key : "energy";
      const yr = await record(ctx, shift(to, -364), to, key === "focus");
      const val = d => !d.file ? null : key === "focus" ? (focusOf(d.text).reduce((a, x) => a + x.min, 0) || null) : key === "mood" ? (moodRank(d.fm.mood) == null ? null : MOODS.length - 1 - moodRank(d.fm.mood)) : num(d.fm[key]);
      const vals = yr.map(val), lbl = x => key === "focus" ? hm(x / 60) : key === "mood" ? MOODS[MOODS.length - 1 - x] : String(+x.toFixed(1));
      const pick = `<span class="hd-seg lv-yseg" role="radiogroup" aria-label="what the year draws">${keys.map(([k, w]) => `<button class="hd-seg-b${k === key ? " hd-on" : ""}" role="radio" aria-checked="${k === key}" data-lvyear="${esc(k)}">${esc(w)}</button>`).join("")}</span>`;
      cards.push(card("The year", `${plural(got(vals).length, "day")} written · brighter is higher`, pick + yearGrid(yr, vals, lbl) +
        `<div class="lv-months">${Array.from({ length: 12 }, (_, i) => { const d = atNoon(shift(to, -364)); d.setMonth(d.getMonth() + i + 1, 1); return `<span>${MONTHS[d.getMonth()].slice(0, 3)}</span>`; }).join("")}</div>`, true));
    }
    {
      const own = words(s.trends_own), found = ownNumbers(days).filter(([k]) => !own.includes(k));
      const drawn = own.map(k => { const v = col(days, d => num(d.fm[k])), g = got(v);
        return `<div class="lv-own1"><div class="lv-own-h"><b>${esc(k)}</b><span>${esc(plural(g.length, "day"))}${g.length ? ` · a mean of ${esc(String(+mean(g).toFixed(1)))}` : ""}</span><button class="vc-ib" data-lvunown="${esc(k)}" aria-label="stop drawing ${esc(k)}">${icon("close")}</button></div>${g.length ? dotsChart(days, v, x => String(+x.toFixed(1)), 120) : `<p class="lv-none">not written in these ${esc(spanWord)}</p>`}</div>`; }).join("");
      cards.push(card("Your own numbers", "found in your daily notes", `${drawn}<p class="lv-said">${found.length ? "A number a daily note keeps in its properties can be drawn here beside the rest. Press one to add it." : own.length ? "Every number your notes keep in these " + esc(spanWord) + " is drawn." : "A number your daily notes keep in their properties, steps or pages or anything, is offered here once a note has one."}</p>${found.length ? `<div class="lv-own">${found.slice(0, 12).map(([k, n]) => `<button class="hd-pill" data-lvown="${esc(k)}">${esc(k)}<small>${esc(plural(n, "day"))}</small></button>`).join("")}</div>` : ""}`, true));
    }
    const head = `<div class="lv-head"><p class="lv-lead">What your daily notes have recorded, ${esc(dayWords(from))} to ${esc(dayWords(to))}: <b>${esc(plural(had, "note"))}</b>${N - had ? `, ${esc(plural(N - had, "day"))} without one` : ""}.</p>
      <div class="lv-tools"><span class="hd-seg" role="radiogroup" aria-label="how far back">${SPANS.map(([n, w]) => `<button class="hd-seg-b${n === N ? " hd-on" : ""}" role="radio" aria-checked="${n === N}" data-lvspan="${n}">${esc(w)}</button>`).join("")}</span>
      <button class="hd-pill lv-vs${cmp ? " hd-on" : ""}" role="switch" aria-checked="${cmp}" data-lvcmp>against the ${esc(spanWord)} before</button></div></div>`;
    return head + `<div class="lv-figs">${figs}</div><div class="lv-grid">${cards.join("")}</div>`;
  }

  async function yearHtml(ctx) {
    const hs = habitList(ctx), to = ctx.iso, from = shift(to, -364);
    if (!hs.length) return `<p class="lv-none">Name a habit on the daily note's day page, and its year is drawn here.</p>`;
    const days = await record(ctx, from, to, true), recs = await habitRecs(ctx, hs, days.map(d => d.iso)), kept = keeper(ctx, hs, recs);
    return `<p class="lv-lead">Each habit from ${esc(dayWords(from))} to today, a day a cell.</p>` + hs.map((h, k) => {
      const on = days.map(d => d.file ? kept(h, d) : false), n = on.filter(Boolean).length;
      let best = 0, bestEnd = -1, run = 0; on.forEach((x, i) => { run = x ? run + 1 : 0; if (run > best) { best = run; bestEnd = i; } });
      let now = 0; for (let i = on.length - 1; i >= 0; i--) { if (on[i]) now++; else if (i === on.length - 1) continue; else break; }
      const yr = iso => dayWords(iso) + (iso.slice(0, 4) !== to.slice(0, 4) ? " " + iso.slice(0, 4) : ""), a = days[bestEnd - best + 1], b = days[bestEnd];
      const longest = !best ? "no run yet" : best === 1 ? `the longest run a day, ${yr(b.iso)}` : `the longest run ${plural(best, "day")}, ${yr(a.iso)} to ${yr(b.iso)}`;
      return `<section class="hd-plate lv-card lv-wide lv-hy" style="--c:var(--hb-${k % 6 + 1})"><div class="hd-plate-h"><span class="hd-sc">${esc(h.label || h.id)}</span><span class="lv-aside">kept on ${esc(plural(n, "day"))} of 365</span></div>
        <p class="lv-said">${esc(longest)}${now ? ` · on a run of ${esc(plural(now, "day"))}` : ""}.</p>${yearGrid(days, on.map(x => x ? 1 : null), () => "kept", true)}</section>`;
    }).join("");
  }

  function periodOf(kind, off, today) {
    const d = atNoon(today);
    if (kind === "week") { const mon = shift(today, -((d.getDay() + 6) % 7) + 7 * off); return { from: mon, to: shift(mon, 6), name: `Week of ${dayWords(mon)} ${atNoon(mon).getFullYear()}`, file: `${mon} week` }; }
    if (kind === "year") { const y = d.getFullYear() + off; return { from: `${y}-01-01`, to: `${y}-12-31`, name: String(y), file: `${y} year` }; }
    const m = new Date(d.getFullYear(), d.getMonth() + off, 1, 12), last = new Date(m.getFullYear(), m.getMonth() + 1, 0, 12);
    return { from: isoOf(m), to: isoOf(last), name: `${MONTHS[m.getMonth()]} ${m.getFullYear()}`, file: `${m.getFullYear()}-${pad(m.getMonth() + 1)} ${MONTHS[m.getMonth()]}` };
  }
  const reviewFolder = ctx => String(ctx.settings.review_folder || "").replace(/^\/+|\/+$/g, "") || `${folderOf(ctx) ? folderOf(ctx) + "/" : ""}Reviews`;
  async function readPeriod(ctx, P) {
    const to = P.to > ctx.iso ? ctx.iso : P.to, days = P.from > ctx.iso ? [] : await record(ctx, P.from, to, true), had = days.filter(d => d.file);
    const hs = habitList(ctx), recs = await habitRecs(ctx, hs, days.map(d => d.iso)), kept = keeper(ctx, hs, recs);
    const g = f => had.map(f).filter(x => x != null);
    const w = g(d => num(d.fm.weight)), sl = g(d => num(d.fm.sleep_hours)), en = g(d => num(d.fm.energy)), fo = had.reduce((a, d) => a + focusOf(d.text).reduce((x, y) => x + y.min, 0), 0);
    const rated = had.map(d => ({ d, r: num(d.fm.day_rating) ?? num(d.fm.energy) })).filter(x => x.r != null).sort((a, b) => b.r - a.r);
    const by = num(had[0] && had[0].fm.day_rating) != null || had.some(d => num(d.fm.day_rating) != null) ? "rated" : "energy";
    const first = d => (entriesOf(d.text)[0] || {}).text || "";
    return { P, days, had, hs, kept, w, sl, en, fo, by,
      high: rated.slice(0, 2), low: rated.length > 2 ? rated.slice(-1) : [],
      habits: hs.map(h => ({ h, n: had.filter(d => kept(h, d)).length })),
      starred: had.flatMap(d => entriesOf(d.text).filter(e => e.star).map(e => ({ iso: d.iso, ...e }))), first };
  }
  function reviewFigs(R) {
    const n = R.days.length;
    return [["notes written", `${R.had.length}`, `of ${plural(n, "day")}`],
      ["weight", R.w.length ? `${R.w[0].toFixed(1)} → ${R.w[R.w.length - 1].toFixed(1)}` : "—", R.w.length ? `kg, ${plural(R.w.length, "morning")}` : "none written"],
      ["slept, a night", R.sl.length ? hm(mean(R.sl)) : "—", plural(R.sl.length, "night")],
      ["energy", R.en.length ? mean(R.en).toFixed(1) : "—", `of 10, ${plural(R.en.length, "morning")}`],
      ["focus", hm(R.fo / 60), "in all"],
      ["habits kept", R.hs.length && R.had.length ? `${Math.round(R.habits.reduce((a, x) => a + x.n, 0) / (R.hs.length * R.had.length) * 100)}%` : "—", plural(R.hs.length, "habit")]];
  }
  async function reviewHtml(ctx, st) {
    const P = periodOf(st.rkind, st.roff, ctx.iso), R = await readPeriod(ctx, P), path = `${reviewFolder(ctx)}/${P.file}.md`, there = !!ctx.app.vault.getAbstractFileByPath(path);
    const kinds = [["week", "A week"], ["month", "A month"], ["year", "A year"]];
    const stood = R.high.concat(R.low).map((x, i) => `<li><a href="#" data-lvopen="${esc(x.d.file.path)}">${esc(dayWords(x.d.iso))}</a> <span class="lv-tag">${i < R.high.length ? (R.by === "rated" ? "rated" : "energy") + " " + x.r : "the lowest, " + x.r}</span> ${esc(R.first(x.d).slice(0, 140))}</li>`).join("");
    return `<div class="lv-head"><div class="lv-rnav"><button class="vc-ib" data-lvroff="-1" aria-label="the one before">${icon("prev")}</button><h2 class="lv-rname">${esc(P.name)}</h2><button class="vc-ib" data-lvroff="1" aria-label="the one after"${st.roff >= 0 ? " disabled" : ""}>${icon("next")}</button></div>
      <span class="hd-seg" role="radiogroup" aria-label="what is read back">${kinds.map(([k, w]) => `<button class="hd-seg-b${k === st.rkind ? " hd-on" : ""}" role="radio" aria-checked="${k === st.rkind}" data-lvrkind="${k}">${w}</button>`).join("")}</span></div>
      <p class="lv-lead">A ${esc(st.rkind)} read back from your notes and written down, so it stays when the notes are long past. ${esc(plural(R.had.length, "note"))} of ${esc(plural(R.days.length, "day"))}${P.to > ctx.iso && R.days.length ? ", so far" : ""}.</p>
      <div class="lv-figs">${reviewFigs(R).map(([l, v, s]) => `<div class="lv-fig"><span class="lv-lbl">${esc(l)}</span><b>${esc(v)}</b><small>${esc(s)}</small></div>`).join("")}</div>
      <div class="lv-grid">
        <section class="hd-plate lv-card"><div class="hd-plate-h"><span class="hd-sc">The days that stood out</span><span class="lv-aside">by ${R.by === "rated" ? "the day's rating" : "the morning's energy"}</span></div>${stood ? `<ul class="lv-list">${stood}</ul>` : `<p class="lv-none">no day rated or its energy written</p>`}</section>
        <section class="hd-plate lv-card"><div class="hd-plate-h"><span class="hd-sc">Habits</span></div>${R.hs.length ? R.habits.map((x, k) => `<div class="lv-hab" style="--c:var(--hb-${k % 6 + 1})"><b>${esc(x.h.label || x.h.id)}</b><span class="lv-pt"><i style="width:${R.had.length ? (x.n / R.had.length * 100).toFixed(0) : 0}%"></i></span><em>${x.n} of ${R.had.length}</em></div>`).join("") : `<p class="lv-none">no habits named</p>`}</section>
        <section class="hd-plate lv-card lv-wide"><div class="hd-plate-h"><span class="hd-sc">Lines you starred</span><span class="lv-aside">${esc(plural(R.starred.length, "line"))}</span></div>${R.starred.length ? `<ul class="lv-list">${R.starred.map(e => `<li><a href="#" data-lvopen="${esc((R.days.find(d => d.iso === e.iso) || {}).file.path)}" data-lvline="${e.line}">${esc(dayShort(e.iso))} · ${esc(e.time)}</a> ${esc(e.text)}</li>`).join("")}</ul>` : `<p class="lv-none">a line starred in the journal is gathered here</p>`}</section>
        <section class="hd-plate lv-card lv-wide"><div class="hd-plate-h"><span class="hd-sc">Anything to add before it is written</span></div><textarea class="lv-words" data-lvwords rows="4" placeholder="written under In your words">${esc(st.words || "")}</textarea>
          <div class="lv-acts"><button class="vc-b" data-lvwrite>${there ? "Write it again" : "Write it"}</button>${there ? `<button class="vc-b vc-b--ghost" data-lvopen="${esc(path)}">Open the review</button>` : ""}<span class="lv-where">${esc(path)}</span></div></section>
      </div>`;
  }
  function reviewNote(R, words, today) {
    const L = R.P, f = reviewFigs(R);
    return ["---", "type: review", `period: ${L.file.split(" ").pop() === "year" ? "year" : L.file.endsWith("week") ? "week" : "month"}`, `from: ${L.from}`, `to: ${L.to}`, `written: ${today}`, "---", "",
      `# ${L.name}`, "", `Read back from ${plural(R.had.length, "daily note")} of ${plural(R.days.length, "day")}.`, "",
      "## The figures", "", ...f.map(([l, v, s]) => `- ${l[0].toUpperCase() + l.slice(1)}: ${v} ${s}`), "",
      "## The days that stood out", "", ...(R.high.concat(R.low).map(x => `- [[${x.d.iso}]] (${R.by} ${x.r}) ${R.first(x.d)}`.trim())), ...(R.high.length ? [] : ["- none rated"]), "",
      "## Habits", "", ...(R.habits.map(x => `- ${x.h.label || x.h.id}: ${x.n} of ${R.had.length} days`)), ...(R.hs.length ? [] : ["- none named"]), "",
      "## Starred", "", ...(R.starred.map(e => `- [[${e.iso}]] ${e.time} — ${e.text}`)), ...(R.starred.length ? [] : ["- none starred"]), "",
      "## In your words", "", String(words || "").trim(), ""].join("\n");
  }
  async function ensureFolder(app, dir) {
    const parts = dir.split("/").filter(Boolean);
    for (let i = 1; i <= parts.length; i++) { const p = parts.slice(0, i).join("/"); if (!app.vault.getAbstractFileByPath(p)) { try { await app.vault.createFolder(p); } catch (e) {} } }
  }
  async function writeNote(app, path, text) {
    await ensureFolder(app, path.slice(0, path.lastIndexOf("/")));
    const f = app.vault.getAbstractFileByPath(path);
    if (f) await app.vault.modify(f, text); else await app.vault.create(path, text);
  }
  async function writeReview(ctx, st) {
    const P = periodOf(st.rkind, st.roff, ctx.iso), R = await readPeriod(ctx, P), path = `${reviewFolder(ctx)}/${P.file}.md`, was = ctx.app.vault.getAbstractFileByPath(path);
    let words = String(st.words || "").trim();
    if (!words && was) { const t = await ctx.app.vault.read(was); words = ((t.split(/^## In your words\s*$/m)[1]) || "").trim(); }
    await writeNote(ctx.app, path, reviewNote(R, words, ctx.iso));
    return path;
  }

  async function starredHtml(ctx, st) {
    const files = allDays(ctx), lines = [];
    for (const f of files) entriesOf(await textOf(ctx, f)).forEach(e => { if (e.star || e.tags.length) lines.push({ iso: f.basename, path: f.path, ...e }); });
    const tags = {}; lines.forEach(l => l.tags.forEach(t => tags[t] = (tags[t] || 0) + 1));
    const on = st.tag && tags[st.tag] ? st.tag : "", shown = on ? lines.filter(l => l.tags.includes(on)) : lines.filter(l => l.star);
    const chips = `<div class="lv-own" role="radiogroup" aria-label="which lines"><button class="hd-pill${on ? "" : " hd-on"}" role="radio" aria-checked="${!on}" data-lvtag="">${icon("star")}Starred<small>${lines.filter(l => l.star).length}</small></button>${Object.entries(tags).sort((a, b) => b[1] - a[1]).map(([t, n]) => `<button class="hd-pill${t === on ? " hd-on" : ""}" role="radio" aria-checked="${t === on}" data-lvtag="${esc(t)}">#${esc(t)}<small>${n}</small></button>`).join("")}</div>`;
    const days = new Set(shown.map(l => l.iso)).size;
    return `<p class="lv-lead">Every line you starred, and every line under a tag, from ${esc(plural(files.length, "daily note"))}. Each opens the day it was written on.</p>${chips}
      <section class="hd-plate lv-card lv-wide"><div class="hd-plate-h"><span class="hd-sc">${on ? "#" + esc(on) : "Starred"}</span><span class="lv-aside">${esc(plural(shown.length, "line"))} across ${esc(plural(days, "day"))}</span></div>
      ${shown.length ? `<ul class="lv-list">${shown.map(l => `<li><a href="#" data-lvopen="${esc(l.path)}" data-lvline="${l.line}">${esc(dayWords(l.iso))} ${esc(l.iso.slice(0, 4))} · ${esc(l.time)}</a> ${esc(l.text)}</li>`).join("")}</ul>` : `<p class="lv-none">${on ? "no line carries this tag" : "a journal line starred on the daily note is gathered here"}</p>`}</section>`;
  }

  const EXPORT_PARTS = [["days", "the figures, a day a row", true], ["means", "the month's means", true], ["habits", "the habits", true], ["journal", "the journal", false]];
  async function exportHtml(ctx, st) {
    const P = periodOf("month", st.eoff, ctx.iso), path = `${reviewFolder(ctx)}/Export ${P.name}.md`, there = !!ctx.app.vault.getAbstractFileByPath(path);
    const R = await readPeriod(ctx, P);
    return `<div class="lv-head"><div class="lv-rnav"><button class="vc-ib" data-lveoff="-1" aria-label="the month before">${icon("prev")}</button><h2 class="lv-rname">Export ${esc(P.name)}</h2><button class="vc-ib" data-lveoff="1" aria-label="the month after"${st.eoff >= 0 ? " disabled" : ""}>${icon("next")}</button></div></div>
      <p class="lv-lead">A month's figures as one clean page, to send to a coach or a doctor or to keep. Nothing from the journal goes unless you tick it. ${esc(plural(R.had.length, "note"))} this month.</p>
      <section class="hd-plate lv-card lv-wide"><div class="hd-plate-h"><span class="hd-sc">What goes on the page</span></div>
        ${EXPORT_PARTS.map(([k, w]) => `<button class="lv-swrow" role="switch" aria-checked="${!!st.ex[k]}" data-lvex="${k}"><span class="lv-sw${st.ex[k] ? " lv-on" : ""}"></span>${esc(w)}</button>`).join("")}
        <div class="lv-acts"><button class="vc-b" data-lvexport>${there ? "Write it again" : "Write the page"}</button>${there ? `<button class="vc-b vc-b--ghost" data-lvopen="${esc(path)}">Open it</button>` : ""}<span class="lv-where">${esc(path)}</span></div>
        <p class="lv-said">Obsidian's Export to PDF, in the note's menu, makes the page a file to send.</p></section>`;
  }
  function exportNote(R, ex, today) {
    const P = R.P, row = d => { const f = d.fm, fo = focusOf(d.text).reduce((a, x) => a + x.min, 0);
      return `| ${dayShort(d.iso)} | ${num(f.weight) ?? ""} | ${num(f.sleep_hours) != null ? hm(num(f.sleep_hours)) : ""} | ${num(f.energy) ?? ""} | ${f.mood ? String(f.mood) : ""} | ${fo ? hm(fo / 60) : ""} | ${R.hs.length ? R.hs.filter(h => R.kept(h, d)).length + " of " + R.hs.length : ""} |`; };
    const out = ["---", "type: export", `month: ${P.from.slice(0, 7)}`, `written: ${today}`, "---", "", `# ${P.name}`, "", `From ${plural(R.had.length, "daily note")} of ${plural(R.days.length, "day")}.`, ""];
    if (ex.means) out.push("## The month", "", ...reviewFigs(R).map(([l, v, s]) => `- ${l[0].toUpperCase() + l.slice(1)}: ${v} ${s}`), "");
    if (ex.days) out.push("## Each day", "", "| Day | Weight | Slept | Energy | Mood | Focus | Habits |", "| --- | --- | --- | --- | --- | --- | --- |", ...R.had.map(row), "");
    if (ex.habits && R.hs.length) out.push("## Habits", "", ...R.habits.map(x => `- ${x.h.label || x.h.id}: ${x.n} of ${R.had.length} days`), "");
    if (ex.journal) out.push("## Journal", "", ...R.had.flatMap(d => { const e = entriesOf(d.text); return e.length ? [`### ${dayWords(d.iso)}`, ...e.map(x => `- ${x.time} — ${x.text}`), ""] : []; }));
    return out.join("\n");
  }

  const STATES = new WeakMap();
  async function draw(ctx) {
    const P = ctx.ui && ctx.ui.panel && ctx.ui.panel(); if (!P) return;
    let st = STATES.get(P);
    if (!st) { st = { tab: TABS.some(t => t[0] === ctx.settings.trends_tab) ? ctx.settings.trends_tab : "trends", rkind: "month", roff: 0, eoff: -1, words: "", tag: "", ex: Object.fromEntries(EXPORT_PARTS.map(([k, , on]) => [k, on])), busy: false }; STATES.set(P, st); wire(P, ctx, st); }
    st.ctx = ctx;
    const bar = `<nav class="vc-tabs lv-tabs" role="tablist" aria-label="the long view">${TABS.map(([k, w, m]) => `<button class="vc-tab lv-tab${k === st.tab ? " vc-on" : ""}" role="tab" aria-selected="${k === st.tab}" data-lvtab="${k}">${icon(m)}<span class="vc-word">${esc(w)}</span></button>`).join("")}</nav>`;
    let body = "";
    try { body = await ({ trends: trendsHtml, year: yearHtml, review: reviewHtml, starred: starredHtml, export: exportHtml }[st.tab])(ctx, st); }
    catch (e) { ctx.report(e); body = `<p class="lv-none">This could not be read: ${esc(e && e.message || e)}</p>`; }
    P.innerHTML = `<div class="lv-page" data-lv>${bar}<div class="lv-body" data-lvbody>${body}</div></div>`;
    try { if (V && V.iconify) V.iconify(P); } catch (e) {}
  }
  function wire(P, ctx0, st) {
    const redraw = () => draw(st.ctx);
    const save = patch => Promise.resolve(st.ctx.write(patch)).then(redraw).catch(e => st.ctx.report(e));
    P.addEventListener("input", e => { if (e.target.matches && e.target.matches("[data-lvwords]")) st.words = e.target.value; });
    P.addEventListener("click", async e => {
      const t = e.target.closest && e.target.closest("button, a"); if (!t || !P.contains(t)) return;
      const d = t.dataset, ctx = st.ctx;
      if (d.lvtab) { st.tab = d.lvtab; return save({ trends_tab: d.lvtab }); }
      if (d.lvspan) return save({ trends_span: Number(d.lvspan) });
      if (d.lvcmp !== undefined) return save({ trends_compare: !compareOn(ctx.settings) });
      if (d.lvyear) return save({ trends_year_key: d.lvyear });
      if (d.lvown) return save({ trends_own: words(ctx.settings.trends_own).concat(d.lvown) });
      if (d.lvunown) { const left = words(ctx.settings.trends_own).filter(k => k !== d.lvunown); return save({ trends_own: left.length ? left : null }); }
      if (d.lvrkind) { st.rkind = d.lvrkind; st.roff = 0; return redraw(); }
      if (d.lvroff) { st.roff = Math.min(0, st.roff + Number(d.lvroff)); return redraw(); }
      if (d.lveoff) { st.eoff = Math.min(0, st.eoff + Number(d.lveoff)); return redraw(); }
      if (d.lvtag !== undefined) { st.tag = d.lvtag; return redraw(); }
      if (d.lvex) { st.ex[d.lvex] = !st.ex[d.lvex]; return redraw(); }
      if (d.lvopen) { e.preventDefault(); return openAt(ctx, d.lvopen, d.lvline != null ? Number(d.lvline) : null); }
      if (d.lvwrite !== undefined || d.lvexport !== undefined) {
        if (st.busy) return; st.busy = true; t.disabled = true;
        try {
          let path;
          if (d.lvwrite !== undefined) path = await writeReview(ctx, st);
          else { const P0 = periodOf("month", st.eoff, ctx.iso); path = `${reviewFolder(ctx)}/Export ${P0.name}.md`; await writeNote(ctx.app, path, exportNote(await readPeriod(ctx, P0), st.ex, ctx.iso)); }
          if (ctx.ui.toast) ctx.ui.toast(`Written to <b>${esc(path)}</b>`);
          st.words = "";
        } catch (err) { ctx.report(err); if (ctx.ui.toast) ctx.ui.toast(`It was not written: ${esc(err && err.message || err)}`); }
        finally { st.busy = false; }
        return redraw();
      }
    });
  }
  async function openAt(ctx, path, line) {
    const f = ctx.app.vault.getAbstractFileByPath(path); if (!f) return;
    try { await ctx.app.workspace.getLeaf(false).openFile(f, line != null ? { eState: { line } } : {}); } catch (e) { if (ctx.ui.open) ctx.ui.open(path); }
  }

  return { VERSION, draw, read: { focusOf, entriesOf, ownNumbers, periodOf, reviewNote, exportNote, readPeriod, record } };
})();
```

```css
.hd .lv-page { display: grid; gap: 18px; }
.hd .lv-tabs { justify-self: start; flex-wrap: wrap; }
.hd .lv-body { display: grid; gap: 18px; min-width: 0; }
.hd .lv-head { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px 20px; }
.hd .lv-lead { margin: 0; max-width: 70ch; color: var(--dim); }
.hd .lv-lead b { color: var(--tx); font-weight: 600; }
.hd .lv-tools { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
.hd .lv-figs { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }
.hd .lv-fig { display: grid; gap: 2px; padding: 14px 16px; border-radius: var(--r-item); background: var(--bg-2); box-shadow: inset 0 0 0 1px var(--border); min-width: 0; }
.hd .lv-lbl { font-size: 12px; color: var(--dim); }
.hd .lv-fig b { font-family: var(--f-display); font-weight: 400; font-size: 30px; line-height: 1.1; color: var(--bright); font-variant-numeric: tabular-nums; }
.hd .lv-fig b i { font-style: normal; font-size: 13px; color: var(--dim); margin-left: 3px; }
.hd .lv-fig small { font-size: 12px; color: var(--fnt); }
.hd .lv-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
.hd[data-cols="narrow"] .lv-grid { grid-template-columns: minmax(0, 1fr); }
.hd .lv-card { display: grid; gap: 10px; align-content: start; min-width: 0; }
.hd .lv-wide { grid-column: 1 / -1; }
.hd .lv-aside { margin-left: auto; font-size: 12px; color: var(--dim); }
.hd .lv-said { margin: 0; color: var(--dim); font-size: 14px; }
.hd .lv-said b { color: var(--tx); font-weight: 600; }
.hd .lv-none { margin: 0; color: var(--fnt); font-size: 13px; }
.hd .lv-caveat { margin: 4px 0 0; font-size: 12px; color: var(--fnt); }
.hd .lv-ch { display: block; width: 100%; height: auto; overflow: visible; }
.hd .lv-ax text { fill: var(--fnt); font-size: 10px; font-family: var(--f-label); }
.hd .lv-ax line { stroke: var(--border); stroke-width: 1; }
.hd .lv-dot { fill: var(--a-lo); }
.hd .lv-dot.lv-today { fill: var(--eaten); }
.hd .lv-dot.lv-we { fill: var(--planned); }
.hd .lv-line { fill: none; stroke: var(--a-hi); stroke-width: 2.2; stroke-linejoin: round; stroke-linecap: round; }
.hd .lv-bar { fill: var(--a-lo); }
.hd .lv-mean { stroke: var(--eaten); stroke-width: 2; stroke-dasharray: 5 4; }
.hd .lv-st0 { fill: var(--a); background: var(--a); }
.hd .lv-st1 { fill: var(--planned); background: var(--planned); }
.hd .lv-st2 { fill: var(--eaten); background: var(--eaten); }
.hd .lv-st3 { fill: var(--bg-4); background: var(--bg-4); }
.hd .lv-key { display: flex; flex-wrap: wrap; gap: 6px 16px; font-size: 12px; color: var(--dim); }
.hd .lv-key span { display: inline-flex; align-items: center; gap: 6px; }
.hd .lv-key i { display: inline-block; width: 12px; height: 8px; border-radius: 2px; }
.hd .lv-key .lv-k-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--a-lo); }
.hd .lv-key .lv-k-dot.lv-we { background: var(--planned); }
.hd .lv-key .lv-k-line { height: 3px; background: var(--a-hi); }
.hd .lv-key .lv-k-bar { background: var(--a-lo); }
.hd .lv-key .lv-k-mean { height: 2px; background: var(--eaten); }
.hd .lv-moods { display: flex; gap: 2px; }
.hd .lv-mc { flex: 1; min-width: 1px; height: 14px; border-radius: 2px; background: var(--bg-3); }
.hd .lv-mc[style] { background: color-mix(in srgb, var(--a) calc(var(--k) * 100%), var(--bg-3)); }
.hd .lv-mc.lv-mother { background: var(--bg-4); }
.hd .lv-hab { display: grid; grid-template-columns: minmax(80px, 160px) minmax(0, 1fr) 54px; align-items: center; gap: 12px; font-size: 13px; }
.hd .lv-hab b { font-weight: 500; color: var(--tx); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.hd .lv-hab em { font-style: normal; text-align: right; color: var(--dim); font-variant-numeric: tabular-nums; }
.hd .lv-hw { display: flex; align-items: flex-end; gap: 3px; height: 26px; }
.hd .lv-hw i { flex: 1; min-width: 2px; height: calc(4px + var(--p) * 22px); border-radius: 2px; background: color-mix(in srgb, var(--c) calc(30% + var(--p) * 70%), var(--bg-3)); }
.hd .lv-pt { position: relative; display: block; height: 8px; border-radius: 4px; background: var(--bg-3); overflow: hidden; }
.hd .lv-pt i { position: absolute; left: 0; top: 0; bottom: 0; border-radius: inherit; background: var(--c, var(--a)); }
.hd .lv-pt i.lv-lo { background: var(--bg-4); }
.hd .lv-pairs { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 14px; }
.hd .lv-pair { display: grid; gap: 8px; padding: 14px 16px; border-radius: var(--r-item); background: var(--bg-2); box-shadow: inset 0 0 0 1px var(--border); }
.hd .lv-pair p { margin: 0; font-size: 14px; color: var(--dim); }
.hd .lv-pair p b { color: var(--tx); }
.hd .lv-pb { display: grid; grid-template-columns: 100px minmax(0, 1fr) 52px; align-items: center; gap: 8px; font-size: 12px; color: var(--dim); }
.hd .lv-pb em { font-style: normal; text-align: right; color: var(--tx); font-variant-numeric: tabular-nums; }
.hd .lv-pair small { font-size: 11px; color: var(--fnt); }
.hd .lv-year { display: grid; grid-auto-flow: column; grid-template-rows: repeat(7, 1fr); gap: 2px; overflow-x: auto; padding-bottom: 2px; }
.hd .lv-yc { width: 100%; min-width: 7px; aspect-ratio: 1; border-radius: 2px; background: var(--bg-3); }
.hd .lv-yc.lv-pad { background: none; }
.hd .lv-yc.lv-on { background: color-mix(in srgb, var(--c, var(--a)) calc(var(--k) * 100%), var(--bg-3)); }
.hd .lv-months { display: flex; justify-content: space-between; font-size: 11px; color: var(--fnt); }
.hd .lv-yseg { justify-self: start; flex-wrap: wrap; }
.hd .lv-own { display: flex; flex-wrap: wrap; gap: 6px; }
.hd .lv-own small { margin-left: 6px; color: var(--dim); font-size: 11px; }
.hd .lv-own1 { display: grid; gap: 6px; padding-bottom: 10px; border-bottom: 1px solid var(--border); }
.hd .lv-own-h { display: flex; align-items: center; gap: 10px; font-size: 13px; color: var(--dim); }
.hd .lv-own-h b { color: var(--tx); font-weight: 600; }
.hd .lv-own-h .vc-ib { margin-left: auto; }
.hd .lv-rnav { display: flex; align-items: center; gap: 10px; }
.hd .lv-rname { margin: 0; font-family: var(--f-title); font-weight: 400; font-size: 30px; color: var(--bright); }
.hd .lv-list { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; font-size: 14px; color: var(--tx); }
.hd .lv-list a { color: var(--a); text-decoration: none; margin-right: 6px; font-variant-numeric: tabular-nums; }
.hd .lv-list a:hover { text-decoration: underline; }
.hd .lv-tag { font-size: 11px; color: var(--dim); margin-right: 6px; }
.hd .lv-words { width: 100%; box-sizing: border-box; resize: vertical; padding: 10px 12px; border-radius: var(--r-item); border: 1px solid var(--border); background: var(--bg-1); color: var(--tx); font: inherit; }
.hd .lv-acts { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
.hd .lv-where { font-size: 12px; color: var(--fnt); }
.hd .lv-swrow { display: flex !important; align-items: center; gap: 10px; width: 100%; padding: 6px 0 !important; border: 0 !important; background: none !important; box-shadow: none !important; color: var(--tx); font: inherit; text-align: left; cursor: pointer; justify-content: flex-start !important; }
.hd .lv-sw { position: relative; flex: none; width: 30px; height: 17px; border-radius: 9px; background: var(--bg-4); }
.hd .lv-sw::after { content: ""; position: absolute; top: 2px; left: 2px; width: 13px; height: 13px; border-radius: 50%; background: var(--dim); transition: left var(--t); }
.hd .lv-sw.lv-on { background: var(--a-lo); }
.hd .lv-sw.lv-on::after { left: 15px; background: var(--a-hi); }
.hd .lv-hy .lv-yc.lv-on { --k: 1; }
```
