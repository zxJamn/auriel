---
type: vault-theme
---

# Lamplit

One of the vault's themes, whole: a style, the palettes that belong to it, and anything else that is
its alone. Every note in this folder is a theme, and the Home Dashboard's settings list them; the style
and palette chosen there are written out as one small stylesheet in the vault's snippets folder,
`vault-theme`, which Obsidian loads when it starts, so the app, every note and every view change
together. Switch that stylesheet on under Settings, Appearance, CSS snippets, if it is not on already.

Nothing below runs as it stands. The first block is the style, and each block that also names a
palette is one of its palettes, as the names the app and the views read their look from. Any other
rule is the theme's own, and reaches a page only while the theme is worn.

**A theme of your own is a copy of this note**, in this folder, under another name: give
`data-style` a name of its own in every block, change the values, and it is offered the next time
the Home Dashboard opens. Nothing else has to change.

**Do not edit this block by hand.** It is replaced whole whenever the vault's code is updated, so
anything typed here is lost. A copy under another name is yours, and is never replaced.

```css
[data-style="lamplit"] {
  --theme-name: "Lamplit";
  --theme-version: "1.0";
  --theme-about: "A warm near-black room and one lamp. Satoshi for reading, Fraunces for titles, soft cards.";
  --theme-order: 1;

  --lp-f-text: "Satoshi", "Manrope", system-ui, "Segoe UI", sans-serif;
  --lp-f-label: "Satoshi", "Manrope", system-ui, "Segoe UI", sans-serif;
  --lp-f-display: "Fraunces", "Iowan Old Style", Georgia, serif;
  --lp-f-title: "Fraunces", "Iowan Old Style", Georgia, serif;
  --lp-f-synthesis: weight style small-caps;
  --lp-r-focal: 18px; --lp-r-plate: 16px; --lp-r-item: 12px; --lp-r-soft: 10px;
  --lp-r: 5px; --lp-r-tight: 3px; --lp-r-hair: 2px;
  --lp-sh-1: 0 1px 2px rgba(0,0,0,.30), 0 6px 18px rgba(0,0,0,.20);
  --lp-sh-2: 0 2px 5px rgba(0,0,0,.34), 0 14px 34px rgba(0,0,0,.34);
  --lp-sh-3: 0 8px 18px rgba(0,0,0,.42), 0 30px 80px rgba(0,0,0,.62);
  --lp-lit: inset 0 1px 0 color-mix(in srgb, var(--lp-bright) 6%, transparent);
  --lp-wash-border: 18%; --lp-wash-hair: 8%; --lp-wash-plate: 2.8%; --lp-wash-tile: 5%; --lp-wash-tile-hi: 6%; --lp-wash-af: 10%;
  --lp-wash-glow: 20%; --lp-glow-size: 18px;
  --lp-hair-w: 1px; --lp-label-case: none;
  --lp-trk-label: .01em; --lp-trk-head: .04em;
  --lp-t: 220ms cubic-bezier(.2,.8,.2,1);
  --lp-slow: 900ms cubic-bezier(.2,.8,.3,1);
  --lp-plate-art: none;
  --lp-cover-1: color-mix(in oklab, var(--lp-a) 48%, var(--lp-bg-3));
  --lp-cover-2: color-mix(in oklab, var(--lp-over) 40%, var(--lp-bg-2));
  --lp-cover-3: color-mix(in oklab, var(--lp-reached) 32%, var(--lp-bg-3));
  --lp-cover-4: color-mix(in oklab, var(--lp-planned) 32%, var(--lp-bg-3));
  --lp-cover-5: color-mix(in oklab, var(--lp-eaten) 38%, var(--lp-bg-4));
  --lp-cover-6: color-mix(in oklab, var(--lp-a-lo) 28%, var(--lp-bg-2));
  --lp-plank: color-mix(in oklab, var(--lp-a-lo) 34%, var(--lp-bg-4));
  --lp-picture-filter: saturate(.85) sepia(.14) brightness(.92);
}

[data-style="lamplit"][data-palette="gold"] {
  --theme-name: "Gold";
  --theme-swatch: #0c0a08 #e8e0d2 #cfa668 #93a8c9;
  --lp-bg: #0c0a08; --lp-bg-1: #120f0b; --lp-bg-2: #14110d; --lp-bg-3: #1f1913; --lp-bg-4: #2b2219;
  --lp-ink: #060503;
  --lp-tx: #e8e0d2; --lp-bright: #f6efe2; --lp-dim: #a89a84; --lp-fnt: #857a6a; --lp-light: #fff0da;
  --lp-a: #cfa668; --lp-a-hi: #e2c48d; --lp-a-lo: #b98f52; --lp-a-pale: #efdcb4; --lp-on-a: #141008;
  --lp-lamp: #cfa668;
  --lp-planned: #93a8c9; --lp-planned-lo: #4f6180;
  --lp-reached: #94b184;
  --lp-over: #c07a72; --lp-over-hi: #e8b7ae; --lp-over-bg: #3a1512;
  --lp-unsure: #cca466;
  --lp-moon: #c4cfd2; --lp-moon-hi: #e4ebee; --lp-moon-lo: #8d9a9f;
  --lp-water: #7fb2d9; --lp-water-hi: #9fd0ec; --lp-water-lo: #5b93bd; --lp-water-pale: #c9d6ea;
  --lp-tint-dawn: #e0a878; --lp-tint-dusk: #cc8e58; --lp-tint-night: #b98189;
  --lp-kind-day: #c9a06a; --lp-kind-movie: #d4a03c; --lp-kind-study: #9db4c0; --lp-kind-training: #c08a5e; --lp-kind-finance: #a8a06a;
  --lp-drink-1: #a98cd9; --lp-drink-2: #8fbf7a; --lp-drink-3: #5cc2b6; --lp-drink-4: #e0925f; --lp-drink-5: #d97b93;
}

[data-style="lamplit"][data-palette="oxblood"] {
  --theme-name: "Oxblood";
  --theme-swatch: #0d0908 #e8dfd6 #c07a72 #cfa668;
  --lp-bg: #0d0908; --lp-bg-1: #130d0c; --lp-bg-2: #16100e; --lp-bg-3: #211714; --lp-bg-4: #2e201c;
  --lp-ink: #070403;
  --lp-tx: #e8dfd6; --lp-bright: #f6eee6; --lp-dim: #ab9a8e; --lp-fnt: #887a70;
  --lp-a: #c07a72; --lp-a-hi: #dda199; --lp-a-lo: #a05f58; --lp-a-pale: #efd0ca; --lp-on-a: #170b09;
  --lp-lamp: #c07a72;
  --lp-eaten: #cfa668;
  --lp-over: #e5653f; --lp-over-hi: #f3ab90; --lp-over-bg: #3d160c;
}

[data-style="lamplit"][data-palette="midnight"] {
  --theme-name: "Midnight";
  --theme-swatch: #0a0b0d #e5e2db #93a8c9 #cfa668;
  --lp-bg: #0a0b0d; --lp-bg-1: #0f1114; --lp-bg-2: #111317; --lp-bg-3: #1a1d23; --lp-bg-4: #242830;
  --lp-ink: #050608;
  --lp-tx: #e5e2db; --lp-bright: #f4f1ea; --lp-dim: #a3a199; --lp-fnt: #817f79;
  --lp-a: #93a8c9; --lp-a-hi: #b9c9e2; --lp-a-lo: #7389ad; --lp-a-pale: #d5deee; --lp-on-a: #0b0f16;
  --lp-lamp: #93a8c9;
  --lp-eaten: #cfa668;
  --lp-planned: #b7a2e0; --lp-planned-lo: #5d4f8a;
}

[data-style="lamplit"][data-palette="forest"] {
  --theme-name: "Forest";
  --theme-swatch: #0a0c09 #e4e4d8 #94b184 #cfa668;
  --lp-bg: #0a0c09; --lp-bg-1: #0f120d; --lp-bg-2: #12150f; --lp-bg-3: #1a1f16; --lp-bg-4: #252b1f;
  --lp-ink: #050704;
  --lp-tx: #e4e4d8; --lp-bright: #f3f3e8; --lp-dim: #a2a490; --lp-fnt: #808270;
  --lp-a: #94b184; --lp-a-hi: #b6cfa8; --lp-a-lo: #76946a; --lp-a-pale: #d8e6cf; --lp-on-a: #0c1209;
  --lp-lamp: #94b184;
  --lp-eaten: #cfa668;
  --lp-reached: #62c2a8;
}

[data-style="lamplit"][data-palette="dusk"] {
  --theme-name: "Dusk";
  --theme-swatch: #1d1a16 #c9bfae #c8a571 #8fa3c2;
  --lp-bg: #1d1a16; --lp-bg-1: #221e1a; --lp-bg-2: #25211c; --lp-bg-3: #2e2924; --lp-bg-4: #3a332c;
  --lp-ink: #100e0b;
  --lp-tx: #c9bfae; --lp-bright: #ddd3c2; --lp-dim: #a19581; --lp-fnt: #8f846f; --lp-light: #ecdcc0;
  --lp-a: #c8a571; --lp-a-hi: #dbc196; --lp-a-lo: #ad8c5d; --lp-a-pale: #e4d3b2; --lp-on-a: #17120b;
  --lp-lamp: #c8a571;
  --lp-planned: #8fa3c2; --lp-planned-lo: #4e5d77;
  --lp-reached: #8fab82;
  --lp-over: #c0837a; --lp-over-hi: #e0b4ac; --lp-over-bg: #3c201c;
  --lp-unsure: #c4a36f;
}
[data-style="lamplit"][data-palette="ash"] {
  --theme-name: "Ash";
  --theme-swatch: #1f1f20 #c6c3bd #c4a470 #8ea2c0;
  --lp-bg: #1f1f20; --lp-bg-1: #232324; --lp-bg-2: #262627; --lp-bg-3: #2f2f31; --lp-bg-4: #3a3a3c;
  --lp-ink: #111112;
  --lp-tx: #c6c3bd; --lp-bright: #d9d6d0; --lp-dim: #9f9c96; --lp-fnt: #8e8b86; --lp-light: #ebe4d6;
  --lp-a: #c4a470; --lp-a-hi: #d8bf94; --lp-a-lo: #a98a5c; --lp-a-pale: #e2d2b4; --lp-on-a: #16120b;
  --lp-lamp: #c4a470;
  --lp-planned: #8ea2c0; --lp-planned-lo: #4d5c75;
  --lp-reached: #8eaa82;
  --lp-over: #bf8279; --lp-over-hi: #dfb2aa; --lp-over-bg: #3b1f1b;
  --lp-unsure: #c2a26e;
}
[data-style="lamplit"][data-palette="slate"] {
  --theme-name: "Slate";
  --theme-swatch: #1c1f23 #c5c9cd #8fa3c2 #c8a571;
  --lp-bg: #1c1f23; --lp-bg-1: #202328; --lp-bg-2: #23272c; --lp-bg-3: #2b3036; --lp-bg-4: #363c43;
  --lp-ink: #0f1114;
  --lp-tx: #c5c9cd; --lp-bright: #d8dce0; --lp-dim: #9ea3a9; --lp-fnt: #8d9298; --lp-light: #e4e9f0;
  --lp-a: #8fa3c2; --lp-a-hi: #b2c2da; --lp-a-lo: #7387a6; --lp-a-pale: #cdd7e6; --lp-on-a: #0c1016;
  --lp-lamp: #8fa3c2;
  --lp-eaten: #c8a571;
  --lp-planned: #b69cd8; --lp-planned-lo: #5a4c84;
  --lp-reached: #8eab84;
  --lp-over: #c0847b; --lp-over-hi: #e0b5ad; --lp-over-bg: #3c201c;
  --lp-unsure: #c4a36f;
}

[data-style="lamplit"][data-palette="picture"] {
  --theme-name: "Image Match";
  --theme-swatch: #0c0a08 #e8e0d2 #cfa668 #93a8c9;
  --theme-match: gold;
}

.hd-shelfwrap::before, .hd-rail.hd-craterail::before { content: ""; position: absolute; inset: -30px 8% 0; pointer-events: none; z-index: 1;
  background: radial-gradient(60% 80% at 50% 0, color-mix(in srgb, var(--lp-lamp) 11%, transparent), transparent 72%); }
.hd-rail.hd-craterail { position: relative; }

.hd[data-pic] .hd-hero { background: radial-gradient(120% 100% at 0 0, color-mix(in srgb, var(--lp-lamp) 10%, transparent), transparent 62%), var(--hd-glass-read); }
.hd-tabs > .hd-tab.hd-on { background: linear-gradient(color-mix(in srgb, var(--lp-lamp) 9%, transparent), transparent), var(--bg-3) !important; }
```
