---
aliases:
  - Guide
tags:
  - guide
---
# The Vault Guide

This vault is a place to think in. Notes go in by its keys, live in a few folders, and are read back by the Hall and the daily note.

## The keys

| key | what it does |
| --- | --- |
| `Alt+C` | a task into today's note — it stays on that day |
| `Alt+J` | a thought into today's journal, with its time |
| `Alt+I` | anything throwaway into the Inbox — clear it every week |
| `Alt+E` | select words, then link them to the note they mean — or to a new permanent note |
| `Alt+W` | something you want |
| `Alt+Z` | the full menu |
| `Ctrl+Shift+D` | today's note |

## Where it goes

- `00_Inbox` — the throwaway shelf. Empty it once a week.
- `01_Zettelkasten` — your notes: `Permanent` for a thought in your own words, `Literature` for what a source said, `Fleeting` for what you have not decided about yet.
- `02_MOCs` — maps: a note that links what belongs together. The Hall's shelves list them.
- `03_PARA` — `01_Projects` (has an end), `02_Areas` (does not), `03_Resources` (reference), `04_Archive` (done with).
- `04_Attachments` — images and files, put there by Obsidian.
- `Daily` — one note a day, made from the template by `Ctrl+Shift+D` or the Hall.
- `99_Meta` — the vault's own machinery: templates, scripts, themes, modules, settings. Nothing here is a note to write in.

## The three moves

1. **Capture**: a key, and keep going. Nothing is filed at the moment it is written.
2. **Decide**: once a week, each inbox line becomes a task, a permanent note, or nothing.
3. **Link**: select the words that mean a note and press `Alt+E`. A note with no links is a note nobody finds.

## Going deeper

A permanent note is one idea, in your words, with its sources linked. A map is made when three or more notes keep pointing at the same thing. The daily note holds the day: its blocks, its tasks, its habits, its journal.

## Once a week

Empty the inbox. Read the week's daily notes. Make a map if one is asking to be made.

## The rooms

The Hall is the front door: the day's line, the doors to where you go most, the shelves of maps, the ledger of tasks and habits and money, and the settings. Each room beyond it is a note that a view draws. The vault starts with the Hall and the daily note; what else it holds is yours to add.
